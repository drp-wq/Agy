/**
 * Type definitions matching the PROTTUSH Homarr/JARVIS backend schemas
 */

export type ServiceHealthStatus = 'HEALTHY' | 'WARNING' | 'CRITICAL' | 'OFFLINE' | 'STOPPED';

export interface MicroserviceStatus {
  status: ServiceHealthStatus;
  port?: number | number[];
  mode?: string;
  service?: string;
}

export interface SystemMetrics {
  timestamp: number;
  uptime_seconds: number;
  uptime_formatted: string;
  load_averages: [number, number, number];
  memory: {
    total_gb: number;
    used_gb: number;
    available_gb: number;
    usage_pct: number;
  };
  disk: {
    total_gb: number;
    used_gb: number;
    free_gb: number;
    usage_pct: number;
  };
  services: {
    homarr: MicroserviceStatus;
    docker_socket_proxy: MicroserviceStatus;
    gate_observer: MicroserviceStatus;
    binance_observer: MicroserviceStatus;
    telegram_notifier: MicroserviceStatus;
    hub_companion: MicroserviceStatus;
    caddy: MicroserviceStatus;
    [key: string]: MicroserviceStatus | undefined;
  };
}

export interface PaperPosition {
  symbol: string;
  side: 'BUY' | 'SELL' | 'LONG' | 'SHORT';
  entry_price: number;
  current_price: number;
  qty: number;
  pnl_usd: number;
  pnl_pct: number;
  stop_loss?: number;
  take_profit?: number;
  strategy: string;
  engine: 'binance' | 'gate';
  timestamp: number;
}

export interface BinanceOverview {
  connected: boolean;
  paper_equity_usd: number;
  total_pnl_usd: number;
  total_pnl_pct: number;
  stale_warning: boolean;
  active_positions_count: number;
  progress: {
    status: string;
    current_stage: string;
    cycle_count: number;
    total_cycles: number;
  };
  risk: {
    max_drawdown_pct: number;
    leverage: string;
    daily_var_usd: number;
    risk_level: 'LOW' | 'MODERATE' | 'HIGH' | 'CRITICAL';
  };
  data_freshness_sec: number;
}

export interface GateSolanaDiscovery {
  id: string;
  symbol: string;
  token_name: string;
  pool_address: string;
  liquidity_usd: number;
  price_usd: number;
  safety_score: number;
  anti_rug_status: 'PASSED' | 'FLAGGED' | 'SUSPICIOUS';
  time_ago: string;
  dex: string;
}

export interface GateOverview {
  connected: boolean;
  paper_balance_usd: number;
  total_solana_discoveries: number;
  stale_warning: boolean;
  staleness_seconds: number;
  bots_running: number;
  discoveries: GateSolanaDiscovery[];
}

export interface TelemetrySummary {
  binance: {
    health: { connected: boolean; status: string };
    overview: BinanceOverview;
  };
  gate: {
    health: { connected: boolean; status: string };
    overview: GateOverview;
  };
  positions: PaperPosition[];
}

export interface UniversalNotification {
  id: string;
  source: 'binance' | 'gate' | 'telegram' | 'whatsapp' | 'google' | 'system' | 'github';
  title: string;
  message: string;
  severity: 'info' | 'warning' | 'critical' | 'success';
  symbol?: string;
  is_simulated: boolean;
  deep_link?: string;
  timestamp: number;
  read: boolean;
}

export interface GoogleIntegrationStatus {
  authorized: boolean;
  auth_url?: string;
  email?: string;
  scopes: string[];
  gmail: {
    unread_count: number;
    threads: Array<{ from: string; subject: string; snippet: string; date: string }>;
  };
  calendar: {
    upcoming_events: Array<{ summary: string; start: string; location?: string }>;
  };
  drive: {
    recent_files: Array<{ name: string; type: string; modified: string; url: string }>;
  };
  tasks: {
    pending_tasks: Array<{ title: string; due?: string; completed: boolean }>;
  };
}

export interface TelegramBotStatus {
  connected: boolean;
  bot_username: string;
  active_subscribers: number;
  last_alert_ts: number;
  recent_alerts: Array<{
    id: number;
    text: string;
    timestamp: number;
    chat_id: number;
    is_paper_trading: boolean;
  }>;
}

export interface WhatsAppStatus {
  connected: boolean;
  bridge_mode: 'DIRECT_DEEP_LINK' | 'COMPANION_API' | 'WEB_SHORTCUT';
  last_ping: number;
  configured_shortcuts: Array<{
    id: string;
    label: string;
    phone_or_group: string;
    is_group: boolean;
    direct_url: string;
  }>;
}

export type GraphicsMode = 'cinematic' | 'balanced' | 'performance';

export interface WidgetPreferences {
  collapsed: Record<string, boolean>;
  graphicsMode: GraphicsMode;
  radarZoom: number;
  soundEnabled: boolean;
}
