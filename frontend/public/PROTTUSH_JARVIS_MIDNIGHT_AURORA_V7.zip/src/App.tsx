import React, { useState, useEffect } from 'react';
import { 
  Radio, 
  Activity, 
  TrendingUp, 
  Radar as RadarIcon, 
  Send, 
  MessageSquare, 
  Calendar, 
  Bell, 
  Cpu, 
  Sparkles, 
  Layers, 
  RefreshCw, 
  Command, 
  Sliders, 
  ExternalLink,
  ShieldCheck,
  CheckCircle2,
  AlertCircle
} from 'lucide-react';
import confetti from 'canvas-confetti';

import { 
  SystemMetrics, 
  BinanceOverview, 
  GateOverview, 
  PaperPosition, 
  UniversalNotification, 
  GoogleIntegrationStatus, 
  TelegramBotStatus, 
  WhatsAppStatus, 
  GraphicsMode,
  WidgetPreferences
} from './types/jarvis';
import { jarvisApi } from './services/api';
import { JarvisCore3D } from './components/JarvisCore3D';
import { TopThreeWidgets } from './components/TopThreeWidgets';
import { SpatialWidget } from './components/SpatialWidget';
import { ScannerRadar } from './components/ScannerRadar';
import { TradingTelemetry } from './components/TradingTelemetry';
import { TelegramIntelligence } from './components/TelegramIntelligence';
import { WhatsAppCenter } from './components/WhatsAppCenter';
import { GoogleProductivity } from './components/GoogleProductivity';
import { UnifiedTimeline } from './components/UnifiedTimeline';
import { CommandPaletteModal } from './components/CommandPaletteModal';

export default function App() {
  // Global Telemetry State
  const [metrics, setMetrics] = useState<SystemMetrics | null>(null);
  const [binance, setBinance] = useState<BinanceOverview | null>(null);
  const [gate, setGate] = useState<GateOverview | null>(null);
  const [positions, setPositions] = useState<PaperPosition[]>([]);
  const [notifications, setNotifications] = useState<UniversalNotification[]>([]);
  const [googleStatus, setGoogleStatus] = useState<GoogleIntegrationStatus | null>(null);
  const [telegramStatus, setTelegramStatus] = useState<TelegramBotStatus | null>(null);
  const [waStatus, setWaStatus] = useState<WhatsAppStatus | null>(null);

  // UI & Preferences
  const [graphicsMode, setGraphicsMode] = useState<GraphicsMode>('cinematic');
  const [isPaletteOpen, setIsPaletteOpen] = useState(false);
  const [radarPulses, setRadarPulses] = useState(0);
  const [isRefreshing, setIsRefreshing] = useState(false);

  // Collapsible widget state (persisted to localStorage)
  const [collapsedMap, setCollapsedMap] = useState<Record<string, boolean>>(() => {
    try {
      const saved = localStorage.getItem('jarvis_v7_collapsed');
      if (saved) return JSON.parse(saved);
    } catch {}
    return {
      'sec-jarvis-core': false,
      'sec-radar': false,
      'sec-trading': false,
      'sec-telegram': false,
      'sec-whatsapp': false,
      'sec-google': false,
      'sec-timeline': false,
      'sec-system': false
    };
  });

  const toggleCollapse = (id: string) => {
    setCollapsedMap(prev => {
      const updated = { ...prev, [id]: !prev[id] };
      try {
        localStorage.setItem('jarvis_v7_collapsed', JSON.stringify(updated));
      } catch {}
      return updated;
    });
  };

  // Initial Data Fetching
  const loadAllTelemetry = async () => {
    setIsRefreshing(true);
    try {
      const [
        sysMetrics,
        binanceData,
        gateData,
        posData,
        notifData,
        gData,
        tgData,
        waData
      ] = await Promise.all([
        jarvisApi.getSystemMetrics(),
        jarvisApi.getBinanceOverview(),
        jarvisApi.getGateOverview(),
        jarvisApi.getPositions(),
        jarvisApi.getNotifications(),
        jarvisApi.getGoogleStatus(),
        jarvisApi.getTelegramStatus(),
        jarvisApi.getWhatsAppStatus()
      ]);

      setMetrics(sysMetrics);
      setBinance(binanceData);
      setGate(gateData);
      setPositions(posData);
      setNotifications(notifData);
      setGoogleStatus(gData);
      setTelegramStatus(tgData);
      setWaStatus(waData);
      setRadarPulses(prev => prev + 1);
    } catch (err) {
      console.error('Failed to load telemetry:', err);
    } finally {
      setIsRefreshing(false);
    }
  };

  useEffect(() => {
    loadAllTelemetry();
    // Auto-refresh telemetry every 10 seconds
    const interval = setInterval(loadAllTelemetry, 10000);
    return () => clearInterval(interval);
  }, []);

  // Keyboard shortcut for Command Palette (Ctrl+K or Cmd+K)
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === 'k') {
        e.preventDefault();
        setIsPaletteOpen(prev => !prev);
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, []);

  const handleNavigateSection = (sectionId: string) => {
    const el = document.getElementById(sectionId);
    if (el) {
      el.scrollIntoView({ behavior: 'smooth', block: 'start' });
      // If collapsed, expand it
      if (collapsedMap[sectionId]) {
        toggleCollapse(sectionId);
      }
    }
  };

  const handleFireConfetti = () => {
    confetti({
      particleCount: 80,
      spread: 70,
      origin: { y: 0.6 },
      colors: ['#00E5FF', '#387BFF', '#9B5CFF', '#00F5A0']
    });
  };

  return (
    <div className="min-h-screen bg-[#030611] text-[#E2E8F0] pb-16 selection:bg-[#00E5FF]/20 selection:text-[#00E5FF]">
      {/* Top Holographic Navigation Bar */}
      <header className="sticky top-0 z-40 bg-[#081225]/80 backdrop-blur-xl border-b border-[#00E5FF]/20 px-4 lg:px-8 py-3">
        <div className="max-w-7xl mx-auto flex items-center justify-between gap-4">
          {/* Brand & Project Identity */}
          <div className="flex items-center gap-3">
            <div 
              onClick={handleFireConfetti}
              className="w-9 h-9 rounded-xl bg-gradient-to-br from-[#00E5FF] to-[#9B5CFF] flex items-center justify-center text-white font-bold text-lg shadow-[0_0_20px_rgba(0,229,255,0.5)] cursor-pointer hover:scale-105 transition-transform"
              title="Click to celebrate JARVIS V7 Nominal State!"
            >
              ⚡
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="font-cyber font-bold text-base lg:text-lg text-white tracking-wider">
                  PROTTUSH JARVIS
                </span>
                <span className="text-[10px] px-1.5 py-0.5 rounded bg-[#9B5CFF]/20 text-[#9B5CFF] border border-[#9B5CFF]/40 font-mono font-semibold">
                  V7 MIDNIGHT AURORA
                </span>
                <span className="hidden sm:inline-block text-[10px] px-1.5 py-0.5 rounded bg-[#00F5A0]/10 text-[#00F5A0] border border-[#00F5A0]/30 font-mono">
                  SPATIAL INTELLIGENCE
                </span>
              </div>
              <p className="text-[11px] text-slate-400 font-mono hidden md:block">
                Universal Command Center · Homarr / Hostinger VPS · Binance & Gate.io Telemetry
              </p>
            </div>
          </div>

          {/* Action Center: Command Palette Trigger, Graphics Mode Selector, Refresh */}
          <div className="flex items-center gap-2">
            {/* Graphics Mode Selector */}
            <div className="hidden sm:flex items-center bg-black/50 p-1 rounded-lg border border-white/10 text-xs font-mono">
              <span className="text-slate-400 text-[10px] px-2 flex items-center gap-1">
                <Sliders className="w-3 h-3 text-[#00E5FF]" /> GFX:
              </span>
              {(['cinematic', 'balanced', 'performance'] as GraphicsMode[]).map(mode => (
                <button
                  key={mode}
                  onClick={() => setGraphicsMode(mode)}
                  className={`px-2 py-0.5 rounded text-[10px] capitalize transition ${
                    graphicsMode === mode
                      ? 'bg-[#00E5FF]/20 text-[#00E5FF] border border-[#00E5FF]/40 font-semibold'
                      : 'text-slate-400 hover:text-white'
                  }`}
                >
                  {mode}
                </button>
              ))}
            </div>

            {/* Ctrl + K Palette Trigger */}
            <button
              onClick={() => setIsPaletteOpen(true)}
              className="px-3 py-1.5 rounded-lg bg-[#00E5FF]/15 hover:bg-[#00E5FF]/25 border border-[#00E5FF]/40 text-[#00E5FF] font-mono text-xs flex items-center gap-1.5 transition shadow-[0_0_12px_rgba(0,229,255,0.15)]"
            >
              <Command className="w-3.5 h-3.5" />
              <span className="hidden md:inline">Command Palette</span>
              <kbd className="px-1 py-0.2 rounded bg-black/40 text-[10px] border border-white/10">⌘K</kbd>
            </button>

            {/* Manual Refresh */}
            <button
              onClick={loadAllTelemetry}
              disabled={isRefreshing}
              className="p-2 rounded-lg bg-white/5 hover:bg-white/10 border border-white/10 text-slate-300 hover:text-white transition disabled:opacity-50"
              title="Refresh All Telemetry"
            >
              <RefreshCw className={`w-3.5 h-3.5 ${isRefreshing ? 'animate-spin text-[#00E5FF]' : ''}`} />
            </button>
          </div>
        </div>
      </header>

      {/* Main Command Dashboard Container */}
      <main className="max-w-7xl mx-auto px-4 lg:px-8 mt-6 space-y-6">
        {/* REPAIRED TOP 3 WIDGETS: Clock, Weather, System Health */}
        {metrics && (
          <TopThreeWidgets 
            metrics={metrics} 
            onRefreshMetrics={loadAllTelemetry} 
          />
        )}

        {/* SECTION 1 & 2: 3D Holographic Core & Solana DEX Radar Scanner */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* 3D Holographic Core */}
          <SpatialWidget
            id="sec-jarvis-core"
            title="JARVIS Spatial Intelligence Core"
            subtitle="Real-time WebGL orbital simulation reacting to system events"
            icon={Radio}
            badge={{ text: '3D ACTIVE', variant: 'live' }}
            isCollapsed={!!collapsedMap['sec-jarvis-core']}
            onToggleCollapse={() => toggleCollapse('sec-jarvis-core')}
          >
            <div className="space-y-4">
              <JarvisCore3D
                graphicsMode={graphicsMode}
                systemStatus={metrics?.services.gate_observer.status === 'HEALTHY' ? 'HEALTHY' : 'WARNING'}
                radarPulseCount={radarPulses}
                onCoreClick={() => setIsPaletteOpen(true)}
              />

              <div className="p-3 rounded-lg bg-black/40 border border-white/10 text-xs font-mono flex items-center justify-between text-slate-300">
                <div className="flex items-center gap-2">
                  <ShieldCheck className="w-4 h-4 text-[#00F5A0]" />
                  <span>Caddy Reverse Proxy & Docker Socket Proxy Sandboxed</span>
                </div>
                <span className="text-[#00E5FF] font-semibold">Zero Order Rights</span>
              </div>
            </div>
          </SpatialWidget>

          {/* Scanner Radar */}
          <SpatialWidget
            id="sec-radar"
            title="Solana Liquidity Radar Scanner"
            subtitle="Live Raydium CPMM & Meteora DLMM pool discovery stream"
            icon={RadarIcon}
            badge={{ text: 'SCANNING', variant: 'live' }}
            isCollapsed={!!collapsedMap['sec-radar']}
            onToggleCollapse={() => toggleCollapse('sec-radar')}
          >
            {gate && <ScannerRadar gateOverview={gate} />}
          </SpatialWidget>
        </div>

        {/* SECTION 3 & 4: Verified Trading Telemetry & Active Paper Positions */}
        <SpatialWidget
          id="sec-trading"
          title="Autonomous Trading Intelligence"
          subtitle="Binance Alpha V3 Experiment & Gate.io Paper Trading Observer (Read-Only)"
          icon={TrendingUp}
          badge={{ text: 'PAPER VERIFIED', variant: 'sim' }}
          isCollapsed={!!collapsedMap['sec-trading']}
          onToggleCollapse={() => toggleCollapse('sec-trading')}
        >
          {binance && gate && (
            <TradingTelemetry
              binanceOverview={binance}
              gateOverview={gate}
              positions={positions}
            />
          )}
        </SpatialWidget>

        {/* SECTION 5 & 6: Telegram Bot Intelligence & Repaired WhatsApp Center */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Telegram Intelligence */}
          <SpatialWidget
            id="sec-telegram"
            title="Telegram Bot Intelligence"
            subtitle="Verified notification stream from @ProttushAlertsBot"
            icon={Send}
            badge={{ text: 'LIVE FEED', variant: 'live' }}
            isCollapsed={!!collapsedMap['sec-telegram']}
            onToggleCollapse={() => toggleCollapse('sec-telegram')}
          >
            {telegramStatus && (
              <TelegramIntelligence 
                status={telegramStatus} 
                onRefresh={loadAllTelemetry} 
              />
            )}
          </SpatialWidget>

          {/* Repaired WhatsApp Web Suite */}
          <SpatialWidget
            id="sec-whatsapp"
            title="WhatsApp Companion Suite"
            subtitle="CSP-safe launcher, direct phone dialer, and Alpha group shortcuts"
            icon={MessageSquare}
            badge={{ text: 'CSP SOLVED', variant: 'live' }}
            isCollapsed={!!collapsedMap['sec-whatsapp']}
            onToggleCollapse={() => toggleCollapse('sec-whatsapp')}
          >
            {waStatus && <WhatsAppCenter status={waStatus} />}
          </SpatialWidget>
        </div>

        {/* SECTION 7: Google Workspace Productivity Suite */}
        <SpatialWidget
          id="sec-google"
          title="Google Workspace Productivity"
          subtitle="Minimal-permission authorized telemetry for Gmail, Calendar, Drive, and Tasks"
          icon={Calendar}
          badge={{ text: 'AUTHORIZED', variant: 'live' }}
          isCollapsed={!!collapsedMap['sec-google']}
          onToggleCollapse={() => toggleCollapse('sec-google')}
        >
          {googleStatus && <GoogleProductivity status={googleStatus} />}
        </SpatialWidget>

        {/* SECTION 8: Unified Event & Signal Timeline */}
        <SpatialWidget
          id="sec-timeline"
          title="Unified Activity & Signal Timeline"
          subtitle="Consolidated real-time event log across Trading, Telegram, System, and Google"
          icon={Bell}
          badge={{ text: `${notifications.length} EVENTS`, variant: 'neutral' }}
          isCollapsed={!!collapsedMap['sec-timeline']}
          onToggleCollapse={() => toggleCollapse('sec-timeline')}
        >
          <UnifiedTimeline
            notifications={notifications}
            onMarkAllRead={() => {
              setNotifications(prev => prev.map(n => ({ ...n, read: true })));
            }}
          />
        </SpatialWidget>
      </main>

      {/* Global Command Palette Modal (Ctrl + K) */}
      <CommandPaletteModal
        isOpen={isPaletteOpen}
        onClose={() => setIsPaletteOpen(false)}
        onNavigateSection={handleNavigateSection}
        graphicsMode={graphicsMode}
        onChangeGraphicsMode={setGraphicsMode}
      />
    </div>
  );
}
