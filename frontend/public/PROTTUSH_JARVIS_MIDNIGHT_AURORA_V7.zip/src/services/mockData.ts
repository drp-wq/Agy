import {
  SystemMetrics,
  BinanceOverview,
  GateOverview,
  PaperPosition,
  UniversalNotification,
  GoogleIntegrationStatus,
  TelegramBotStatus,
  WhatsAppStatus
} from '../types/jarvis';

export const INITIAL_SYSTEM_METRICS: SystemMetrics = {
  timestamp: Date.now() / 1000,
  uptime_seconds: 452930,
  uptime_formatted: "5d 5h 48m",
  load_averages: [0.42, 0.58, 0.65],
  memory: {
    total_gb: 15.6,
    used_gb: 6.84,
    available_gb: 8.76,
    usage_pct: 43.8
  },
  disk: {
    total_gb: 98.4,
    used_gb: 34.2,
    free_gb: 64.2,
    usage_pct: 34.7
  },
  services: {
    homarr: { status: 'HEALTHY', port: 7575 },
    docker_socket_proxy: { status: 'HEALTHY', port: 2375, mode: 'READ_ONLY' },
    gate_observer: { status: 'HEALTHY', port: 8844, mode: 'READ_ONLY' },
    binance_observer: { status: 'HEALTHY', port: 8845, mode: 'READ_ONLY' },
    telegram_notifier: { status: 'HEALTHY', service: 'prottush-binance-telegram' },
    hub_companion: { status: 'HEALTHY', port: 7580 },
    caddy: { status: 'HEALTHY', port: [80, 443] }
  }
};

export const INITIAL_BINANCE_OVERVIEW: BinanceOverview = {
  connected: true,
  paper_equity_usd: 12450.80,
  total_pnl_usd: 1842.30,
  total_pnl_pct: 17.36,
  stale_warning: false,
  active_positions_count: 3,
  progress: {
    status: "ACTIVE",
    current_stage: "Stage 3 (Alpha V3 Optimizer)",
    cycle_count: 142,
    total_cycles: 250
  },
  risk: {
    max_drawdown_pct: 3.4,
    leverage: "1x Spot / Isolated 2x",
    daily_var_usd: 145.20,
    risk_level: "LOW"
  },
  data_freshness_sec: 1.4
};

export const INITIAL_GATE_OVERVIEW: GateOverview = {
  connected: true,
  paper_balance_usd: 8640.25,
  total_solana_discoveries: 18,
  stale_warning: false,
  staleness_seconds: 2.1,
  bots_running: 4,
  discoveries: [
    {
      id: "sol-ray-001",
      symbol: "SOL/USDC",
      token_name: "Solana Raydium Pool",
      pool_address: "5Q544fKrFoe6tsEbD7S8EmxGTJYAKtTVhAW5Q5pge4j1",
      liquidity_usd: 1450000,
      price_usd: 188.45,
      safety_score: 98,
      anti_rug_status: "PASSED",
      time_ago: "3m ago",
      dex: "Raydium CPMM"
    },
    {
      id: "sol-ray-002",
      symbol: "JUP/SOL",
      token_name: "Jupiter DEX Liquidity",
      pool_address: "7xKXtg2CW87d97TXJSDpbD5jBkheTqA83TZRuJosgAsU",
      liquidity_usd: 890000,
      price_usd: 1.12,
      safety_score: 95,
      anti_rug_status: "PASSED",
      time_ago: "14m ago",
      dex: "Meteora DLMM"
    },
    {
      id: "sol-ray-003",
      symbol: "ORCA/SOL",
      token_name: "Orca Whirlpool Yield",
      pool_address: "HJPjoWUrhoZzkNfRpHuieeFKAvTkD12BPjPOe387HR5g",
      liquidity_usd: 420000,
      price_usd: 3.48,
      safety_score: 92,
      anti_rug_status: "PASSED",
      time_ago: "28m ago",
      dex: "Orca Whirlpools"
    }
  ]
};

export const INITIAL_POSITIONS: PaperPosition[] = [
  {
    symbol: "BTC/USDT",
    side: "LONG",
    entry_price: 91250.00,
    current_price: 93420.50,
    qty: 0.08,
    pnl_usd: 173.64,
    pnl_pct: 2.38,
    stop_loss: 89800.00,
    take_profit: 96500.00,
    strategy: "Alpha V3 Momentum Breakout",
    engine: "binance",
    timestamp: Date.now() - 3600000 * 4
  },
  {
    symbol: "ETH/USDT",
    side: "LONG",
    entry_price: 3340.20,
    current_price: 3422.10,
    qty: 1.5,
    pnl_usd: 122.85,
    pnl_pct: 2.45,
    stop_loss: 3260.00,
    take_profit: 3580.00,
    strategy: "Multi-Timeframe Trend Following",
    engine: "binance",
    timestamp: Date.now() - 3600000 * 8
  },
  {
    symbol: "SOL/USDT",
    side: "LONG",
    entry_price: 181.50,
    current_price: 188.45,
    qty: 15.0,
    pnl_usd: 104.25,
    pnl_pct: 3.83,
    stop_loss: 174.00,
    take_profit: 205.00,
    strategy: "Solana Liquidity Velocity Scanner",
    engine: "gate",
    timestamp: Date.now() - 3600000 * 2
  }
];

export const INITIAL_NOTIFICATIONS: UniversalNotification[] = [
  {
    id: "notif-001",
    source: "binance",
    title: "Binance Alpha V3 Experiment Milestone",
    message: "Cycle #142 completed. Trailing stop-loss moved to $91,250 on BTC/USDT position.",
    severity: "info",
    symbol: "BTC/USDT",
    is_simulated: true,
    deep_link: "https://trading.prottushjd.tech/binance",
    timestamp: Date.now() - 120000,
    read: false
  },
  {
    id: "notif-002",
    source: "gate",
    title: "Gate.io Solana Discovery Stream Active",
    message: "New liquidity pool SOL/USDC detected with $1.45M TVL and verified anti-rug pass.",
    severity: "success",
    symbol: "SOL",
    is_simulated: true,
    deep_link: "https://trading.prottushjd.tech/",
    timestamp: Date.now() - 340000,
    read: false
  },
  {
    id: "notif-003",
    source: "system",
    title: "Microservice Grid Synced",
    message: "Caddy proxy, Docker Socket Proxy, and Hub Companion verified nominal on Hostinger VPS.",
    severity: "info",
    is_simulated: false,
    timestamp: Date.now() - 900000,
    read: true
  },
  {
    id: "notif-004",
    source: "telegram",
    title: "Telegram Alert Received",
    message: "Signal #899: RSI divergence detected on 4h timeframe across BTC/ETH correlation index.",
    severity: "warning",
    symbol: "BTC",
    is_simulated: true,
    timestamp: Date.now() - 1800000,
    read: true
  }
];

export const INITIAL_GOOGLE_STATUS: GoogleIntegrationStatus = {
  authorized: true,
  email: "drprottush44@gmail.com",
  scopes: ["gmail.readonly", "calendar.readonly", "drive.readonly", "tasks.readonly"],
  gmail: {
    unread_count: 4,
    threads: [
      { from: "GitHub Alerts", subject: "[Security Alert] Repository audit completed successfully", snippet: "Dependabot alerts resolved on prottush-homarr-hub.", date: "10:45 AM" },
      { from: "Cloud Infrastructure", subject: "Hostinger VPS Backup Snapshot Finished", snippet: "Daily volume snapshot completed (NVMe 34.2 GB).", date: "04:00 AM" },
      { from: "Binance API Services", subject: "Testnet API Key Health Notice", snippet: "Read-only testnet observation key validated.", date: "Yesterday" }
    ]
  },
  calendar: {
    upcoming_events: [
      { summary: "JARVIS V7 Autonomous Review", start: "Today · 17:00", location: "Holo Console" },
      { summary: "Gate.io Solana Scanner Calibration", start: "Tomorrow · 11:30", location: "Trading Engine" },
      { summary: "Homarr Container Security Verification", start: "Friday · 15:00", location: "VPS Terminal" }
    ]
  },
  drive: {
    recent_files: [
      { name: "JARVIS_Architecture_V7.pdf", type: "document", modified: "Today 14:22", url: "#" },
      { name: "Trading_Alpha_Risk_Model.xlsx", type: "spreadsheet", modified: "Yesterday", url: "#" },
      { name: "Homarr_Backup_20261106.tar.gz", type: "archive", modified: "Nov 05", url: "#" }
    ]
  },
  tasks: {
    pending_tasks: [
      { title: "Review iPad widget height calibration", due: "Today", completed: false },
      { title: "Calibrate Solana Raydium anti-rug filters", due: "Tomorrow", completed: false },
      { title: "Verify Telegram polling thread lifecycle", due: "Nov 09", completed: true }
    ]
  }
};

export const INITIAL_TELEGRAM_STATUS: TelegramBotStatus = {
  connected: true,
  bot_username: "@ProttushAlertsBot",
  active_subscribers: 1,
  last_alert_ts: Date.now() - 1800000,
  recent_alerts: [
    {
      id: 899,
      text: "⚡ [JARVIS ALPHA V3] BTC/USDT target $93,400 reached. Trailing SL updated.",
      timestamp: Date.now() - 1800000,
      chat_id: 1083921,
      is_paper_trading: true
    },
    {
      id: 898,
      text: "🛡️ [GATE SOLANA] Pool 5Q544 passed contract audit. TVL > $1M.",
      timestamp: Date.now() - 3600000 * 3,
      chat_id: 1083921,
      is_paper_trading: true
    }
  ]
};

export const INITIAL_WHATSAPP_STATUS: WhatsAppStatus = {
  connected: true,
  bridge_mode: "DIRECT_DEEP_LINK",
  last_ping: Date.now() - 60000,
  configured_shortcuts: [
    {
      id: "wa-1",
      label: "Personal Command / Self Chat",
      phone_or_group: "+1 (Direct Chat)",
      is_group: false,
      direct_url: "https://web.whatsapp.com/send?text=%2Fjarvis%20status"
    },
    {
      id: "wa-2",
      label: "Trading Alpha VIP Group",
      phone_or_group: "Alpha Signals",
      is_group: true,
      direct_url: "https://web.whatsapp.com/"
    },
    {
      id: "wa-3",
      label: "DevOps Emergency Escalation",
      phone_or_group: "Sysadmin Ops",
      is_group: true,
      direct_url: "https://web.whatsapp.com/"
    }
  ]
};
