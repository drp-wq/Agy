import React, { useState } from 'react';
import { 
  MessageSquare, 
  ExternalLink, 
  Smartphone, 
  ShieldCheck, 
  AlertCircle, 
  Send, 
  Users, 
  User, 
  Plus, 
  Globe,
  Share2
} from 'lucide-react';
import { WhatsAppStatus } from '../types/jarvis';

interface WhatsAppCenterProps {
  status: WhatsAppStatus;
}

export const WhatsAppCenter: React.FC<WhatsAppCenterProps> = ({ status }) => {
  const [quickMsg, setQuickMsg] = useState('');
  const [targetPhone, setTargetPhone] = useState('');

  const shortcuts = status.configured_shortcuts || [];

  const handleSendDirect = (e: React.FormEvent) => {
    e.preventDefault();
    if (!targetPhone) return;
    const cleanPhone = targetPhone.replace(/[^0-9]/g, '');
    const encoded = encodeURIComponent(quickMsg);
    const url = `https://wa.me/${cleanPhone}${encoded ? `?text=${encoded}` : ''}`;
    window.open(url, '_blank', 'noopener,noreferrer');
  };

  return (
    <div className="w-full space-y-4 font-mono text-xs">
      {/* WhatsApp Architecture & Diagnostic Notice */}
      <div className="p-3.5 rounded-xl bg-gradient-to-r from-[#25D366]/15 via-black/40 to-transparent border border-[#25D366]/30 flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center gap-3">
          <div className="w-9 h-9 rounded-full bg-[#25D366]/20 border border-[#25D366]/40 flex items-center justify-center text-[#25D366]">
            <MessageSquare className="w-4 h-4" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="font-bold text-white text-sm">WhatsApp Web Companion Suite</span>
              <span className="px-1.5 py-0.5 rounded text-[10px] bg-[#25D366]/20 text-[#25D366] border border-[#25D366]/30">
                OFFICIAL DEEP-LINK BRIDGE
              </span>
            </div>
            <div className="text-[11px] text-slate-400 mt-0.5">
              Protocol: <span className="text-slate-200">CSP-Safe Deep Navigation</span> · Cross-Frame Sandboxing: <span className="text-[#00F5A0]">Active</span>
            </div>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <a
            href="https://web.whatsapp.com"
            target="_blank"
            rel="noreferrer"
            className="px-3 py-1.5 rounded-lg bg-[#25D366]/20 hover:bg-[#25D366]/30 border border-[#25D366]/40 text-[#25D366] transition flex items-center gap-1.5 text-xs font-semibold"
          >
            <Globe className="w-3.5 h-3.5" />
            <span>Launch WhatsApp Web</span>
            <ExternalLink className="w-3 h-3" />
          </a>
        </div>
      </div>

      {/* Root-Cause Explanation of WhatsApp iframe Restrictions */}
      <div className="p-3 rounded-lg bg-black/40 border border-white/10 flex items-start gap-2.5 text-slate-300">
        <ShieldCheck className="w-4 h-4 text-[#00E5FF] mt-0.5 shrink-0" />
        <div className="leading-relaxed text-[11px]">
          <strong className="text-white">Security & iframe Policy:</strong> Meta WhatsApp Web strictly enforces <code className="text-[#00E5FF]">X-Frame-Options: DENY</code> and CSP frame-ancestors. Embedding directly inside an iframe results in browser blank-screen blocking. The V7 command center resolves this with native multi-platform deep links, rapid target dialing, and external companion session launch.
        </div>
      </div>

      {/* 2-Column: Quick Dial Direct Composer & Configured Shortcuts */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {/* Quick Contact Dispatcher */}
        <div className="p-3.5 rounded-xl bg-black/30 border border-white/10 flex flex-col justify-between">
          <div>
            <div className="text-xs font-bold text-white uppercase tracking-wider mb-2 flex items-center gap-1.5">
              <Send className="w-3.5 h-3.5 text-[#25D366]" />
              <span>Direct Chat Initiator</span>
            </div>
            <p className="text-[11px] text-slate-400 mb-3">
              Open a direct end-to-end encrypted session with any telephone number without saving it into address book.
            </p>

            <form onSubmit={handleSendDirect} className="space-y-2.5">
              <div>
                <label className="text-[10px] text-slate-400 uppercase">Country Code & Phone Number</label>
                <input
                  type="text"
                  value={targetPhone}
                  onChange={(e) => setTargetPhone(e.target.value)}
                  placeholder="+1 (555) 000-0000 or phone"
                  className="w-full mt-1 px-3 py-1.5 rounded bg-black/50 border border-white/10 text-white placeholder-slate-500 focus:outline-none focus:border-[#25D366] text-xs"
                />
              </div>
              <div>
                <label className="text-[10px] text-slate-400 uppercase">Pre-filled Command / Message (Optional)</label>
                <input
                  type="text"
                  value={quickMsg}
                  onChange={(e) => setQuickMsg(e.target.value)}
                  placeholder="e.g. /jarvis status or alert confirmation"
                  className="w-full mt-1 px-3 py-1.5 rounded bg-black/50 border border-white/10 text-white placeholder-slate-500 focus:outline-none focus:border-[#25D366] text-xs"
                />
              </div>

              <button
                type="submit"
                disabled={!targetPhone}
                className="w-full py-2 px-3 rounded-lg bg-[#25D366]/20 hover:bg-[#25D366]/30 border border-[#25D366]/50 text-[#25D366] disabled:opacity-40 disabled:cursor-not-allowed font-semibold transition flex items-center justify-center gap-2"
              >
                <Share2 className="w-3.5 h-3.5" />
                <span>Open in WhatsApp</span>
              </button>
            </form>
          </div>
        </div>

        {/* Configured Quick-Dial Shortcuts */}
        <div className="p-3.5 rounded-xl bg-black/30 border border-white/10 flex flex-col justify-between">
          <div>
            <div className="text-xs font-bold text-white uppercase tracking-wider mb-2 flex items-center gap-1.5">
              <Smartphone className="w-3.5 h-3.5 text-[#00E5FF]" />
              <span>Configured Shortcuts & Groups</span>
            </div>
            <p className="text-[11px] text-slate-400 mb-3">
              One-click shortcuts to personal self-notes, Alpha trading groups, and DevOps channels.
            </p>

            <div className="space-y-2">
              {shortcuts.map((sc) => (
                <a
                  key={sc.id}
                  href={sc.direct_url}
                  target="_blank"
                  rel="noreferrer"
                  className="p-2.5 rounded-lg bg-black/40 border border-white/5 hover:border-[#25D366]/40 hover:bg-[#25D366]/5 transition flex items-center justify-between group"
                >
                  <div className="flex items-center gap-2">
                    {sc.is_group ? (
                      <Users className="w-3.5 h-3.5 text-[#9B5CFF]" />
                    ) : (
                      <User className="w-3.5 h-3.5 text-[#25D366]" />
                    )}
                    <div>
                      <div className="text-white font-medium group-hover:text-[#25D366] transition">
                        {sc.label}
                      </div>
                      <div className="text-[10px] text-slate-400">{sc.phone_or_group}</div>
                    </div>
                  </div>
                  <ExternalLink className="w-3 h-3 text-slate-500 group-hover:text-[#25D366] transition" />
                </a>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
