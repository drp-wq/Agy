import React from 'react';
import { 
  TrendingUp, 
  ExternalLink, 
  ShieldAlert, 
  Activity, 
  Clock, 
  Layers, 
  Bot,
  Zap,
  ArrowUpRight
} from 'lucide-react';
import { BinanceOverview, GateOverview, PaperPosition } from '../types/jarvis';

interface TradingTelemetryProps {
  binanceOverview: BinanceOverview;
  gateOverview: GateOverview;
  positions: PaperPosition[];
}

export const TradingTelemetry: React.FC<TradingTelemetryProps> = ({
  binanceOverview,
  gateOverview,
  positions
}) => {
  return (
    <div className="w-full space-y-4">
      {/* 2-Column Summary Cards for Binance & Gate.io */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {/* BINANCE ALPHA V3 CARD */}
        <div className="p-4 rounded-xl bg-gradient-to-br from-[#081225]/90 to-[#030611] border border-[#9B5CFF]/30 relative overflow-hidden">
          <div className="flex items-center justify-between mb-3">
            <div className="flex items-center gap-2">
              <span className="w-2.5 h-2.5 rounded-full bg-[#9B5CFF] shadow-[0_0_8px_#9B5CFF]" />
              <h4 className="font-semibold text-white font-cyber tracking-wide">Binance Alpha V3 Observer</h4>
            </div>
            <a 
              href="https://trading.prottushjd.tech/binance" 
              target="_blank" 
              rel="noreferrer"
              className="text-[11px] font-mono text-[#9B5CFF] hover:underline flex items-center gap-1"
            >
              <span>Portal</span>
              <ExternalLink className="w-3 h-3" />
            </a>
          </div>

          <div className="grid grid-cols-2 gap-3 mb-3">
            <div className="p-2.5 rounded bg-black/40 border border-white/5">
              <span className="text-[10px] uppercase text-slate-400 font-mono">Paper Equity</span>
              <div className="text-xl font-bold font-mono text-white mt-0.5">
                ${binanceOverview.paper_equity_usd.toLocaleString('en-US', { minimumFractionDigits: 2 })}
              </div>
              <span className="text-[10px] text-[#00F5A0] font-mono flex items-center gap-0.5">
                <ArrowUpRight className="w-3 h-3" /> +{binanceOverview.total_pnl_pct}%
              </span>
            </div>

            <div className="p-2.5 rounded bg-black/40 border border-white/5">
              <span className="text-[10px] uppercase text-slate-400 font-mono">Realized PnL</span>
              <div className="text-xl font-bold font-mono text-[#00F5A0] mt-0.5">
                +${binanceOverview.total_pnl_usd.toFixed(2)}
              </div>
              <span className="text-[10px] text-slate-400 font-mono">
                {binanceOverview.active_positions_count} Active Orders
              </span>
            </div>
          </div>

          <div className="text-xs font-mono space-y-1.5 pt-2 border-t border-white/5">
            <div className="flex justify-between text-slate-300">
              <span className="text-slate-400">Strategy Status:</span>
              <span className="text-[#00E5FF]">{binanceOverview.progress.current_stage}</span>
            </div>
            <div className="flex justify-between text-slate-300">
              <span className="text-slate-400">Risk Matrix:</span>
              <span className="text-[#00F5A0]">{binanceOverview.risk.risk_level} · Drawdown {binanceOverview.risk.max_drawdown_pct}%</span>
            </div>
            <div className="flex justify-between text-slate-400 text-[11px]">
              <span>Data Freshness: {binanceOverview.data_freshness_sec}s ago</span>
              <span className="text-slate-500">Read-Only Sandboxed</span>
            </div>
          </div>
        </div>

        {/* GATE.IO AI TRADER CARD */}
        <div className="p-4 rounded-xl bg-gradient-to-br from-[#081225]/90 to-[#030611] border border-[#00E5FF]/30 relative overflow-hidden">
          <div className="flex items-center justify-between mb-3">
            <div className="flex items-center gap-2">
              <span className="w-2.5 h-2.5 rounded-full bg-[#00E5FF] shadow-[0_0_8px_#00E5FF]" />
              <h4 className="font-semibold text-white font-cyber tracking-wide">Gate.io Autonomous Observer</h4>
            </div>
            <a 
              href="https://trading.prottushjd.tech/" 
              target="_blank" 
              rel="noreferrer"
              className="text-[11px] font-mono text-[#00E5FF] hover:underline flex items-center gap-1"
            >
              <span>Gate Hub</span>
              <ExternalLink className="w-3 h-3" />
            </a>
          </div>

          <div className="grid grid-cols-2 gap-3 mb-3">
            <div className="p-2.5 rounded bg-black/40 border border-white/5">
              <span className="text-[10px] uppercase text-slate-400 font-mono">Paper Balance</span>
              <div className="text-xl font-bold font-mono text-white mt-0.5">
                ${gateOverview.paper_balance_usd.toLocaleString('en-US', { minimumFractionDigits: 2 })}
              </div>
              <span className="text-[10px] text-slate-400 font-mono">USDT Spot Reserve</span>
            </div>

            <div className="p-2.5 rounded bg-black/40 border border-white/5">
              <span className="text-[10px] uppercase text-slate-400 font-mono">Solana Discoveries</span>
              <div className="text-xl font-bold font-mono text-[#00E5FF] mt-0.5">
                {gateOverview.total_solana_discoveries} Pools
              </div>
              <span className="text-[10px] text-[#00F5A0] font-mono">
                {gateOverview.bots_running} Autonomous Observers
              </span>
            </div>
          </div>

          <div className="text-xs font-mono space-y-1.5 pt-2 border-t border-white/5">
            <div className="flex justify-between text-slate-300">
              <span className="text-slate-400">Liquidity Telemetry:</span>
              <span className="text-[#00F5A0]">Raydium CPMM & Meteora DLMM Active</span>
            </div>
            <div className="flex justify-between text-slate-300">
              <span className="text-slate-400">Security Gate:</span>
              <span className="text-[#00E5FF]">Strict Read-Only Observer Mode</span>
            </div>
            <div className="flex justify-between text-slate-400 text-[11px]">
              <span>Staleness: {gateOverview.staleness_seconds}s</span>
              <span className="text-[#00F5A0]">Connected (:8844)</span>
            </div>
          </div>
        </div>
      </div>

      {/* VERIFIED ACTIVE PAPER POSITIONS TABLE */}
      <div className="rounded-xl border border-white/10 bg-black/30 overflow-hidden font-mono text-xs">
        <div className="p-3 bg-white/5 border-b border-white/10 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <TrendingUp className="w-4 h-4 text-[#00E5FF]" />
            <span className="font-semibold text-white tracking-wide">Active Paper Positions</span>
            <span className="text-[10px] px-1.5 py-0.5 rounded bg-[#00E5FF]/20 text-[#00E5FF]">
              {positions.length} Positions Active
            </span>
          </div>
          <span className="text-[11px] text-slate-400">Read-Only Experiment Execution</span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left">
            <thead>
              <tr className="border-b border-white/10 text-slate-400 text-[11px] uppercase bg-black/40">
                <th className="py-2.5 px-3">Symbol</th>
                <th className="py-2.5 px-3">Side</th>
                <th className="py-2.5 px-3">Entry Price</th>
                <th className="py-2.5 px-3">Current Price</th>
                <th className="py-2.5 px-3">PnL ($)</th>
                <th className="py-2.5 px-3">PnL (%)</th>
                <th className="py-2.5 px-3">Stop-Loss</th>
                <th className="py-2.5 px-3">Take-Profit</th>
                <th className="py-2.5 px-3">Strategy</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-white/5">
              {positions.map((pos) => {
                const isPositive = pos.pnl_usd >= 0;
                return (
                  <tr key={pos.symbol} className="hover:bg-white/[0.02] transition">
                    <td className="py-2.5 px-3 font-semibold text-white flex items-center gap-1.5">
                      <span className={`w-1.5 h-1.5 rounded-full ${pos.engine === 'binance' ? 'bg-[#9B5CFF]' : 'bg-[#00E5FF]'}`} />
                      {pos.symbol}
                    </td>
                    <td className="py-2.5 px-3">
                      <span className="px-1.5 py-0.5 rounded text-[10px] font-bold bg-[#00F5A0]/20 text-[#00F5A0]">
                        {pos.side}
                      </span>
                    </td>
                    <td className="py-2.5 px-3 text-slate-300">
                      ${pos.entry_price.toLocaleString('en-US', { minimumFractionDigits: 2 })}
                    </td>
                    <td className="py-2.5 px-3 text-white font-medium">
                      ${pos.current_price.toLocaleString('en-US', { minimumFractionDigits: 2 })}
                    </td>
                    <td className={`py-2.5 px-3 font-semibold ${isPositive ? 'text-[#00F5A0]' : 'text-[#FF4567]'}`}>
                      {isPositive ? '+' : ''}${pos.pnl_usd.toFixed(2)}
                    </td>
                    <td className={`py-2.5 px-3 font-semibold ${isPositive ? 'text-[#00F5A0]' : 'text-[#FF4567]'}`}>
                      {isPositive ? '+' : ''}{pos.pnl_pct.toFixed(2)}%
                    </td>
                    <td className="py-2.5 px-3 text-slate-400">
                      ${pos.stop_loss ? pos.stop_loss.toLocaleString() : '--'}
                    </td>
                    <td className="py-2.5 px-3 text-[#00E5FF]">
                      ${pos.take_profit ? pos.take_profit.toLocaleString() : '--'}
                    </td>
                    <td className="py-2.5 px-3 text-slate-400 text-[11px] truncate max-w-[150px]">
                      {pos.strategy}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
