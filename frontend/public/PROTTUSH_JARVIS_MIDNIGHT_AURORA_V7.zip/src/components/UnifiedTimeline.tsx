import React, { useState } from 'react';
import { 
  Bell, 
  Search, 
  Filter, 
  ExternalLink, 
  CheckCheck, 
  Clock, 
  Tag,
  AlertTriangle,
  Info,
  CheckCircle2,
  Trash2,
  Download,
  FileSpreadsheet
} from 'lucide-react';
import { UniversalNotification } from '../types/jarvis';

interface UnifiedTimelineProps {
  notifications: UniversalNotification[];
  onMarkAllRead?: () => void;
  onClearRead?: () => void;
}

export const UnifiedTimeline: React.FC<UnifiedTimelineProps> = ({
  notifications,
  onMarkAllRead,
  onClearRead
}) => {
  const [activeSource, setActiveSource] = useState<string>('all');
  const [activeSeverity, setActiveSeverity] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState('');

  const sources = ['all', 'binance', 'gate', 'telegram', 'whatsapp', 'system'];

  const filtered = notifications.filter((item) => {
    const matchesSource = activeSource === 'all' || item.source === activeSource;
    const matchesSeverity = activeSeverity === 'all' || item.severity === activeSeverity;
    const matchesSearch = 
      item.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      item.message.toLowerCase().includes(searchQuery.toLowerCase()) ||
      (item.symbol && item.symbol.toLowerCase().includes(searchQuery.toLowerCase()));

    return matchesSource && matchesSeverity && matchesSearch;
  });

  const getSeverityBadge = (severity: string) => {
    switch (severity) {
      case 'critical':
        return <span className="px-1.5 py-0.5 rounded text-[10px] bg-[#FF4567]/20 text-[#FF4567] border border-[#FF4567]/30">CRITICAL</span>;
      case 'warning':
        return <span className="px-1.5 py-0.5 rounded text-[10px] bg-[#FFB547]/20 text-[#FFB547] border border-[#FFB547]/30">WARNING</span>;
      case 'success':
        return <span className="px-1.5 py-0.5 rounded text-[10px] bg-[#00F5A0]/20 text-[#00F5A0] border border-[#00F5A0]/30">SUCCESS</span>;
      default:
        return <span className="px-1.5 py-0.5 rounded text-[10px] bg-[#00E5FF]/20 text-[#00E5FF] border border-[#00E5FF]/30">INFO</span>;
    }
  };

  const getSourceIconColor = (source: string) => {
    switch (source) {
      case 'binance': return 'text-[#9B5CFF] border-[#9B5CFF]/30 bg-[#9B5CFF]/10';
      case 'gate': return 'text-[#00E5FF] border-[#00E5FF]/30 bg-[#00E5FF]/10';
      case 'telegram': return 'text-[#0088cc] border-[#0088cc]/30 bg-[#0088cc]/10';
      case 'whatsapp': return 'text-[#25D366] border-[#25D366]/30 bg-[#25D366]/10';
      case 'system': return 'text-[#00F5A0] border-[#00F5A0]/30 bg-[#00F5A0]/10';
      default: return 'text-slate-300 border-white/10 bg-white/5';
    }
  };

  const handleDownloadJSON = () => {
    const dataStr = "data:text/json;charset=utf-8," + encodeURIComponent(JSON.stringify(filtered, null, 2));
    const downloadAnchor = document.createElement('a');
    downloadAnchor.setAttribute("href", dataStr);
    downloadAnchor.setAttribute("download", `jarvis_unified_timeline_${new Date().toISOString().slice(0, 10)}.json`);
    document.body.appendChild(downloadAnchor);
    downloadAnchor.click();
    downloadAnchor.remove();
  };

  const handleDownloadCSV = () => {
    const headers = ["ID", "Timestamp", "Source", "Severity", "Symbol", "Title", "Message", "Simulated", "DeepLink"];
    const rows = filtered.map(item => [
      `"${item.id}"`,
      `"${new Date(item.timestamp).toISOString()}"`,
      `"${item.source}"`,
      `"${item.severity}"`,
      `"${item.symbol || ''}"`,
      `"${(item.title || '').replace(/"/g, '""')}"`,
      `"${(item.message || '').replace(/"/g, '""')}"`,
      `"${item.is_simulated ? 'true' : 'false'}"`,
      `"${item.deep_link || ''}"`
    ]);
    const csvContent = "data:text/csv;charset=utf-8," + [headers.join(","), ...rows.map(e => e.join(","))].join("\n");
    const encodedUri = encodeURI(csvContent);
    const downloadAnchor = document.createElement('a');
    downloadAnchor.setAttribute("href", encodedUri);
    downloadAnchor.setAttribute("download", `jarvis_unified_timeline_${new Date().toISOString().slice(0, 10)}.csv`);
    document.body.appendChild(downloadAnchor);
    downloadAnchor.click();
    downloadAnchor.remove();
  };

  return (
    <div className="w-full space-y-4 font-mono text-xs">
      {/* Top Filter and Search Controls */}
      <div className="flex flex-wrap items-center justify-between gap-2">
        <div className="flex items-center gap-1.5 overflow-x-auto pb-1 max-w-full">
          {sources.map((src) => (
            <button
              key={src}
              onClick={() => setActiveSource(src)}
              className={`px-2.5 py-1 rounded-md text-[11px] uppercase transition border whitespace-nowrap ${
                activeSource === src
                  ? 'bg-[#00E5FF]/20 border-[#00E5FF] text-[#00E5FF] font-semibold'
                  : 'bg-black/40 border-white/10 text-slate-400 hover:text-white'
              }`}
            >
              {src}
            </button>
          ))}
        </div>

        <div className="flex items-center gap-2">
          {/* Download JSON and CSV buttons */}
          <div className="flex items-center bg-black/40 border border-white/10 rounded-md p-0.5">
            <button
              onClick={handleDownloadJSON}
              title="Download timeline as JSON"
              className="px-2 py-0.5 rounded text-[11px] text-[#00E5FF] hover:bg-[#00E5FF]/20 transition flex items-center gap-1"
            >
              <Download className="w-3 h-3" />
              <span>JSON</span>
            </button>
            <div className="h-3 w-[1px] bg-white/10 mx-0.5" />
            <button
              onClick={handleDownloadCSV}
              title="Download timeline as CSV"
              className="px-2 py-0.5 rounded text-[11px] text-[#00F5A0] hover:bg-[#00F5A0]/20 transition flex items-center gap-1"
            >
              <FileSpreadsheet className="w-3 h-3" />
              <span>CSV</span>
            </button>
          </div>

          {onMarkAllRead && (
            <button
              onClick={onMarkAllRead}
              className="px-2.5 py-1 rounded bg-white/5 hover:bg-white/10 text-slate-300 border border-white/10 flex items-center gap-1 text-[11px] transition"
            >
              <CheckCheck className="w-3.5 h-3.5" />
              <span>Mark Read</span>
            </button>
          )}
        </div>
      </div>

      {/* Search Input */}
      <div className="relative">
        <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
        <input
          type="text"
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          placeholder="Filter event timeline by symbol, topic, or source..."
          className="w-full pl-9 pr-3 py-1.5 rounded-lg bg-black/50 border border-white/10 text-white placeholder-slate-500 focus:outline-none focus:border-[#00E5FF] text-xs"
        />
      </div>

      {/* Stream List */}
      <div className="space-y-2.5 max-h-[380px] overflow-y-auto pr-1">
        {filtered.length > 0 ? (
          filtered.map((item) => (
            <div
              key={item.id}
              className={`p-3 rounded-xl border transition flex flex-col md:flex-row md:items-center justify-between gap-3 ${
                item.read 
                  ? 'bg-black/30 border-white/5 opacity-80' 
                  : 'bg-gradient-to-r from-[#081225] to-black/60 border-[#00E5FF]/25 shadow-[0_4px_16px_rgba(0,0,0,0.3)]'
              }`}
            >
              <div className="flex items-start gap-3">
                <div className={`w-8 h-8 rounded-lg border flex items-center justify-center shrink-0 uppercase font-bold text-[10px] ${getSourceIconColor(item.source)}`}>
                  {item.source.slice(0, 3)}
                </div>

                <div>
                  <div className="flex items-center gap-2 flex-wrap">
                    <span className="font-semibold text-white text-[13px]">{item.title}</span>
                    {getSeverityBadge(item.severity)}
                    {item.symbol && (
                      <span className="px-1.5 py-0.5 rounded text-[10px] bg-white/5 text-slate-300 border border-white/10">
                        ${item.symbol}
                      </span>
                    )}
                    {item.is_simulated && (
                      <span className="text-[9px] text-[#00E5FF]/70">DEMO/SIM</span>
                    )}
                  </div>
                  <p className="text-slate-300 text-xs mt-1 leading-relaxed">
                    {item.message}
                  </p>
                  <div className="flex items-center gap-2 text-[10px] text-slate-500 mt-1">
                    <Clock className="w-3 h-3" />
                    <span>{new Date(item.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</span>
                  </div>
                </div>
              </div>

              {item.deep_link && (
                <a
                  href={item.deep_link}
                  target="_blank"
                  rel="noreferrer"
                  className="shrink-0 self-end md:self-center px-2.5 py-1 rounded bg-[#00E5FF]/10 hover:bg-[#00E5FF]/20 text-[#00E5FF] border border-[#00E5FF]/30 transition flex items-center gap-1 text-[11px]"
                >
                  <span>Inspect</span>
                  <ExternalLink className="w-3 h-3" />
                </a>
              )}
            </div>
          ))
        ) : (
          <div className="p-8 text-center text-slate-500 border border-dashed border-white/10 rounded-xl">
            No events found matching the active filters
          </div>
        )}
      </div>
    </div>
  );
};
