import React, { useState } from 'react';
import { 
  Radar, 
  TrendingUp, 
  ShieldCheck, 
  ExternalLink, 
  Zap, 
  Bot, 
  ArrowUpRight, 
  ArrowDownRight,
  Filter,
  Layers,
  Crosshair
} from 'lucide-react';
import { GateOverview, GateSolanaDiscovery } from '../types/jarvis';

interface ScannerRadarProps {
  gateOverview: GateOverview;
  onSelectDiscovery?: (item: GateSolanaDiscovery) => void;
}

export const ScannerRadar: React.FC<ScannerRadarProps> = ({
  gateOverview,
  onSelectDiscovery
}) => {
  const [selectedBlip, setSelectedBlip] = useState<GateSolanaDiscovery | null>(null);
  const [filterPassedOnly, setFilterPassedOnly] = useState(true);

  const discoveries = gateOverview.discoveries || [];
  const filtered = filterPassedOnly 
    ? discoveries.filter(d => d.anti_rug_status === 'PASSED') 
    : discoveries;

  // Radar coordinates mapping: compute polar angle and distance
  const blipPositions = [
    { x: '35%', y: '40%' },
    { x: '68%', y: '28%' },
    { x: '58%', y: '72%' },
    { x: '24%', y: '65%' },
    { x: '78%', y: '60%' }
  ];

  return (
    <div className="w-full flex flex-col gap-4">
      {/* Top Controls Bar */}
      <div className="flex flex-wrap items-center justify-between gap-2 text-xs font-mono">
        <div className="flex items-center gap-2">
          <span className="flex items-center gap-1.5 text-[#00E5FF]">
            <Radar className="w-4 h-4 animate-spin text-[#00E5FF]" style={{ animationDuration: '8s' }} />
            <span className="font-bold text-sm tracking-wide">Raydium & Solana DEX Radar</span>
          </span>
          <span className="px-2 py-0.5 rounded-full bg-[#00F5A0]/10 border border-[#00F5A0]/30 text-[#00F5A0] text-[10px]">
            {filtered.length} ACTIVE BLIPS
          </span>
        </div>

        <div className="flex items-center gap-2">
          <button 
            onClick={() => setFilterPassedOnly(!filterPassedOnly)}
            className={`px-2 py-1 rounded text-[11px] border transition flex items-center gap-1 ${
              filterPassedOnly 
                ? 'bg-[#00E5FF]/20 border-[#00E5FF] text-[#00E5FF]' 
                : 'bg-white/5 border-white/10 text-slate-400'
            }`}
          >
            <Filter className="w-3 h-3" />
            <span>Anti-Rug Validated Only</span>
          </button>
          <a 
            href="https://trading.prottushjd.tech/" 
            target="_blank" 
            rel="noreferrer"
            className="flex items-center gap-1 text-[11px] text-[#9B5CFF] hover:underline"
          >
            <span>Gate Hub</span>
            <ExternalLink className="w-3 h-3" />
          </a>
        </div>
      </div>

      {/* Radar Visual Scanner */}
      <div className="relative w-full h-[280px] rounded-xl border border-[#00E5FF]/25 bg-gradient-to-b from-[#030611] via-[#081225] to-[#030611] overflow-hidden flex items-center justify-center">
        {/* Radar Concentric Circles */}
        <div className="absolute w-[240px] h-[240px] rounded-full border border-[#00E5FF]/15 pointer-events-none" />
        <div className="absolute w-[170px] h-[170px] rounded-full border border-[#00E5FF]/20 pointer-events-none" />
        <div className="absolute w-[100px] h-[100px] rounded-full border border-[#00E5FF]/25 pointer-events-none" />
        
        {/* Crosshairs */}
        <div className="absolute w-full h-[1px] bg-[#00E5FF]/10 pointer-events-none" />
        <div className="absolute h-full w-[1px] bg-[#00E5FF]/10 pointer-events-none" />
        <div className="absolute w-full h-[1px] rotate-45 bg-[#00E5FF]/5 pointer-events-none" />
        <div className="absolute w-full h-[1px] -rotate-45 bg-[#00E5FF]/5 pointer-events-none" />

        {/* Sweeping Conic Beam */}
        <div 
          className="absolute w-[240px] h-[240px] rounded-full pointer-events-none animate-radar-sweep"
          style={{
            background: 'conic-gradient(from 0deg, transparent 0deg, transparent 270deg, rgba(0, 229, 255, 0.35) 360deg)'
          }}
        />

        {/* Center Scanner Nucleus */}
        <div className="w-3 h-3 rounded-full bg-[#00E5FF] shadow-[0_0_12px_#00E5FF] z-10 flex items-center justify-center">
          <div className="w-1 h-1 rounded-full bg-white" />
        </div>

        {/* Interactive Radar Blips */}
        {filtered.map((item, idx) => {
          const pos = blipPositions[idx % blipPositions.length];
          const isSelected = selectedBlip?.id === item.id;
          return (
            <button
              key={item.id}
              onClick={() => {
                setSelectedBlip(item);
                if (onSelectDiscovery) onSelectDiscovery(item);
              }}
              className="absolute z-20 group -translate-x-1/2 -translate-y-1/2 focus:outline-none transition-transform hover:scale-125"
              style={{ left: pos.x, top: pos.y }}
              title={`${item.symbol} (${item.token_name})`}
            >
              <div className="relative flex items-center justify-center">
                <span className="absolute w-4 h-4 rounded-full bg-[#00F5A0]/40 animate-ping" />
                <span className={`w-3 h-3 rounded-full border border-black shadow-[0_0_8px_#00F5A0] ${
                  isSelected ? 'bg-white scale-125 ring-2 ring-[#00E5FF]' : 'bg-[#00F5A0]'
                }`} />
                {/* Floating label */}
                <span className="absolute left-4 top-0 whitespace-nowrap bg-black/80 backdrop-blur-sm px-1.5 py-0.5 rounded border border-[#00E5FF]/30 text-[10px] font-mono text-[#00E5FF] pointer-events-none opacity-0 group-hover:opacity-100 transition-opacity">
                  {item.symbol}
                </span>
              </div>
            </button>
          );
        })}

        {/* Contextual Blip Inspection Card */}
        {selectedBlip ? (
          <div className="absolute bottom-3 left-3 right-3 md:right-auto md:max-w-sm z-30 p-3 rounded-lg bg-[#081225]/95 border border-[#00E5FF]/40 backdrop-blur-md shadow-xl text-xs font-mono animate-in slide-in-from-bottom-2 duration-150">
            <div className="flex items-center justify-between text-[#00E5FF] mb-1">
              <span className="font-bold flex items-center gap-1">
                <Crosshair className="w-3.5 h-3.5" />
                {selectedBlip.symbol} · {selectedBlip.token_name}
              </span>
              <button 
                onClick={() => setSelectedBlip(null)}
                className="text-slate-400 hover:text-white text-xs px-1"
              >
                ✕
              </button>
            </div>
            <div className="grid grid-cols-2 gap-2 text-[11px] text-slate-300 mt-1">
              <div>DEX: <span className="text-white">{selectedBlip.dex}</span></div>
              <div>TVL: <span className="text-[#00F5A0] font-semibold">${(selectedBlip.liquidity_usd / 1000).toFixed(0)}k</span></div>
              <div>Safety Score: <span className="text-[#00E5FF] font-semibold">{selectedBlip.safety_score}/100</span></div>
              <div>Status: <span className="text-[#00F5A0] font-semibold">{selectedBlip.anti_rug_status}</span></div>
            </div>
            <div className="text-[10px] text-slate-400 mt-1 truncate">
              Pool: {selectedBlip.pool_address}
            </div>
          </div>
        ) : (
          <div className="absolute bottom-2 left-3 text-[10px] font-mono text-slate-500 pointer-events-none">
            Click any green blip to audit pool telemetry
          </div>
        )}
      </div>

      {/* Discovery Feed Summary */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-2">
        {filtered.slice(0, 3).map((disc) => (
          <div 
            key={disc.id}
            onClick={() => setSelectedBlip(disc)}
            className="p-2.5 rounded-lg bg-black/40 border border-white/10 hover:border-[#00E5FF]/40 cursor-pointer transition flex items-center justify-between text-xs font-mono"
          >
            <div>
              <div className="text-white font-bold flex items-center gap-1.5">
                <span>{disc.symbol}</span>
                <span className="text-[10px] text-[#00F5A0] px-1 bg-[#00F5A0]/10 rounded">
                  Score {disc.safety_score}
                </span>
              </div>
              <div className="text-[10px] text-slate-400 mt-0.5">{disc.dex} · {disc.time_ago}</div>
            </div>
            <div className="text-right">
              <div className="text-slate-200">${disc.price_usd}</div>
              <div className="text-[10px] text-slate-400">${(disc.liquidity_usd / 1000000).toFixed(2)}M Liq</div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
