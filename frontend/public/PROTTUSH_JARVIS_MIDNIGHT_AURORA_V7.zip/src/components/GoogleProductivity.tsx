import React from 'react';
import { 
  Mail, 
  Calendar as CalendarIcon, 
  HardDrive, 
  CheckSquare, 
  ExternalLink, 
  ShieldCheck, 
  Lock,
  Search,
  CheckCircle2,
  Clock
} from 'lucide-react';
import { GoogleIntegrationStatus } from '../types/jarvis';

interface GoogleProductivityProps {
  status: GoogleIntegrationStatus;
}

export const GoogleProductivity: React.FC<GoogleProductivityProps> = ({ status }) => {
  return (
    <div className="w-full space-y-4 font-mono text-xs">
      {/* Integration Header & Account Card */}
      <div className="p-3.5 rounded-xl bg-gradient-to-r from-[#EA4335]/15 via-black/40 to-transparent border border-[#EA4335]/30 flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center gap-3">
          <div className="w-9 h-9 rounded-full bg-[#EA4335]/20 border border-[#EA4335]/40 flex items-center justify-center text-[#EA4335] font-bold text-sm">
            G
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="font-bold text-white text-sm">Google Workspace Integration</span>
              <span className="px-1.5 py-0.5 rounded text-[10px] bg-[#00F5A0]/20 text-[#00F5A0] border border-[#00F5A0]/30 flex items-center gap-1">
                <ShieldCheck className="w-3 h-3" />
                AUTHORIZED · MINIMAL SCOPES
              </span>
            </div>
            <div className="text-[11px] text-slate-400 mt-0.5">
              Account: <span className="text-white">{status.email}</span> · Scopes: <span className="text-slate-300">Gmail, Calendar, Drive, Tasks (Read-Only)</span>
            </div>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <a
            href="https://mail.google.com"
            target="_blank"
            rel="noreferrer"
            className="px-3 py-1.5 rounded-lg bg-white/5 hover:bg-white/10 border border-white/10 text-white transition flex items-center gap-1.5 text-xs"
          >
            <span>Gmail</span>
            <ExternalLink className="w-3 h-3 text-slate-400" />
          </a>
          <a
            href="https://calendar.google.com"
            target="_blank"
            rel="noreferrer"
            className="px-3 py-1.5 rounded-lg bg-white/5 hover:bg-white/10 border border-white/10 text-white transition flex items-center gap-1.5 text-xs"
          >
            <span>Calendar</span>
            <ExternalLink className="w-3 h-3 text-slate-400" />
          </a>
        </div>
      </div>

      {/* 4-Pillar Grid: Gmail, Calendar, Drive, Tasks */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-3">
        {/* Gmail Unread */}
        <div className="p-3 rounded-xl bg-black/30 border border-white/10 flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between text-[#EA4335] font-semibold mb-2">
              <span className="flex items-center gap-1.5">
                <Mail className="w-3.5 h-3.5" />
                <span>Inbox Telemetry</span>
              </span>
              <span className="px-1.5 py-0.5 rounded bg-[#EA4335]/20 text-[#EA4335] text-[10px]">
                {status.gmail.unread_count} Unread
              </span>
            </div>
            <div className="space-y-2 mt-2">
              {status.gmail.threads.map((t, idx) => (
                <div key={idx} className="p-2 rounded bg-black/40 border border-white/5 text-[11px]">
                  <div className="text-white font-medium truncate">{t.from}</div>
                  <div className="text-slate-300 text-[10px] truncate">{t.subject}</div>
                  <div className="text-slate-500 text-[9px] mt-0.5">{t.date}</div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Google Calendar */}
        <div className="p-3 rounded-xl bg-black/30 border border-white/10 flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between text-[#4285F4] font-semibold mb-2">
              <span className="flex items-center gap-1.5">
                <CalendarIcon className="w-3.5 h-3.5" />
                <span>Agenda Stream</span>
              </span>
              <span className="px-1.5 py-0.5 rounded bg-[#4285F4]/20 text-[#4285F4] text-[10px]">
                Upcoming
              </span>
            </div>
            <div className="space-y-2 mt-2">
              {status.calendar.upcoming_events.map((e, idx) => (
                <div key={idx} className="p-2 rounded bg-black/40 border border-white/5 text-[11px]">
                  <div className="text-white font-medium truncate">{e.summary}</div>
                  <div className="text-[#00E5FF] text-[10px] flex items-center gap-1 mt-0.5">
                    <Clock className="w-2.5 h-2.5" />
                    <span>{e.start}</span>
                  </div>
                  {e.location && <div className="text-slate-400 text-[9px]">{e.location}</div>}
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Google Drive */}
        <div className="p-3 rounded-xl bg-black/30 border border-white/10 flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between text-[#34A853] font-semibold mb-2">
              <span className="flex items-center gap-1.5">
                <HardDrive className="w-3.5 h-3.5" />
                <span>Recent Files</span>
              </span>
              <span className="px-1.5 py-0.5 rounded bg-[#34A853]/20 text-[#34A853] text-[10px]">
                Drive
              </span>
            </div>
            <div className="space-y-2 mt-2">
              {status.drive.recent_files.map((f, idx) => (
                <div key={idx} className="p-2 rounded bg-black/40 border border-white/5 text-[11px]">
                  <div className="text-white font-medium truncate">{f.name}</div>
                  <div className="text-slate-400 text-[10px] mt-0.5 flex justify-between">
                    <span className="capitalize">{f.type}</span>
                    <span>{f.modified}</span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Google Tasks */}
        <div className="p-3 rounded-xl bg-black/30 border border-white/10 flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between text-[#FBBC05] font-semibold mb-2">
              <span className="flex items-center gap-1.5">
                <CheckSquare className="w-3.5 h-3.5" />
                <span>Pending Tasks</span>
              </span>
              <span className="px-1.5 py-0.5 rounded bg-[#FBBC05]/20 text-[#FBBC05] text-[10px]">
                Tasks
              </span>
            </div>
            <div className="space-y-2 mt-2">
              {status.tasks.pending_tasks.map((task, idx) => (
                <div key={idx} className="p-2 rounded bg-black/40 border border-white/5 text-[11px] flex items-start gap-1.5">
                  <CheckCircle2 className={`w-3.5 h-3.5 mt-0.5 shrink-0 ${task.completed ? 'text-[#00F5A0]' : 'text-slate-500'}`} />
                  <div>
                    <div className={`truncate ${task.completed ? 'line-through text-slate-500' : 'text-white'}`}>
                      {task.title}
                    </div>
                    {task.due && <div className="text-[#FFB547] text-[9px]">Due: {task.due}</div>}
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
