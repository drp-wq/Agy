import React, { useState } from 'react';
import { 
  ChevronDown, 
  ChevronUp, 
  Maximize2, 
  Minimize2, 
  HelpCircle,
  LucideIcon
} from 'lucide-react';

interface SpatialWidgetProps {
  id: string;
  title: string;
  subtitle?: string;
  icon: LucideIcon;
  badge?: {
    text: string;
    variant: 'live' | 'sim' | 'warning' | 'alert' | 'neutral';
  };
  isCollapsed: boolean;
  onToggleCollapse: () => void;
  headerActions?: React.ReactNode;
  children: React.ReactNode;
  className?: string;
}

export const SpatialWidget: React.FC<SpatialWidgetProps> = ({
  id,
  title,
  subtitle,
  icon: Icon,
  badge,
  isCollapsed,
  onToggleCollapse,
  headerActions,
  children,
  className = ''
}) => {
  const [isFullScreen, setIsFullScreen] = useState(false);

  const getBadgeClass = (variant?: string) => {
    switch (variant) {
      case 'live':
        return 'bg-[#00F5A0]/10 border-[#00F5A0]/40 text-[#00F5A0]';
      case 'sim':
        return 'bg-[#00E5FF]/10 border-[#00E5FF]/40 text-[#00E5FF]';
      case 'warning':
        return 'bg-[#FFB547]/10 border-[#FFB547]/40 text-[#FFB547]';
      case 'alert':
        return 'bg-[#FF4567]/10 border-[#FF4567]/40 text-[#FF4567]';
      default:
        return 'bg-white/5 border-white/10 text-slate-300';
    }
  };

  return (
    <div 
      id={id}
      className={`glass-panel glass-panel-hover rounded-xl border border-[#00E5FF]/20 transition-all duration-300 overflow-hidden ${
        isFullScreen ? 'fixed inset-4 z-50 overflow-y-auto bg-[#081225]/98' : ''
      } ${className}`}
    >
      {/* Widget Header */}
      <div className="p-4 flex items-center justify-between border-b border-white/5 bg-gradient-to-r from-white/[0.02] to-transparent select-none">
        <div 
          className="flex items-center gap-3 cursor-pointer group flex-1"
          onClick={onToggleCollapse}
        >
          <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-[#00E5FF]/20 to-[#387BFF]/20 border border-[#00E5FF]/30 flex items-center justify-center text-[#00E5FF] group-hover:scale-105 transition-transform">
            <Icon className="w-4 h-4" />
          </div>

          <div>
            <div className="flex items-center gap-2">
              <span className="font-semibold text-sm lg:text-base text-white tracking-wide font-cyber">
                {title}
              </span>
              {badge && (
                <span className={`text-[10px] px-2 py-0.5 rounded border font-mono font-medium ${getBadgeClass(badge.variant)}`}>
                  {badge.text}
                </span>
              )}
            </div>
            {subtitle && (
              <p className="text-[11px] text-slate-400 font-mono mt-0.5 truncate max-w-xs md:max-w-md">
                {subtitle}
              </p>
            )}
          </div>
        </div>

        {/* Header Action Controls */}
        <div className="flex items-center gap-1.5 ml-2">
          {headerActions}

          <button
            onClick={() => setIsFullScreen(!isFullScreen)}
            className="p-1.5 text-slate-400 hover:text-white rounded hover:bg-white/5 transition"
            title={isFullScreen ? "Exit Fullscreen" : "Fullscreen View"}
          >
            {isFullScreen ? <Minimize2 className="w-3.5 h-3.5" /> : <Maximize2 className="w-3.5 h-3.5" />}
          </button>

          <button
            onClick={onToggleCollapse}
            className="p-1.5 text-slate-400 hover:text-white rounded hover:bg-white/5 transition"
            title={isCollapsed ? "Expand Panel" : "Collapse Panel"}
          >
            {isCollapsed ? <ChevronDown className="w-4 h-4" /> : <ChevronUp className="w-4 h-4" />}
          </button>
        </div>
      </div>

      {/* Widget Content Body with Smooth Expand/Collapse */}
      {!isCollapsed && (
        <div className="p-4 animate-in fade-in slide-in-from-top-1 duration-200">
          {children}
        </div>
      )}
    </div>
  );
};
