import React, { useState } from 'react';
import { 
  Send, 
  ExternalLink, 
  Bot, 
  Search, 
  Filter, 
  AlertTriangle, 
  CheckCircle2, 
  Info, 
  ShieldCheck,
  Bell,
  RefreshCw
} from 'lucide-react';
import { TelegramBotStatus } from '../types/jarvis';

interface TelegramIntelligenceProps {
  status: TelegramBotStatus;
  onRefresh?: () => void;
}

export const TelegramIntelligence: React.FC<TelegramIntelligenceProps> = ({
  status,
  onRefresh
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [filterPaperTrading, setFilterPaperTrading] = useState(false);

  const alerts = status.recent_alerts || [];
  const filteredAlerts = alerts.filter(a => {
    const matchesSearch = a.text.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesPaper = filterPaperTrading ? a.is_paper_trading : true;
    return matchesSearch && matchesPaper;
  });

  return (
    <div className="w-full space-y-4 font-mono">
      {/* Bot Status & Overview Header */}
      <div className="p-3.5 rounded-xl bg-gradient-to-r from-[#0088cc]/15 via-black/40 to-transparent border border-[#0088cc]/30 flex flex-wrap items-center justify-between gap-3 text-xs">
        <div className="flex items-center gap-3">
          <div className="w-9 h-9 rounded-full bg-[#0088cc]/20 border border-[#0088cc]/40 flex items-center justify-center text-[#0088cc]">
            <Send className="w-4 h-4 -rotate-45" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="font-bold text-white text-sm">Telegram Bot Telemetry Stream</span>
              <span className="px-1.5 py-0.5 rounded text-[10px] bg-[#00F5A0]/20 text-[#00F5A0] border border-[#00F5A0]/30">
                ACTIVE DAEMON
              </span>
            </div>
            <div className="text-[11px] text-slate-400 mt-0.5">
              Service: <span className="text-slate-200">prottush-binance-telegram</span> · Polling Channel: <span className="text-[#0088cc]">{status.bot_username}</span>
            </div>
          </div>
        </div>

        <div className="flex items-center gap-2">
          {onRefresh && (
            <button 
              onClick={onRefresh}
              className="p-1.5 rounded bg-white/5 border border-white/10 text-slate-300 hover:text-white transition"
              title="Refresh Telegram alerts"
            >
              <RefreshCw className="w-3.5 h-3.5" />
            </button>
          )}
          <a
            href="https://t.me"
            target="_blank"
            rel="noreferrer"
            className="px-3 py-1.5 rounded-lg bg-[#0088cc]/20 hover:bg-[#0088cc]/30 border border-[#0088cc]/40 text-[#0088cc] transition flex items-center gap-1.5 text-xs font-semibold"
          >
            <span>Launch Web Telegram</span>
            <ExternalLink className="w-3 h-3" />
          </a>
        </div>
      </div>

      {/* Search and Filters */}
      <div className="flex flex-wrap items-center justify-between gap-2 text-xs">
        <div className="relative flex-1 min-w-[200px]">
          <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search alerts by symbol, keyword, or trade ID..."
            className="w-full pl-9 pr-3 py-1.5 rounded-lg bg-black/50 border border-white/10 text-white placeholder-slate-500 focus:outline-none focus:border-[#0088cc] text-xs"
          />
        </div>

        <button
          onClick={() => setFilterPaperTrading(!filterPaperTrading)}
          className={`px-2.5 py-1.5 rounded-lg border text-xs transition flex items-center gap-1.5 ${
            filterPaperTrading
              ? 'bg-[#0088cc]/20 border-[#0088cc] text-[#0088cc]'
              : 'bg-white/5 border-white/10 text-slate-400'
          }`}
        >
          <Filter className="w-3 h-3" />
          <span>Paper Trading Alerts Only</span>
        </button>
      </div>

      {/* Alert Stream List */}
      <div className="space-y-2">
        {filteredAlerts.length > 0 ? (
          filteredAlerts.map((alert) => (
            <div
              key={alert.id}
              className="p-3 rounded-lg bg-black/40 border border-white/10 hover:border-[#0088cc]/40 transition text-xs flex flex-col md:flex-row md:items-center justify-between gap-2"
            >
              <div className="flex items-start gap-2.5">
                <span className="w-2 h-2 rounded-full bg-[#0088cc] mt-1 shrink-0" />
                <div>
                  <div className="text-white leading-relaxed">{alert.text}</div>
                  <div className="flex items-center gap-3 text-[10px] text-slate-400 mt-1">
                    <span>Chat ID: {alert.chat_id}</span>
                    <span>•</span>
                    <span>{new Date(alert.timestamp).toLocaleTimeString()}</span>
                    {alert.is_paper_trading && (
                      <span className="text-[#00E5FF] px-1 bg-[#00E5FF]/10 rounded">
                        Paper Trading Tagged
                      </span>
                    )}
                  </div>
                </div>
              </div>

              <div className="shrink-0 self-end md:self-center">
                <span className="px-2 py-0.5 rounded text-[10px] bg-white/5 text-slate-400 border border-white/10">
                  VERIFIED DISPATCH
                </span>
              </div>
            </div>
          ))
        ) : (
          <div className="p-6 text-center text-slate-500 border border-dashed border-white/10 rounded-lg">
            No Telegram alerts matching current query
          </div>
        )}
      </div>
    </div>
  );
};
