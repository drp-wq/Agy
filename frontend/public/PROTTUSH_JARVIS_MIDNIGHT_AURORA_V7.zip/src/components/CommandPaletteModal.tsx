import React, { useState, useEffect } from 'react';
import { 
  Search, 
  Terminal, 
  Radio, 
  TrendingUp, 
  Send, 
  MessageSquare, 
  Calendar, 
  Cpu, 
  Sliders, 
  X,
  ArrowRight,
  Sparkles
} from 'lucide-react';
import { GraphicsMode } from '../types/jarvis';

interface CommandPaletteModalProps {
  isOpen: boolean;
  onClose: () => void;
  onNavigateSection: (sectionId: string) => void;
  graphicsMode: GraphicsMode;
  onChangeGraphicsMode: (mode: GraphicsMode) => void;
}

interface CommandItem {
  id: string;
  category: 'Navigation' | 'Trading' | 'Communications' | 'Graphics & System';
  title: string;
  description: string;
  icon: React.ElementType;
  action: () => void;
}

export const CommandPaletteModal: React.FC<CommandPaletteModalProps> = ({
  isOpen,
  onClose,
  onNavigateSection,
  graphicsMode,
  onChangeGraphicsMode
}) => {
  const [query, setQuery] = useState('');
  const [selectedIndex, setSelectedIndex] = useState(0);

  const commands: CommandItem[] = [
    {
      id: 'cmd-core',
      category: 'Navigation',
      title: 'Navigate to JARVIS Central Intelligence',
      description: 'Scroll to 3D Holographic Core & Telemetry Radar',
      icon: Radio,
      action: () => onNavigateSection('sec-jarvis-core')
    },
    {
      id: 'cmd-trading',
      category: 'Trading',
      title: 'Inspect Binance & Gate.io Telemetry',
      description: 'View active paper positions, PnL curve, and equity',
      icon: TrendingUp,
      action: () => onNavigateSection('sec-trading')
    },
    {
      id: 'cmd-radar',
      category: 'Trading',
      title: 'Activate Solana Scanner Radar',
      description: 'Audit fresh Raydium & Meteora liquidity pools',
      icon: Radio,
      action: () => onNavigateSection('sec-radar')
    },
    {
      id: 'cmd-telegram',
      category: 'Communications',
      title: 'Open Telegram Alert Stream',
      description: 'Check active notifications from @ProttushAlertsBot',
      icon: Send,
      action: () => onNavigateSection('sec-telegram')
    },
    {
      id: 'cmd-whatsapp',
      category: 'Communications',
      title: 'Launch WhatsApp Web Companion',
      description: 'Access quick-dial contact launcher & Alpha groups',
      icon: MessageSquare,
      action: () => onNavigateSection('sec-whatsapp')
    },
    {
      id: 'cmd-google',
      category: 'Navigation',
      title: 'Open Google Productivity Suite',
      description: 'Review unread Gmail, Calendar agenda, and Drive files',
      icon: Calendar,
      action: () => onNavigateSection('sec-google')
    },
    {
      id: 'cmd-system',
      category: 'Graphics & System',
      title: 'Check VPS Hardware Diagnostics',
      description: 'Inspect CPU load, NVMe disk, and Docker microservices',
      icon: Cpu,
      action: () => onNavigateSection('sec-system')
    },
    {
      id: 'cmd-gfx-cinematic',
      category: 'Graphics & System',
      title: 'Set Graphics Mode: Cinematic (Full 3D)',
      description: 'High-res WebGL shaders, orbital particle cloud, 60 FPS',
      icon: Sparkles,
      action: () => onChangeGraphicsMode('cinematic')
    },
    {
      id: 'cmd-gfx-balanced',
      category: 'Graphics & System',
      title: 'Set Graphics Mode: Balanced',
      description: 'Optimized lighting and moderate particle density',
      icon: Sliders,
      action: () => onChangeGraphicsMode('balanced')
    },
    {
      id: 'cmd-gfx-perf',
      category: 'Graphics & System',
      title: 'Set Graphics Mode: Performance (Low Power)',
      description: '2D lightweight acceleration, minimal battery use',
      icon: Terminal,
      action: () => onChangeGraphicsMode('performance')
    }
  ];

  const filtered = commands.filter(c => 
    c.title.toLowerCase().includes(query.toLowerCase()) ||
    c.description.toLowerCase().includes(query.toLowerCase()) ||
    c.category.toLowerCase().includes(query.toLowerCase())
  );

  useEffect(() => {
    setSelectedIndex(0);
  }, [query]);

  // Keyboard navigation
  useEffect(() => {
    if (!isOpen) return;

    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        onClose();
      } else if (e.key === 'ArrowDown') {
        e.preventDefault();
        setSelectedIndex(prev => (prev + 1) % (filtered.length || 1));
      } else if (e.key === 'ArrowUp') {
        e.preventDefault();
        setSelectedIndex(prev => (prev - 1 + filtered.length) % (filtered.length || 1));
      } else if (e.key === 'Enter') {
        e.preventDefault();
        if (filtered[selectedIndex]) {
          filtered[selectedIndex].action();
          onClose();
        }
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isOpen, filtered, selectedIndex, onClose]);

  if (!isOpen) return null;

  return (
    <div 
      className="fixed inset-0 z-50 flex items-start justify-center pt-20 px-4 bg-black/80 backdrop-blur-md animate-in fade-in duration-150"
      onClick={onClose}
    >
      <div 
        className="w-full max-w-xl rounded-2xl bg-[#081225]/95 border border-[#00E5FF]/40 shadow-[0_20px_60px_rgba(0,0,0,0.8),0_0_30px_rgba(0,229,255,0.2)] overflow-hidden font-mono"
        onClick={e => e.stopPropagation()}
      >
        {/* Search Input Bar */}
        <div className="p-4 border-b border-white/10 flex items-center gap-3">
          <Terminal className="w-5 h-5 text-[#00E5FF] shrink-0" />
          <input
            type="text"
            autoFocus
            value={query}
            onChange={e => setQuery(e.target.value)}
            placeholder="Type a command, section name, or mode..."
            className="w-full bg-transparent text-white placeholder-slate-500 text-sm focus:outline-none"
          />
          <button 
            onClick={onClose}
            className="text-slate-400 hover:text-white p-1 rounded"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Command List */}
        <div className="max-h-[360px] overflow-y-auto p-2 space-y-1">
          {filtered.length > 0 ? (
            filtered.map((cmd, idx) => {
              const Icon = cmd.icon;
              const isSelected = idx === selectedIndex;
              return (
                <div
                  key={cmd.id}
                  onClick={() => {
                    cmd.action();
                    onClose();
                  }}
                  onMouseEnter={() => setSelectedIndex(idx)}
                  className={`p-3 rounded-xl cursor-pointer flex items-center justify-between transition ${
                    isSelected 
                      ? 'bg-[#00E5FF]/15 border border-[#00E5FF]/40 text-white' 
                      : 'hover:bg-white/5 border border-transparent text-slate-300'
                  }`}
                >
                  <div className="flex items-center gap-3">
                    <div className={`p-2 rounded-lg border ${
                      isSelected ? 'border-[#00E5FF]/50 text-[#00E5FF] bg-black/40' : 'border-white/10 text-slate-400'
                    }`}>
                      <Icon className="w-4 h-4" />
                    </div>
                    <div>
                      <div className="text-xs font-semibold text-white flex items-center gap-2">
                        <span>{cmd.title}</span>
                        <span className="text-[10px] text-slate-400 px-1.5 py-0.2 rounded bg-black/40 border border-white/5">
                          {cmd.category}
                        </span>
                      </div>
                      <div className="text-[11px] text-slate-400 mt-0.5">{cmd.description}</div>
                    </div>
                  </div>

                  {isSelected && (
                    <ArrowRight className="w-4 h-4 text-[#00E5FF]" />
                  )}
                </div>
              );
            })
          ) : (
            <div className="p-8 text-center text-slate-500 text-xs">
              No JARVIS commands match "{query}"
            </div>
          )}
        </div>

        {/* Modal Footer Hotkey Hint */}
        <div className="p-2.5 bg-black/60 border-t border-white/5 flex items-center justify-between text-[11px] text-slate-400 px-4">
          <div className="flex items-center gap-3">
            <span><kbd className="px-1.5 py-0.5 bg-white/10 rounded">↑↓</kbd> Navigate</span>
            <span><kbd className="px-1.5 py-0.5 bg-white/10 rounded">↵</kbd> Execute</span>
            <span><kbd className="px-1.5 py-0.5 bg-white/10 rounded">ESC</kbd> Close</span>
          </div>
          <span className="text-[#00E5FF]">JARVIS Command Center V7</span>
        </div>
      </div>
    </div>
  );
};
