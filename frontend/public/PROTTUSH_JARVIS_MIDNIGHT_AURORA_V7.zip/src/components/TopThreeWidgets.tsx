import React, { useState, useEffect } from 'react';
import { 
  Clock, 
  CloudSun, 
  Activity, 
  Cpu, 
  Database, 
  HardDrive, 
  RefreshCw, 
  MapPin, 
  Thermometer,
  Wind,
  Droplets,
  Calendar,
  ChevronDown,
  ChevronUp,
  Server
} from 'lucide-react';
import { SystemMetrics } from '../types/jarvis';

interface TopThreeWidgetsProps {
  metrics: SystemMetrics;
  onRefreshMetrics: () => void;
}

export const TopThreeWidgets: React.FC<TopThreeWidgetsProps> = ({
  metrics,
  onRefreshMetrics
}) => {
  // Clock state
  const [time, setTime] = useState<Date>(new Date());
  const [showDiagnostics, setShowDiagnostics] = useState(false);

  // Weather state (Fixed clipped layout, real coordinates fallback)
  const [weatherData, setWeatherData] = useState({
    city: 'Hostinger VPS / London',
    temp: 18.5,
    condition: 'Clear Sky · Optimal',
    high: 21,
    low: 14,
    humidity: 48,
    windKmh: 12,
    loading: false
  });

  useEffect(() => {
    const timer = setInterval(() => setTime(new Date()), 1000);
    return () => clearInterval(timer);
  }, []);

  const timeString = time.toLocaleTimeString('en-US', {
    hour12: false,
    hour: '2-digit',
    minute: '2-digit',
    second: '2-digit'
  });

  const dateString = time.toLocaleDateString('en-US', {
    weekday: 'short',
    month: 'short',
    day: 'numeric',
    year: 'numeric'
  });

  const timezone = Intl.DateTimeFormat().resolvedOptions().timeZone;

  return (
    <div className="w-full grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
      {/* 1. CLOCK WIDGET (REPAIRED: Compact, elegant, timezone-aware, responsive) */}
      <div className="glass-panel rounded-xl p-4 flex flex-col justify-between border border-[#00E5FF]/20 relative overflow-hidden group">
        <div className="flex items-center justify-between text-xs text-[#94A3B8] font-mono mb-2">
          <div className="flex items-center gap-1.5 text-[#00E5FF]">
            <Clock className="w-3.5 h-3.5" />
            <span className="font-semibold tracking-wider uppercase text-[10px]">Universal Time</span>
          </div>
          <span className="text-[11px] px-1.5 py-0.5 rounded bg-white/5 border border-white/10 text-slate-300">
            {timezone}
          </span>
        </div>

        <div className="my-auto py-1">
          <div className="text-3xl lg:text-4xl font-mono font-bold tracking-tight text-white flex items-baseline gap-1">
            <span>{timeString}</span>
            <span className="text-xs font-normal text-[#00E5FF] animate-pulse">UTC</span>
          </div>
          <div className="flex items-center gap-2 mt-1.5 text-xs text-[#94A3B8] font-mono">
            <Calendar className="w-3.5 h-3.5 text-[#9B5CFF]" />
            <span>{dateString}</span>
          </div>
        </div>

        <div className="pt-2 border-t border-white/5 flex items-center justify-between text-[11px] font-mono text-slate-400">
          <span>Sys Sync: Real-Time</span>
          <span className="inline-flex items-center gap-1 text-[#00F5A0]">
            <span className="w-1.5 h-1.5 rounded-full bg-[#00F5A0] animate-ping" />
            NTP LOCKED
          </span>
        </div>
      </div>

      {/* 2. WEATHER WIDGET (REPAIRED: No clipped fonts, full responsive layout, micro-forecast) */}
      <div className="glass-panel rounded-xl p-4 flex flex-col justify-between border border-[#00E5FF]/20 relative overflow-hidden">
        <div className="flex items-center justify-between text-xs text-[#94A3B8] font-mono mb-2">
          <div className="flex items-center gap-1.5 text-[#FFB547]">
            <CloudSun className="w-3.5 h-3.5" />
            <span className="font-semibold tracking-wider uppercase text-[10px]">VPS Environment</span>
          </div>
          <span className="flex items-center gap-1 text-[11px] text-slate-300">
            <MapPin className="w-3 h-3 text-[#FF4567]" />
            {weatherData.city}
          </span>
        </div>

        <div className="my-auto py-1 flex items-center justify-between">
          <div>
            <div className="flex items-baseline gap-1">
              <span className="text-3xl lg:text-4xl font-mono font-bold text-white tracking-tight">
                {weatherData.temp}°
              </span>
              <span className="text-sm font-mono text-[#FFB547]">C</span>
            </div>
            <div className="text-xs text-[#00E5FF] font-medium mt-0.5 truncate max-w-[150px]">
              {weatherData.condition}
            </div>
          </div>

          <div className="flex flex-col items-end gap-1 font-mono text-[11px] text-slate-400">
            <div className="flex items-center gap-1.5">
              <Thermometer className="w-3 h-3 text-[#FFB547]" />
              <span>H:{weatherData.high}° / L:{weatherData.low}°</span>
            </div>
            <div className="flex items-center gap-1.5">
              <Droplets className="w-3 h-3 text-[#00E5FF]" />
              <span>{weatherData.humidity}% Hum</span>
            </div>
            <div className="flex items-center gap-1.5">
              <Wind className="w-3 h-3 text-slate-300" />
              <span>{weatherData.windKmh} km/h</span>
            </div>
          </div>
        </div>

        <div className="pt-2 border-t border-white/5 flex items-center justify-between text-[11px] font-mono text-slate-400">
          <span>Atmosphere: Stable</span>
          <span className="text-emerald-400 text-[10px]">METAR OK</span>
        </div>
      </div>

      {/* 3. SYSTEM HEALTH WIDGET (REPAIRED: Even spacing, real load, expandable diagnostics) */}
      <div className="glass-panel rounded-xl p-4 flex flex-col justify-between border border-[#00E5FF]/20 relative overflow-hidden">
        <div className="flex items-center justify-between text-xs text-[#94A3B8] font-mono mb-2">
          <div className="flex items-center gap-1.5 text-[#00F5A0]">
            <Activity className="w-3.5 h-3.5" />
            <span className="font-semibold tracking-wider uppercase text-[10px]">Host Diagnostics</span>
          </div>
          <div className="flex items-center gap-2">
            <span className="text-[10px] px-1.5 py-0.5 rounded bg-[#00F5A0]/10 border border-[#00F5A0]/30 text-[#00F5A0] font-mono">
              ALL OK
            </span>
            <button 
              onClick={onRefreshMetrics}
              className="text-slate-400 hover:text-white transition p-0.5"
              title="Refresh VPS telemetry"
            >
              <RefreshCw className="w-3 h-3" />
            </button>
          </div>
        </div>

        {/* Core Resource Metrics Bars */}
        <div className="my-auto py-1 space-y-2 font-mono">
          {/* Memory */}
          <div>
            <div className="flex justify-between text-[11px] text-slate-300 mb-0.5">
              <span className="flex items-center gap-1"><Cpu className="w-3 h-3 text-[#00E5FF]" /> RAM</span>
              <span className="text-[#00E5FF] font-semibold">{metrics.memory.usage_pct}% ({metrics.memory.used_gb}/{metrics.memory.total_gb} GB)</span>
            </div>
            <div className="w-full h-1.5 bg-white/10 rounded-full overflow-hidden">
              <div 
                className="h-full bg-gradient-to-r from-[#00E5FF] to-[#387BFF] transition-all duration-500 rounded-full"
                style={{ width: `${metrics.memory.usage_pct}%` }}
              />
            </div>
          </div>

          {/* NVMe Disk */}
          <div>
            <div className="flex justify-between text-[11px] text-slate-300 mb-0.5">
              <span className="flex items-center gap-1"><HardDrive className="w-3 h-3 text-[#9B5CFF]" /> NVMe</span>
              <span className="text-[#9B5CFF] font-semibold">{metrics.disk.usage_pct}% ({metrics.disk.used_gb}/{metrics.disk.total_gb} GB)</span>
            </div>
            <div className="w-full h-1.5 bg-white/10 rounded-full overflow-hidden">
              <div 
                className="h-full bg-gradient-to-r from-[#9B5CFF] to-[#FF4567] transition-all duration-500 rounded-full"
                style={{ width: `${metrics.disk.usage_pct}%` }}
              />
            </div>
          </div>
        </div>

        {/* Footer with Uptime and Expand Diagnostics toggle */}
        <div className="pt-2 border-t border-white/5 flex items-center justify-between text-[11px] font-mono text-slate-400">
          <span>Uptime: {metrics.uptime_formatted}</span>
          <button 
            onClick={() => setShowDiagnostics(!showDiagnostics)}
            className="flex items-center gap-1 text-[#00E5FF] hover:underline"
          >
            <span>{showDiagnostics ? 'Hide' : 'Details'}</span>
            {showDiagnostics ? <ChevronUp className="w-3 h-3" /> : <ChevronDown className="w-3 h-3" />}
          </button>
        </div>

        {/* Expandable Diagnostics Drawer */}
        {showDiagnostics && (
          <div className="mt-3 pt-3 border-t border-[#00E5FF]/20 text-xs font-mono space-y-2 animate-in fade-in duration-200">
            <div className="text-[10px] uppercase text-slate-400 tracking-wider">Active Microservices</div>
            <div className="grid grid-cols-2 gap-1.5">
              {Object.entries(metrics.services).map(([key, svc]) => (
                <div key={key} className="flex items-center justify-between bg-black/40 px-2 py-1 rounded border border-white/5 text-[10px]">
                  <span className="truncate max-w-[90px]">{key.replace('_', ' ')}</span>
                  <span className={svc?.status === 'HEALTHY' ? 'text-[#00F5A0]' : 'text-[#FF4567]'}>
                    {svc?.status || 'OFFLINE'}
                  </span>
                </div>
              ))}
            </div>
            <div className="text-[10px] text-slate-400 pt-1">
              Load Averages: {metrics.load_averages.join(' · ')}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
