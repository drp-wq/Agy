import React, { useEffect, useRef, useState } from 'react';
import * as THREE from 'three';
import { GraphicsMode } from '../types/jarvis';

interface JarvisCore3DProps {
  graphicsMode: GraphicsMode;
  systemStatus: 'HEALTHY' | 'WARNING' | 'CRITICAL' | 'OFFLINE';
  radarPulseCount: number;
  onCoreClick?: () => void;
}

export const JarvisCore3D: React.FC<JarvisCore3DProps> = ({
  graphicsMode,
  systemStatus,
  radarPulseCount,
  onCoreClick
}) => {
  const mountRef = useRef<HTMLDivElement>(null);
  const [fps, setFps] = useState<number>(60);
  const [hovered, setHovered] = useState(false);

  useEffect(() => {
    const container = mountRef.current;
    if (!container) return;

    if (graphicsMode === 'performance') {
      return;
    }

    const width = container.clientWidth || 320;
    const height = container.clientHeight || 280;

    // Scene, Camera, Renderer
    const scene = new THREE.Scene();
    const camera = new THREE.PerspectiveCamera(45, width / height, 0.1, 1000);
    camera.position.z = 7;

    const renderer = new THREE.WebGLRenderer({
      alpha: true,
      antialias: graphicsMode === 'cinematic',
      powerPreference: 'high-performance'
    });

    const maxDpr = graphicsMode === 'cinematic' ? 2 : 1;
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, maxDpr));
    renderer.setSize(width, height);
    container.innerHTML = '';
    container.appendChild(renderer.domElement);

    // Color definitions based on systemStatus
    let coreColorHex = 0x00e5ff; // cyan
    let glowColorHex = 0x387bff; // aurora blue
    if (systemStatus === 'WARNING') {
      coreColorHex = 0xffb547;
      glowColorHex = 0xff9900;
    } else if (systemStatus === 'CRITICAL' || systemStatus === 'OFFLINE') {
      coreColorHex = 0xff4567;
      glowColorHex = 0xff1144;
    }

    // 1. Central Core: Icosahedron / Nucleus
    const nucleusGeo = new THREE.IcosahedronGeometry(1.0, 2);
    const nucleusMat = new THREE.MeshStandardMaterial({
      color: coreColorHex,
      emissive: coreColorHex,
      emissiveIntensity: 0.5,
      wireframe: true,
      roughness: 0.2,
      metalness: 0.9
    });
    const nucleus = new THREE.Mesh(nucleusGeo, nucleusMat);
    scene.add(nucleus);

    // Inner glowing sphere
    const innerSphereGeo = new THREE.SphereGeometry(0.65, 16, 16);
    const innerSphereMat = new THREE.MeshBasicMaterial({
      color: glowColorHex,
      transparent: true,
      opacity: 0.8
    });
    const innerSphere = new THREE.Mesh(innerSphereGeo, innerSphereMat);
    scene.add(innerSphere);

    // 2. Orbital Rings
    const ringGroup = new THREE.Group();
    scene.add(ringGroup);

    // Outer Ring 1
    const ring1Geo = new THREE.TorusGeometry(1.8, 0.02, 8, 64);
    const ring1Mat = new THREE.MeshBasicMaterial({
      color: 0x00e5ff,
      transparent: true,
      opacity: 0.65
    });
    const ring1 = new THREE.Mesh(ring1Geo, ring1Mat);
    ringGroup.add(ring1);

    // Ring 2 (Tilted)
    const ring2Geo = new THREE.TorusGeometry(2.3, 0.015, 8, 64);
    const ring2Mat = new THREE.MeshBasicMaterial({
      color: 0x9b5cff, // violet
      transparent: true,
      opacity: 0.6
    });
    const ring2 = new THREE.Mesh(ring2Geo, ring2Mat);
    ring2.rotation.x = Math.PI / 4;
    ringGroup.add(ring2);

    // Ring 3 (Equatorial Dotted Ring)
    const ring3Geo = new THREE.RingGeometry(2.7, 2.75, 48);
    const ring3Mat = new THREE.MeshBasicMaterial({
      color: 0x00f5a0, // emerald
      side: THREE.DoubleSide,
      transparent: true,
      opacity: 0.4
    });
    const ring3 = new THREE.Mesh(ring3Geo, ring3Mat);
    ring3.rotation.y = Math.PI / 3;
    ringGroup.add(ring3);

    // 3. Floating Data Nodes / Particle Cloud (Cinematic & Balanced)
    const particleCount = graphicsMode === 'cinematic' ? 120 : 50;
    const particleGeo = new THREE.BufferGeometry();
    const positions = new Float32Array(particleCount * 3);
    const colors = new Float32Array(particleCount * 3);

    for (let i = 0; i < particleCount * 3; i += 3) {
      const radius = 2.5 + Math.random() * 2.5;
      const theta = Math.random() * Math.PI * 2;
      const phi = Math.acos(Math.random() * 2 - 1);

      positions[i] = radius * Math.sin(phi) * Math.cos(theta);
      positions[i + 1] = radius * Math.sin(phi) * Math.sin(theta);
      positions[i + 2] = radius * Math.cos(phi);

      colors[i] = 0.0;
      colors[i + 1] = 0.9;
      colors[i + 2] = 1.0;
    }
    particleGeo.setAttribute('position', new THREE.BufferAttribute(positions, 3));
    particleGeo.setAttribute('color', new THREE.BufferAttribute(colors, 3));

    const particleMat = new THREE.PointsMaterial({
      size: 0.05,
      vertexColors: true,
      transparent: true,
      opacity: 0.75
    });
    const particles = new THREE.Points(particleGeo, particleMat);
    scene.add(particles);

    // Lighting
    const ambientLight = new THREE.AmbientLight(0xffffff, 0.8);
    scene.add(ambientLight);

    const pointLight = new THREE.PointLight(coreColorHex, 2.5, 20);
    pointLight.position.set(0, 0, 2);
    scene.add(pointLight);

    // Animation variables
    let animationFrameId: number;
    let lastTime = performance.now();
    let frameCount = 0;
    let fpsTime = performance.now();

    const animate = (time: number) => {
      animationFrameId = requestAnimationFrame(animate);

      const delta = (time - lastTime) * 0.001;
      lastTime = time;

      // FPS tracking
      frameCount++;
      if (time - fpsTime >= 1000) {
        setFps(Math.round((frameCount * 1000) / (time - fpsTime)));
        frameCount = 0;
        fpsTime = time;
      }

      // Rotations
      nucleus.rotation.x += 0.4 * delta;
      nucleus.rotation.y += 0.6 * delta;

      ring1.rotation.z += 0.3 * delta;
      ring2.rotation.y += 0.4 * delta;
      ring3.rotation.x += 0.25 * delta;
      particles.rotation.y += 0.08 * delta;

      // Pulse breathing
      const pulse = 1 + Math.sin(time * 0.003) * 0.05;
      innerSphere.scale.set(pulse, pulse, pulse);

      renderer.render(scene, camera);
    };

    animationFrameId = requestAnimationFrame(animate);

    // Resize Handler
    const handleResize = () => {
      if (!container) return;
      const w = container.clientWidth || 320;
      const h = container.clientHeight || 280;
      camera.aspect = w / h;
      camera.updateProjectionMatrix();
      renderer.setSize(w, h);
    };

    window.addEventListener('resize', handleResize);

    return () => {
      cancelAnimationFrame(animationFrameId);
      window.removeEventListener('resize', handleResize);
      renderer.dispose();
      if (container.contains(renderer.domElement)) {
        container.removeChild(renderer.domElement);
      }
    };
  }, [graphicsMode, systemStatus, radarPulseCount]);

  return (
    <div 
      className="relative w-full h-[280px] flex items-center justify-center overflow-hidden rounded-xl border border-[#00E5FF]/20 bg-gradient-to-b from-[#081225]/80 to-[#030611]/90 backdrop-blur-md cursor-pointer group"
      onClick={onCoreClick}
      onMouseEnter={() => setHovered(true)}
      onMouseLeave={() => setHovered(false)}
      title="Click to engage JARVIS Command Palette"
    >
      {/* 3D WebGL Canvas Mount */}
      {graphicsMode !== 'performance' ? (
        <div ref={mountRef} className="w-full h-full absolute inset-0 z-0" />
      ) : (
        /* Lightweight 2D Fallback for Performance Mode */
        <div className="relative flex items-center justify-center w-48 h-48">
          <div className="absolute inset-0 rounded-full border border-dashed border-[#00E5FF]/40 animate-spin" style={{ animationDuration: '20s' }} />
          <div className="absolute inset-3 rounded-full border-2 border-[#9B5CFF]/40 border-t-[#00E5FF] animate-spin" style={{ animationDuration: '14s', animationDirection: 'reverse' }} />
          <div className="w-16 h-16 rounded-full bg-gradient-to-tr from-[#00E5FF] to-[#387BFF] flex items-center justify-center text-white text-2xl shadow-[0_0_25px_rgba(0,229,255,0.7)] animate-pulse">
            ⚡
          </div>
        </div>
      )}

      {/* Holographic HUD Overlays */}
      <div className="absolute top-3 left-4 z-10 pointer-events-none flex flex-col gap-0.5">
        <span className="text-[10px] uppercase tracking-widest text-[#94A3B8] font-bold">JARVIS Nucleus</span>
        <span className="text-xs font-mono text-[#00E5FF] flex items-center gap-1.5">
          <span className="inline-block w-2 h-2 rounded-full bg-[#00F5A0] animate-ping" />
          SPATIAL CORES ACTIVE
        </span>
      </div>

      <div className="absolute top-3 right-4 z-10 pointer-events-none flex items-center gap-2">
        <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-black/60 border border-[#00E5FF]/30 text-[#00E5FF]">
          {graphicsMode.toUpperCase()} · {graphicsMode !== 'performance' ? `${fps} FPS` : '2D ACCEL'}
        </span>
      </div>

      {/* Center Interactive Hint */}
      <div className={`absolute bottom-3 text-center z-10 transition-opacity duration-300 pointer-events-none ${hovered ? 'opacity-100' : 'opacity-60'}`}>
        <span className="text-[11px] font-mono text-[#94A3B8] bg-[#030611]/80 px-3 py-1 rounded-full border border-white/10">
          Click Core to trigger ⌘K Command Palette
        </span>
      </div>
    </div>
  );
};
