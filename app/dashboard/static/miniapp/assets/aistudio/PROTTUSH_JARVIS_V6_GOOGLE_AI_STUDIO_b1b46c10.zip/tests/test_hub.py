import pytest
import httpx
import os
import subprocess

BASE_HUB_URL = "http://127.0.0.1:7580"
HOMARR_URL = "http://127.0.0.1:7575"
GATE_URL = "http://127.0.0.1:8844"
BINANCE_URL = "http://127.0.0.1:8845"

@pytest.mark.asyncio
async def test_homarr_service_health():
    """Verify Homarr container is running and redirecting to /auth/login (authentication required)."""
    async with httpx.AsyncClient() as client:
        r = await client.get(f"{HOMARR_URL}/")
        assert r.status_code in [200, 307]
        if r.status_code == 307:
            assert "/auth/login" in r.headers.get("location", "")

@pytest.mark.asyncio
async def test_hub_adapter_health():
    """Verify Hub Adapter health endpoint."""
    async with httpx.AsyncClient() as client:
        r = await client.get(f"{BASE_HUB_URL}/hub-api/health")
        assert r.status_code == 200
        data = r.json()
        assert data["status"] == "healthy"

@pytest.mark.asyncio
async def test_existing_trading_services_unaffected():
    """Verify existing Gate and Binance observer services are unaffected and strictly read-only."""
    async with httpx.AsyncClient() as client:
        gr = await client.get(f"{GATE_URL}/api/health")
        assert gr.status_code == 200
        assert gr.json().get("mode") == "STRICTLY_READ_ONLY"

        br = await client.get(f"{BINANCE_URL}/binance/api/health")
        assert br.status_code == 200
        assert br.json().get("mode") == "STRICTLY_READ_ONLY"

@pytest.mark.asyncio
async def test_telemetry_adapters_integration():
    """Verify Hub Adapter accurately aggregates upstream trading telemetry."""
    async with httpx.AsyncClient() as client:
        r = await client.get(f"{BASE_HUB_URL}/hub-api/telemetry/summary")
        assert r.status_code == 200
        data = r.json()
        assert "gate" in data
        assert "binance" in data
        assert data["gate"]["health"]["connected"] is True
        assert data["binance"]["health"]["connected"] is True

@pytest.mark.asyncio
async def test_notifications_crud_and_deduplication():
    """Verify Universal Notification Center ingestion, retrieval, and deduplication."""
    async with httpx.AsyncClient() as client:
        payload = {
            "source": "test_suite",
            "title": "Automated Integration Test Event",
            "message": "Testing deduplication and severity routing",
            "severity": "info",
            "symbol": "BTC",
            "is_simulated": True
        }
        r1 = await client.post(f"{BASE_HUB_URL}/hub-api/notifications", json=payload)
        assert r1.status_code == 200
        
        # Query notifications
        r2 = await client.get(f"{BASE_HUB_URL}/hub-api/notifications?source=test_suite")
        assert r2.status_code == 200
        notifs = r2.json().get("notifications", [])
        assert len(notifs) >= 1
        notif_id = notifs[0]["id"]
        
        # Mark read
        r3 = await client.post(f"{BASE_HUB_URL}/hub-api/notifications/{notif_id}/read")
        assert r3.status_code == 200

@pytest.mark.asyncio
async def test_whatsapp_security_and_export_import():
    """Verify WhatsApp chat export parser and symbol extraction."""
    async with httpx.AsyncClient() as client:
        sample_export = (
            "[06/11/26, 21:00:15] Trader Alice: Looking at $SOL breakout above 185! Stop loss tight.\n"
            "[06/11/26, 21:05:22] Analyst Bob: BTC resistance at 74k holding strong.\n"
        )
        files = {"file": ("chat.txt", sample_export.encode("utf-8"), "text/plain")}
        r = await client.post(f"{BASE_HUB_URL}/hub-api/whatsapp/import-export", files=files)
        assert r.status_code == 200
        data = r.json()
        assert data["imported_messages"] == 2
        assert "SOL" in data["detected_symbols"]
        assert "BTC" in data["detected_symbols"]

@pytest.mark.asyncio
async def test_google_status_and_oauth_callback():
    """Verify Google integration returns honest status (pending authorization) and OAuth endpoints exist."""
    async with httpx.AsyncClient() as client:
        r = await client.get(f"{BASE_HUB_URL}/hub-api/google/status")
        assert r.status_code == 200
        data = r.json()
        assert "status" in data
        assert data["scopes"] is not None

        # Test OAuth callback error handling
        cb_r = await client.get(f"{BASE_HUB_URL}/hub-api/google/oauth/callback?error=access_denied")
        assert cb_r.status_code == 200
        assert "access_denied" in cb_r.text

@pytest.mark.asyncio
async def test_widgets_rendering():
    """Verify all 8 HTML widgets render cleanly with security headers."""
    widgets = [
        "notifications", "trading", "messages", "google",
        "netflix", "development", "intelligence", "system"
    ]
    async with httpx.AsyncClient() as client:
        for w in widgets:
            r = await client.get(f"{BASE_HUB_URL}/hub-widgets/{w}")
            assert r.status_code == 200
            assert "Content-Security-Policy" in r.headers
            assert "frame-ancestors" in r.headers["Content-Security-Policy"]
            assert "<!DOCTYPE html>" in r.text

@pytest.mark.asyncio
async def test_social_intelligence_feeds():
    """Verify RSS parsing and symbol tagging."""
    async with httpx.AsyncClient() as client:
        r = await client.get(f"{BASE_HUB_URL}/hub-api/intelligence/feeds")
        assert r.status_code == 200
        data = r.json()
        assert "items" in data

@pytest.mark.asyncio
async def test_caddy_trading_regression():
    """Verify Caddy continues serving trading.prottushjd.tech correctly with SNI."""
    res = subprocess.run(
        ["curl", "-s", "-k", "-I", "--resolve", "trading.prottushjd.tech:443:127.0.0.1", "https://trading.prottushjd.tech/"],
        capture_output=True,
        text=True
    )
    assert res.returncode == 0
    assert "401" in res.stdout
    assert "Basic realm=\"restricted\"" in res.stdout
