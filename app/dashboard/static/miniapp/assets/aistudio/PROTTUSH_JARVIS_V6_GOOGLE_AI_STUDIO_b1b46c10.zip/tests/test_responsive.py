import re
from pathlib import Path

CSS_FILE = Path("/root/prottush-homarr-hub/service/static/hub.css")

VIEWPORTS = [320, 390, 768, 1024, 1440]

def test_viewport_css_coverage():
    """Verify hub.css includes responsive breakpoints, meta viewports, and flex wrapping."""
    content = CSS_FILE.read_text()
    
    # Check media queries
    assert "@media (max-width: 480px)" in content
    
    # Check flexible layouts
    assert "grid-template-columns: repeat(auto-fit, minmax(" in content
    assert "flex-wrap: wrap;" in content
    assert "overflow-x: hidden;" in content

def test_html_templates_viewport_meta():
    """Verify all templates include responsive viewport meta tags."""
    templates_dir = Path("/root/prottush-homarr-hub/service/templates")
    html_files = list(templates_dir.glob("*.html"))
    assert len(html_files) >= 8
    
    for hf in html_files:
        html = hf.read_text()
        assert '<meta name="viewport" content="width=device-width, initial-scale=1.0">' in html
