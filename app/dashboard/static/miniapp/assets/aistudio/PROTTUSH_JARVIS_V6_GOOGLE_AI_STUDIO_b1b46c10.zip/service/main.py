from contextlib import asynccontextmanager
import asyncio
from fastapi import FastAPI, Request
from fastapi.staticfiles import StaticFiles
from fastapi.middleware.cors import CORSMiddleware
from pathlib import Path
from service.config import settings
from service.database import init_db, record_notification
from service.adapters.gate import gate_adapter
from service.adapters.binance import binance_adapter
from service.routers import (
    notifications,
    telemetry,
    google,
    whatsapp,
    telegram,
    github,
    intelligence,
    system,
    widgets
)

STATIC_DIR = Path(__file__).resolve().parent / "static"

async def background_telemetry_poller():
    """Polls Gate and Binance read-only observers periodically to update event log."""
    await asyncio.sleep(5)
    while True:
        try:
            gate_over = await gate_adapter.get_overview()
            if gate_over.get("connected"):
                # Check for active bots or discoveries
                disc = gate_over.get("total_solana_discoveries", 0)
                if disc > 0:
                    record_notification(
                        source="gate",
                        title=f"Gate.io Solana Discovery Stream Active",
                        message=f"{disc} fresh Solana/Raydium liquidity pools discovered. Security anti-rug validation active.",
                        severity="info",
                        symbol="SOL",
                        is_simulated=True,
                        deep_link="https://trading.prottushjd.tech/"
                    )
            
            bin_over = await binance_adapter.get_overview()
            if bin_over.get("connected"):
                prog = bin_over.get("progress", {})
                pnl = bin_over.get("total_pnl_usd", 0.0)
                record_notification(
                    source="binance",
                    title=f"Binance Alpha V3 Experiment ({prog.get('status', 'RUNNING')})",
                    message=f"Stage: {prog.get('current_stage', 'Stage 2')} · Cycle {prog.get('cycle_count', 0)} · PnL: ${pnl:.2f}",
                    severity="info",
                    is_simulated=True,
                    deep_link="https://trading.prottushjd.tech/binance"
                )
        except Exception as e:
            pass
        await asyncio.sleep(60)

@asynccontextmanager
async def lifespan(app: FastAPI):
    init_db()
    
    # Record initial system startup event
    record_notification(
        source="system",
        title="Prottush Homarr Command Center Online",
        message="Universal Command Center microservices, Caddy reverse-proxy bridge, and telemetry adapters initialized successfully.",
        severity="info",
        is_simulated=False,
        deep_link="https://home.prottushjd.tech"
    )
    
    poller_task = asyncio.create_task(background_telemetry_poller())
    yield
    poller_task.cancel()

app = FastAPI(
    title="Prottush Homarr Universal Hub Companion",
    version="1.0.0",
    lifespan=lifespan
)

# CORS configuration
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Security Headers & Framing Middleware
@app.middleware("http")
async def add_security_headers(request: Request, call_next):
    response = await call_next(request)
    response.headers["X-Content-Type-Options"] = "nosniff"
    response.headers["X-XSS-Protection"] = "1; mode=block"
    # Allow embedding in Homarr dashboard frames
    response.headers["Content-Security-Policy"] = "frame-ancestors 'self' http://127.0.0.1:7575 https://home.prottushjd.tech *;"
    return response

# Static files
app.mount("/hub-static", StaticFiles(directory=str(STATIC_DIR)), name="hub-static")

# Routers
app.include_router(notifications.router)
app.include_router(telemetry.router)
app.include_router(google.router)
app.include_router(whatsapp.router)
app.include_router(telegram.router)
app.include_router(github.router)
app.include_router(intelligence.router)
app.include_router(system.router)
app.include_router(widgets.router)

@app.get("/hub-api/health")
async def health_check():
    return {
        "status": "healthy",
        "service": "prottush-homarr-hub-companion",
        "port": settings.hub_port
    }
