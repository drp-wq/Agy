import httpx
import time
from typing import Dict, Any
from service.config import settings

class GateAdapter:
    def __init__(self):
        self.base_url = settings.gate_observer_url.rstrip("/")
        self.client = httpx.AsyncClient(timeout=4.0)

    async def get_health(self) -> Dict[str, Any]:
        try:
            r = await self.client.get(f"{self.base_url}/api/health")
            if r.status_code == 200:
                data = r.json()
                data["connected"] = True
                return data
        except Exception as e:
            return {"connected": False, "status": "offline", "error": str(e), "service": "gate-observer"}
        return {"connected": False, "status": "unknown"}

    async def get_overview(self) -> Dict[str, Any]:
        try:
            r = await self.client.get(f"{self.base_url}/api/overview")
            if r.status_code == 200:
                data = r.json()
                data["connected"] = True
                # Detect stale data
                now = time.time()
                last_ts = data.get("bots", [{}])[0].get("last_update_ts", now)
                data["stale_warning"] = (now - last_ts) > 120
                data["staleness_seconds"] = round(now - last_ts, 1)
                return data
        except Exception as e:
            return {"connected": False, "error": str(e), "stale_warning": True}
        return {"connected": False, "stale_warning": True}

    async def get_subsystems(self) -> Dict[str, Any]:
        try:
            r = await self.client.get(f"{self.base_url}/api/subsystems")
            if r.status_code == 200:
                return r.json()
        except Exception:
            pass
        return {}

gate_adapter = GateAdapter()
