import feedparser
import time
from typing import List, Dict, Any
from service.adapters.whatsapp import extract_symbols

FEEDS = [
    {"name": "CoinDesk", "url": "https://www.coindesk.com/arc/outboundfeeds/rss/", "category": "Crypto News"},
    {"name": "CoinTelegraph", "url": "https://cointelegraph.com/rss", "category": "Market News"},
    {"name": "Decrypt", "url": "https://decrypt.co/feed", "category": "Tech & Web3"},
    {"name": "Bitcoin Magazine", "url": "https://bitcoinmagazine.com/.rss/full/", "category": "Bitcoin"}
]

class IntelligenceAdapter:
    def __init__(self):
        self._cached_items = []
        self._last_fetch = 0.0
        self.cache_ttl = 300.0 # 5 minutes

    async def get_feed_items(self, symbol_filter: str = None) -> List[Dict[str, Any]]:
        now = time.time()
        if not self._cached_items or (now - self._last_fetch > self.cache_ttl):
            items = []
            seen_titles = set()
            for feed in FEEDS:
                try:
                    parsed = feedparser.parse(feed["url"])
                    for entry in parsed.entries[:6]:
                        title = entry.get("title", "")
                        clean_title = title.strip()
                        if clean_title in seen_titles:
                            continue
                        seen_titles.add(clean_title)
                        
                        summary = entry.get("summary", "") or entry.get("description", "")
                        # strip html tags simply
                        clean_summary = summary.replace("<p>", "").replace("</p>", "").replace("<b>", "").replace("</b>", "")[:200]
                        symbols = extract_symbols(f"{title} {clean_summary}")
                        link = entry.get("link", "#")
                        published = entry.get("published", "") or time.strftime("%Y-%m-%d %H:%M UTC", time.gmtime())
                        
                        items.append({
                            "source": feed["name"],
                            "category": feed["category"],
                            "title": clean_title,
                            "summary": clean_summary,
                            "symbols": symbols,
                            "link": link,
                            "published": published,
                            "timestamp": time.time()
                        })
                except Exception:
                    continue
            self._cached_items = items
            self._last_fetch = now

        if symbol_filter:
            sym_upper = symbol_filter.upper()
            return [it for it in self._cached_items if sym_upper in it["symbols"]]
        
        return self._cached_items

intelligence_adapter = IntelligenceAdapter()
