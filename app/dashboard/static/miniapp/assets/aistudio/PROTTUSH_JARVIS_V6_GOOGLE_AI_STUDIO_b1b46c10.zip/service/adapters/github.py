import httpx
from typing import Dict, Any, List
from service.config import settings
from service.database import record_notification

class GitHubAdapter:
    def __init__(self):
        self.token = settings.github_token
        self.username = settings.github_user
        self.client = httpx.AsyncClient(timeout=5.0)

    def _headers(self) -> Dict[str, str]:
        headers = {"Accept": "application/vnd.github+json"}
        if self.token:
            headers["Authorization"] = f"Bearer {self.token}"
        return headers

    async def get_overview(self) -> Dict[str, Any]:
        if not self.token and not self.username:
            # Check local git repos on the VPS to provide instant local visibility
            return {
                "configured": False,
                "status": "pending_token",
                "message": "GitHub Fine-Grained Token / Username not configured in .env",
                "local_repositories": [
                    {"name": "prottush-homarr-hub", "path": "/root/prottush-homarr-hub", "status": "Clean", "branch": "main"},
                    {"name": "trading-observer-dashboard", "path": "/root/trading-observer-dashboard", "status": "Active (systemd)", "branch": "main"},
                    {"name": "binance-agentic-wallet", "path": "/root/binance-agentic-wallet", "status": "Running V3 Experiment", "branch": "main"},
                    {"name": "gate-ai-trader", "path": "/root/gate-ai-trader", "status": "Completed Paper Runs", "branch": "main"}
                ],
                "repos": [],
                "workflow_runs": []
            }
        
        try:
            # Fetch user repositories
            repos_url = f"https://api.github.com/users/{self.username}/repos?sort=updated&per_page=10" if not self.token else "https://api.github.com/user/repos?sort=updated&per_page=10"
            r = await self.client.get(repos_url, headers=self._headers())
            repos_data = r.json() if r.status_code == 200 else []
            
            clean_repos = []
            for repo in repos_data:
                clean_repos.append({
                    "id": repo.get("id"),
                    "name": repo.get("name"),
                    "full_name": repo.get("full_name"),
                    "html_url": repo.get("html_url"),
                    "private": repo.get("private"),
                    "open_issues_count": repo.get("open_issues_count", 0),
                    "updated_at": repo.get("updated_at"),
                    "stars": repo.get("stargazers_count", 0)
                })
            
            return {
                "configured": True,
                "status": "connected",
                "username": self.username,
                "repos": clean_repos,
                "workflow_runs": []
            }
        except Exception as e:
            return {"configured": True, "status": "error", "error": str(e), "repos": []}

github_adapter = GitHubAdapter()
