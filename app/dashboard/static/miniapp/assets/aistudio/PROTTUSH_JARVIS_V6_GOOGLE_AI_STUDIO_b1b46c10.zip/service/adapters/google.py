import urllib.parse
import time
import httpx
from typing import Dict, Any, List
from service.config import settings
from service.crypto import encrypt_value, decrypt_value
from service.database import get_db

SCOPES = [
    "https://www.googleapis.com/auth/gmail.readonly",
    "https://www.googleapis.com/auth/calendar.readonly",
    "https://www.googleapis.com/auth/drive.readonly",
    "https://www.googleapis.com/auth/youtube.readonly"
]

class GoogleAdapter:
    def __init__(self):
        self.client_id = settings.google_client_id
        self.client_secret = settings.google_client_secret
        self.redirect_uri = settings.google_redirect_uri
        self.api_key = settings.google_api_key

    def get_token(self) -> str:
        with get_db() as conn:
            cursor = conn.cursor()
            row = cursor.execute("SELECT encrypted_value FROM tokens WHERE key_name = 'google_refresh_token'").fetchone()
            if row and row["encrypted_value"]:
                return decrypt_value(row["encrypted_value"])
        return ""

    def save_token(self, refresh_token: str):
        enc = encrypt_value(refresh_token)
        with get_db() as conn:
            cursor = conn.cursor()
            cursor.execute("""
            INSERT INTO tokens (key_name, encrypted_value, updated_at)
            VALUES ('google_refresh_token', ?, ?)
            ON CONFLICT(key_name) DO UPDATE SET
                encrypted_value = excluded.encrypted_value,
                updated_at = excluded.updated_at
            """, (enc, time.time()))
            conn.commit()

    def disconnect(self):
        with get_db() as conn:
            cursor = conn.cursor()
            cursor.execute("DELETE FROM tokens WHERE key_name = 'google_refresh_token'")
            conn.commit()

    def get_auth_url(self) -> str:
        if not self.client_id:
            return ""
        params = {
            "client_id": self.client_id,
            "redirect_uri": self.redirect_uri,
            "response_type": "code",
            "scope": " ".join(SCOPES),
            "access_type": "offline",
            "prompt": "consent"
        }
        return f"https://accounts.google.com/o/oauth2/v2/auth?{urllib.parse.urlencode(params)}"

    def get_status(self) -> Dict[str, Any]:
        has_client = bool(self.client_id and self.client_secret)
        has_token = bool(self.get_token())
        return {
            "configured": has_client,
            "authorized": has_token,
            "status": "connected" if (has_client and has_token) else ("pending_authorization" if has_client else "not_configured"),
            "client_id_set": bool(self.client_id),
            "redirect_uri": self.redirect_uri,
            "auth_url": self.get_auth_url() if has_client else None,
            "scopes": SCOPES
        }

    async def get_access_token(self) -> str:
        refresh_token = self.get_token()
        if not refresh_token or not self.client_id or not self.client_secret:
            return ""
        async with httpx.AsyncClient() as client:
            resp = await client.post("https://oauth2.googleapis.com/token", data={
                "client_id": self.client_id,
                "client_secret": self.client_secret,
                "refresh_token": refresh_token,
                "grant_type": "refresh_token"
            })
            if resp.status_code == 200:
                return resp.json().get("access_token", "")
        return ""

    async def get_gmail_summary(self) -> Dict[str, Any]:
        token = await self.get_access_token()
        if not token:
            return {
                "authorized": False,
                "status": "pending_authorization",
                "unread_count": 0,
                "messages": [],
                "open_url": "https://mail.google.com"
            }
        try:
            headers = {"Authorization": f"Bearer {token}"}
            async with httpx.AsyncClient() as client:
                # Get unread message count
                r = await client.get("https://gmail.googleapis.com/gmail/v1/users/me/labels/INBOX", headers=headers)
                unread_count = r.json().get("messagesUnread", 0) if r.status_code == 200 else 0
                
                # Get recent 5 unread messages metadata
                list_r = await client.get("https://gmail.googleapis.com/gmail/v1/users/me/messages?q=is:unread&maxResults=5", headers=headers)
                messages = []
                if list_r.status_code == 200:
                    msg_ids = [m["id"] for m in list_r.json().get("messages", [])]
                    for mid in msg_ids:
                        mr = await client.get(f"https://gmail.googleapis.com/gmail/v1/users/me/messages/{mid}?format=metadata", headers=headers)
                        if mr.status_code == 200:
                            mdata = mr.json()
                            headers_list = mdata.get("payload", {}).get("headers", [])
                            subject = next((h["value"] for h in headers_list if h["name"].lower() == "subject"), "No Subject")
                            sender = next((h["value"] for h in headers_list if h["name"].lower() == "from"), "Unknown Sender")
                            messages.append({
                                "id": mid,
                                "sender": sender,
                                "subject": subject,
                                "snippet": mdata.get("snippet", ""),
                                "deep_link": f"https://mail.google.com/mail/u/0/#inbox/{mid}"
                            })
                return {
                    "authorized": True,
                    "status": "connected",
                    "unread_count": unread_count,
                    "messages": messages,
                    "open_url": "https://mail.google.com"
                }
        except Exception as e:
            return {"authorized": False, "error": str(e), "open_url": "https://mail.google.com"}

    async def get_calendar_events(self) -> Dict[str, Any]:
        token = await self.get_access_token()
        if not token:
            return {
                "authorized": False,
                "status": "pending_authorization",
                "events": [],
                "open_url": "https://calendar.google.com"
            }
        try:
            headers = {"Authorization": f"Bearer {token}"}
            now_iso = time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())
            async with httpx.AsyncClient() as client:
                r = await client.get(
                    f"https://www.googleapis.com/calendar/v3/calendars/primary/events?timeMin={now_iso}&maxResults=10&singleEvents=true&orderBy=startTime",
                    headers=headers
                )
                if r.status_code == 200:
                    items = r.json().get("items", [])
                    events = []
                    for item in items:
                        start = item.get("start", {}).get("dateTime") or item.get("start", {}).get("date")
                        events.append({
                            "id": item.get("id"),
                            "summary": item.get("summary", "Untitled Event"),
                            "start": start,
                            "htmlLink": item.get("htmlLink", "https://calendar.google.com")
                        })
                    return {"authorized": True, "status": "connected", "events": events, "open_url": "https://calendar.google.com"}
        except Exception as e:
            return {"authorized": False, "error": str(e), "open_url": "https://calendar.google.com"}
        return {"authorized": False, "events": [], "open_url": "https://calendar.google.com"}

    async def get_drive_files(self) -> Dict[str, Any]:
        token = await self.get_access_token()
        if not token:
            return {
                "authorized": False,
                "status": "pending_authorization",
                "files": [],
                "open_url": "https://drive.google.com"
            }
        try:
            headers = {"Authorization": f"Bearer {token}"}
            async with httpx.AsyncClient() as client:
                r = await client.get(
                    "https://www.googleapis.com/drive/v3/files?pageSize=10&fields=files(id,name,mimeType,webViewLink,modifiedTime)&orderBy=modifiedTime desc",
                    headers=headers
                )
                if r.status_code == 200:
                    return {
                        "authorized": True,
                        "status": "connected",
                        "files": r.json().get("files", []),
                        "open_url": "https://drive.google.com"
                    }
        except Exception as e:
            return {"authorized": False, "error": str(e), "open_url": "https://drive.google.com"}
        return {"authorized": False, "files": [], "open_url": "https://drive.google.com"}

    async def get_youtube_feed(self) -> Dict[str, Any]:
        # If API key or OAuth token available
        return {
            "authorized": bool(self.api_key or self.get_token()),
            "status": "connected" if (self.api_key or self.get_token()) else "pending_authorization",
            "channels": [
                {"name": "CoinDesk", "url": "https://www.youtube.com/@CoinDesk/videos"},
                {"name": "Bloomberg Crypto", "url": "https://www.youtube.com/@BloombergCrypto/videos"},
                {"name": "Bankless", "url": "https://www.youtube.com/@Bankless/videos"}
            ],
            "open_url": "https://youtube.com"
        }

google_adapter = GoogleAdapter()
