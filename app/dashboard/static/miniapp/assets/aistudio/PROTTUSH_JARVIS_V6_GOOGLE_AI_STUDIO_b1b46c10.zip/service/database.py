import sqlite3
import json
import hashlib
import time
from typing import List, Dict, Any, Optional
from service.config import settings

def get_db():
    conn = sqlite3.connect(settings.database_url)
    conn.row_factory = sqlite3.Row
    return conn

def init_db():
    with get_db() as conn:
        cursor = conn.cursor()
        # Notifications table
        cursor.execute("""
        CREATE TABLE IF NOT EXISTS notifications (
            id TEXT PRIMARY KEY,
            fingerprint TEXT UNIQUE,
            source TEXT NOT NULL,
            title TEXT NOT NULL,
            message TEXT NOT NULL,
            severity TEXT NOT NULL DEFAULT 'info',
            symbol TEXT,
            is_simulated INTEGER NOT NULL DEFAULT 0,
            is_read INTEGER NOT NULL DEFAULT 0,
            deep_link TEXT,
            metadata_json TEXT DEFAULT '{}',
            created_at REAL NOT NULL
        )
        """)
        cursor.execute("CREATE INDEX IF NOT EXISTS idx_notif_created ON notifications(created_at DESC);")
        cursor.execute("CREATE INDEX IF NOT EXISTS idx_notif_source ON notifications(source);")
        cursor.execute("CREATE INDEX IF NOT EXISTS idx_notif_severity ON notifications(severity);")
        cursor.execute("CREATE INDEX IF NOT EXISTS idx_notif_read ON notifications(is_read);")
        
        # Stored encrypted tokens
        cursor.execute("""
        CREATE TABLE IF NOT EXISTS tokens (
            key_name TEXT PRIMARY KEY,
            encrypted_value TEXT NOT NULL,
            updated_at REAL NOT NULL
        )
        """)
        
        # WhatsApp Companion Messages
        cursor.execute("""
        CREATE TABLE IF NOT EXISTS whatsapp_messages (
            id TEXT PRIMARY KEY,
            sender TEXT NOT NULL,
            message_text TEXT NOT NULL,
            symbols TEXT,
            keywords TEXT,
            timestamp REAL NOT NULL,
            created_at REAL NOT NULL
        )
        """)
        cursor.execute("CREATE INDEX IF NOT EXISTS idx_wa_time ON whatsapp_messages(timestamp DESC);")

        # Curated Watchlist (Entertainment / Netflix)
        cursor.execute("""
        CREATE TABLE IF NOT EXISTS entertainment_watchlist (
            id TEXT PRIMARY KEY,
            title TEXT NOT NULL,
            category TEXT NOT NULL DEFAULT 'Netflix',
            status TEXT NOT NULL DEFAULT 'Plan to Watch',
            rating INTEGER DEFAULT 0,
            direct_url TEXT,
            notes TEXT,
            created_at REAL NOT NULL
        )
        """)

        # System Audit Log
        cursor.execute("""
        CREATE TABLE IF NOT EXISTS audit_log (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            action TEXT NOT NULL,
            details TEXT,
            client_ip TEXT,
            timestamp REAL NOT NULL
        )
        """)
        conn.commit()

def record_notification(
    source: str,
    title: str,
    message: str,
    severity: str = "info",
    symbol: Optional[str] = None,
    is_simulated: bool = False,
    deep_link: Optional[str] = None,
    metadata: Optional[Dict[str, Any]] = None
) -> Optional[str]:
    # Deduplication fingerprint
    fp_raw = f"{source}:{title}:{message[:80]}:{symbol or ''}:{int(is_simulated)}"
    fingerprint = hashlib.sha256(fp_raw.encode("utf-8")).hexdigest()
    notif_id = f"notif_{int(time.time()*1000)}_{fingerprint[:8]}"
    created_at = time.time()
    meta_str = json.dumps(metadata or {})
    
    with get_db() as conn:
        cursor = conn.cursor()
        try:
            cursor.execute("""
            INSERT INTO notifications (
                id, fingerprint, source, title, message, severity,
                symbol, is_simulated, is_read, deep_link, metadata_json, created_at
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, 0, ?, ?, ?)
            ON CONFLICT(fingerprint) DO UPDATE SET
                created_at = excluded.created_at,
                message = excluded.message
            """, (
                notif_id, fingerprint, source, title, message, severity,
                symbol, int(is_simulated), deep_link, meta_str, created_at
            ))
            conn.commit()
            return notif_id
        except Exception as e:
            print(f"Error recording notification: {e}")
            return None

def query_notifications(
    source: Optional[str] = None,
    severity: Optional[str] = None,
    symbol: Optional[str] = None,
    query: Optional[str] = None,
    unread_only: bool = False,
    limit: int = 50,
    offset: int = 0
) -> List[Dict[str, Any]]:
    sql = "SELECT * FROM notifications WHERE 1=1"
    params = []
    if source:
        sql += " AND source = ?"
        params.append(source)
    if severity:
        sql += " AND severity = ?"
        params.append(severity)
    if symbol:
        sql += " AND symbol LIKE ?"
        params.append(f"%{symbol}%")
    if unread_only:
        sql += " AND is_read = 0"
    if query:
        sql += " AND (title LIKE ? OR message LIKE ?)"
        params.extend([f"%{query}%", f"%{query}%"])
    sql += " ORDER BY created_at DESC LIMIT ? OFFSET ?"
    params.extend([limit, offset])
    
    with get_db() as conn:
        cursor = conn.cursor()
        rows = cursor.execute(sql, params).fetchall()
        results = []
        for r in rows:
            results.append({
                "id": r["id"],
                "source": r["source"],
                "title": r["title"],
                "message": r["message"],
                "severity": r["severity"],
                "symbol": r["symbol"],
                "is_simulated": bool(r["is_simulated"]),
                "is_read": bool(r["is_read"]),
                "deep_link": r["deep_link"],
                "metadata": json.loads(r["metadata_json"] or "{}"),
                "created_at": r["created_at"],
                "formatted_time": time.strftime("%Y-%m-%d %H:%M:%S UTC", time.gmtime(r["created_at"]))
            })
        return results

def mark_notification_read(notif_id: str):
    with get_db() as conn:
        cursor = conn.cursor()
        cursor.execute("UPDATE notifications SET is_read = 1 WHERE id = ?", (notif_id,))
        conn.commit()

def mark_all_notifications_read():
    with get_db() as conn:
        cursor = conn.cursor()
        cursor.execute("UPDATE notifications SET is_read = 1")
        conn.commit()

def clear_old_notifications(days: int = 14):
    cutoff = time.time() - (days * 86400)
    with get_db() as conn:
        cursor = conn.cursor()
        cursor.execute("DELETE FROM notifications WHERE created_at < ?", (cutoff,))
        conn.commit()
