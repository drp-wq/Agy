from fastapi import APIRouter, Header, HTTPException, Query, UploadFile, File
from pydantic import BaseModel
from typing import Optional, List
from service.adapters.whatsapp import whatsapp_adapter

router = APIRouter(prefix="/hub-api/whatsapp", tags=["WhatsApp Integration"])

class WebhookMessage(BaseModel):
    sender: str
    text: str
    timestamp: Optional[float] = None

@router.get("/status")
async def get_whatsapp_status():
    return whatsapp_adapter.get_status()

@router.get("/messages")
async def get_whatsapp_messages(
    query: Optional[str] = None,
    symbol: Optional[str] = None,
    limit: int = Query(50, le=200)
):
    return {
        "messages": whatsapp_adapter.get_messages(query, symbol, limit)
    }

@router.post("/companion/webhook")
async def companion_webhook(payload: WebhookMessage, authorization: Optional[str] = Header(None)):
    token = authorization.replace("Bearer ", "") if authorization else None
    if not whatsapp_adapter.verify_token(token):
        raise HTTPException(status_code=401, detail="Invalid WhatsApp bridge token")
    
    res = whatsapp_adapter.ingest_notification(payload.sender, payload.text, payload.timestamp)
    return res

@router.post("/import-export")
async def import_chat_export(file: UploadFile = File(...)):
    content = await file.read()
    try:
        text = content.decode("utf-8")
    except UnicodeDecodeError:
        text = content.decode("latin-1")
    return whatsapp_adapter.import_chat_export(text)

@router.post("/wipe")
async def wipe_whatsapp():
    whatsapp_adapter.wipe_data()
    return {"status": "wiped"}
