from fastapi import APIRouter
from service.adapters.gate import gate_adapter
from service.adapters.binance import binance_adapter

router = APIRouter(prefix="/hub-api/telemetry", tags=["Telemetry"])

@router.get("/summary")
async def get_telemetry_summary():
    gate_health = await gate_adapter.get_health()
    gate_data = await gate_adapter.get_overview()
    binance_health = await binance_adapter.get_health()
    binance_data = await binance_adapter.get_overview()
    
    return {
        "gate": {
            "health": gate_health,
            "overview": gate_data
        },
        "binance": {
            "health": binance_health,
            "overview": binance_data
        }
    }

@router.get("/gate")
async def get_gate_telemetry():
    health = await gate_adapter.get_health()
    overview = await gate_adapter.get_overview()
    subsystems = await gate_adapter.get_subsystems()
    return {
        "health": health,
        "overview": overview,
        "subsystems": subsystems
    }

@router.get("/binance")
async def get_binance_telemetry():
    health = await binance_adapter.get_health()
    overview = await binance_adapter.get_overview()
    positions = await binance_adapter.get_positions()
    risk = await binance_adapter.get_risk()
    return {
        "health": health,
        "overview": overview,
        "positions": positions,
        "risk": risk
    }
