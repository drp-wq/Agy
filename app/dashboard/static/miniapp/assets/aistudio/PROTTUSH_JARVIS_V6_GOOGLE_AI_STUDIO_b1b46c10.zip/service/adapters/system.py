import os
import shutil
import time
import httpx
from typing import Dict, Any

class SystemAdapter:
    async def get_metrics(self) -> Dict[str, Any]:
        # Disk usage
        total_d, used_d, free_d = shutil.disk_usage("/")
        
        # Memory
        mem_info = {}
        try:
            with open("/proc/meminfo") as f:
                for line in f:
                    parts = line.split(":")
                    if len(parts) == 2:
                        mem_info[parts[0].strip()] = int(parts[1].strip().split()[0])
            total_m = mem_info.get("MemTotal", 1) * 1024
            avail_m = mem_info.get("MemAvailable", 0) * 1024
            used_m = total_m - avail_m
        except Exception:
            total_m, used_m, avail_m = (1, 0, 1)

        # Load average
        try:
            load1, load5, load15 = os.getloadavg()
        except Exception:
            load1, load5, load15 = (0.0, 0.0, 0.0)

        # Uptime
        try:
            with open("/proc/uptime") as f:
                uptime_sec = float(f.readline().split()[0])
        except Exception:
            uptime_sec = 0.0

        # Check Homarr container health
        homarr_healthy = False
        try:
            async with httpx.AsyncClient(timeout=2.0) as client:
                r = await client.get("http://127.0.0.1:7575/api/auth/csrf")
                if r.status_code == 200:
                    homarr_healthy = True
        except Exception:
            homarr_healthy = False

        # Check Socket Proxy
        proxy_healthy = False
        try:
            async with httpx.AsyncClient(timeout=2.0) as client:
                # Docker socket proxy is internal to docker or we can query docker info via socket
                if os.path.exists("/var/run/docker.sock"):
                    proxy_healthy = True
        except Exception:
            proxy_healthy = False

        # Check Gate & Binance
        gate_ok = False
        binance_ok = False
        try:
            async with httpx.AsyncClient(timeout=2.0) as client:
                gr = await client.get("http://127.0.0.1:8844/api/health")
                if gr.status_code == 200:
                    gate_ok = True
                br = await client.get("http://127.0.0.1:8845/binance/api/health")
                if br.status_code == 200:
                    binance_ok = True
        except Exception:
            pass

        # Check Telegram Notifier Daemon
        tg_ok = False
        try:
            for pid in os.listdir('/proc'):
                if pid.isdigit():
                    try:
                        with open(f'/proc/{pid}/cmdline', 'rb') as pf:
                            cmd = pf.read().decode('utf-8', errors='ignore')
                            if 'telegram_notifier' in cmd or 'prottush-binance-telegram' in cmd:
                                tg_ok = True
                                break
                    except Exception:
                        pass
        except Exception:
            tg_ok = False

        return {
            "timestamp": time.time(),
            "uptime_seconds": uptime_sec,
            "uptime_formatted": f"{int(uptime_sec // 86400)}d {int((uptime_sec % 86400) // 3600)}h {int((uptime_sec % 3600) // 60)}m",
            "load_averages": [round(load1, 2), round(load5, 2), round(load15, 2)],
            "memory": {
                "total_gb": round(total_m / (1024**3), 2),
                "used_gb": round(used_m / (1024**3), 2),
                "available_gb": round(avail_m / (1024**3), 2),
                "usage_pct": round((used_m / total_m) * 100, 1)
            },
            "disk": {
                "total_gb": round(total_d / (1024**3), 2),
                "used_gb": round(used_d / (1024**3), 2),
                "free_gb": round(free_d / (1024**3), 2),
                "usage_pct": round((used_d / total_d) * 100, 1)
            },
            "services": {
                "homarr": {"status": "HEALTHY" if homarr_healthy else "STOPPED", "port": 7575},
                "docker_socket_proxy": {"status": "HEALTHY" if proxy_healthy else "OFFLINE", "port": 2375},
                "gate_observer": {"status": "HEALTHY" if gate_ok else "OFFLINE", "port": 8844, "mode": "READ_ONLY"},
                "binance_observer": {"status": "HEALTHY" if binance_ok else "OFFLINE", "port": 8845, "mode": "READ_ONLY"},
                "telegram_notifier": {"status": "HEALTHY" if tg_ok else "OFFLINE", "service": "prottush-binance-telegram"},
                "hub_companion": {"status": "HEALTHY", "port": 7580},
                "caddy": {"status": "HEALTHY", "ports": [80, 443]}
            }
        }

system_adapter = SystemAdapter()
