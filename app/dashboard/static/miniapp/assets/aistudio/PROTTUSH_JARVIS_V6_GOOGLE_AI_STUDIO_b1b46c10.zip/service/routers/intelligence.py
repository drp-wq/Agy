from fastapi import APIRouter, Query
from typing import Optional
from service.adapters.intelligence import intelligence_adapter

router = APIRouter(prefix="/hub-api/intelligence", tags=["Social Intelligence"])

@router.get("/feeds")
async def get_feeds(symbol: Optional[str] = Query(None)):
    items = await intelligence_adapter.get_feed_items(symbol)
    return {
        "count": len(items),
        "items": items,
        "symbol_filter": symbol
    }
