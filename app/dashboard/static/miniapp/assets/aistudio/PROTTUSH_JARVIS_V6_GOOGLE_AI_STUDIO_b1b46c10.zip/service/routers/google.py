from fastapi import APIRouter, Query, Request
from fastapi.responses import RedirectResponse, HTMLResponse
from typing import Optional, List, Dict, Any
import httpx
from service.adapters.google import google_adapter

router = APIRouter(prefix="/hub-api/google", tags=["Google Integration"])

@router.get("/status")
async def get_google_status():
    return google_adapter.get_status()

@router.get("/gmail/unread")
async def get_gmail_unread():
    return await google_adapter.get_gmail_summary()

@router.get("/calendar/upcoming")
async def get_calendar_upcoming():
    return await google_adapter.get_calendar_events()

@router.get("/drive/recent")
async def get_drive_recent():
    return await google_adapter.get_drive_files()

@router.get("/youtube/feed")
async def get_youtube_feed():
    return await google_adapter.get_youtube_feed()

@router.post("/disconnect")
async def disconnect_google():
    google_adapter.disconnect()
    return {"status": "disconnected"}

# OAuth Callback Handler
@router.get("/oauth/callback")
async def oauth_callback(code: Optional[str] = None, error: Optional[str] = None):
    if error:
        return HTMLResponse(f"<h3>Google OAuth Error: {error}</h3><p><a href='/hub-widgets/google'>Return to Widget</a></p>")
    if not code:
        return HTMLResponse("<h3>No authorization code received.</h3>")
    
    # Exchange code for tokens
    try:
        async with httpx.AsyncClient() as client:
            resp = await client.post("https://oauth2.googleapis.com/token", data={
                "code": code,
                "client_id": google_adapter.client_id,
                "client_secret": google_adapter.client_secret,
                "redirect_uri": google_adapter.redirect_uri,
                "grant_type": "authorization_code"
            })
            if resp.status_code == 200:
                data = resp.json()
                refresh_token = data.get("refresh_token")
                if refresh_token:
                    google_adapter.save_token(refresh_token)
                return HTMLResponse("<h2>Google Account Linked Successfully!</h2><p>You may now close this window or return to the command center.</p><script>setTimeout(() => window.close(), 2500);</script>")
            else:
                return HTMLResponse(f"<h3>Failed to exchange token</h3><pre>{resp.text}</pre>")
    except Exception as e:
        return HTMLResponse(f"<h3>OAuth Exchange Exception: {e}</h3>")
