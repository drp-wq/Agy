import re
import time
from typing import List, Dict, Any, Optional
from service.config import settings
from service.database import get_db, record_notification

COMMON_CRYPTO_SYMBOLS = [
    "BTC", "ETH", "SOL", "BNB", "XRP", "DOGE", "ADA", "AVAX", "LINK", "SUI", "PEPE", "NEAR", "APT", "RENDER", "TAO", "SHIB", "GT"
]

KEYWORDS = [
    "buy", "sell", "pump", "dump", "long", "short", "breakout", "target", "stop", "entry", "alert", "signal", "liquidity", "support", "resistance"
]

def extract_symbols(text: str) -> List[str]:
    found = set()
    # Check for $SYMBOL or word SYMBOL
    for sym in COMMON_CRYPTO_SYMBOLS:
        pattern = rf"(?:\$|\b){sym}\b"
        if re.search(pattern, text, re.IGNORECASE):
            found.add(sym)
    return sorted(list(found))

def extract_keywords(text: str) -> List[str]:
    found = set()
    text_lower = text.lower()
    for kw in KEYWORDS:
        if kw in text_lower:
            found.add(kw)
    return sorted(list(found))

class WhatsAppAdapter:
    def __init__(self):
        self.bridge_token = settings.whatsapp_token

    def verify_token(self, token: Optional[str]) -> bool:
        if not self.bridge_token:
            return True # If no token configured yet, allow setup mode
        return token == self.bridge_token

    def ingest_notification(self, sender: str, text: str, timestamp: Optional[float] = None) -> Dict[str, Any]:
        ts = timestamp or time.time()
        symbols = extract_symbols(text)
        keywords = extract_keywords(text)
        
        symbols_str = ",".join(symbols)
        keywords_str = ",".join(keywords)
        msg_id = f"wa_{int(ts*1000)}"
        
        with get_db() as conn:
            cursor = conn.cursor()
            cursor.execute("""
            INSERT INTO whatsapp_messages (id, sender, message_text, symbols, keywords, timestamp, created_at)
            VALUES (?, ?, ?, ?, ?, ?, ?)
            """, (msg_id, sender, text, symbols_str, keywords_str, ts, time.time()))
            conn.commit()
            
        # If trading symbols or keywords were detected, forward to Universal Notification Center
        if symbols or keywords:
            sym_tag = f"[{'/'.join(symbols)}]" if symbols else ""
            record_notification(
                source="whatsapp",
                title=f"WhatsApp {sym_tag} from {sender}",
                message=text,
                severity="info" if not any(k in ["liquidat", "dump", "stop"] for k in keywords) else "warning",
                symbol=symbols[0] if symbols else None,
                is_simulated=False,
                deep_link="https://web.whatsapp.com"
            )

        return {"status": "ingested", "id": msg_id, "symbols": symbols, "keywords": keywords}

    def import_chat_export(self, export_text: str) -> Dict[str, Any]:
        # Standard WhatsApp export format: [DD/MM/YY, HH:MM:SS] Sender: Message or DD/MM/YYYY, HH:MM - Sender: Message
        lines = export_text.splitlines()
        imported_count = 0
        detected_symbols = set()
        
        # Regex matching WhatsApp export formats
        pattern = re.compile(r"^\[?(\d{1,2}[/.-]\d{1,2}[/.-]\d{2,4}[, ]+\d{1,2}:\d{2}(?::\d{2})?(?: [APap][Mm])?)\]?(?: -)? ([^:]+): (.*)$")
        
        with get_db() as conn:
            cursor = conn.cursor()
            for line in lines:
                m = pattern.match(line.strip())
                if m:
                    date_str, sender, msg = m.groups()
                    symbols = extract_symbols(msg)
                    keywords = extract_keywords(msg)
                    for s in symbols:
                        detected_symbols.add(s)
                    msg_id = f"wa_import_{imported_count}_{int(time.time())}"
                    cursor.execute("""
                    INSERT INTO whatsapp_messages (id, sender, message_text, symbols, keywords, timestamp, created_at)
                    VALUES (?, ?, ?, ?, ?, ?, ?)
                    """, (msg_id, sender.strip(), msg.strip(), ",".join(symbols), ",".join(keywords), time.time(), time.time()))
                    imported_count += 1
            conn.commit()

        return {
            "status": "success",
            "imported_messages": imported_count,
            "detected_symbols": sorted(list(detected_symbols))
        }

    def get_messages(self, query: Optional[str] = None, symbol: Optional[str] = None, limit: int = 50) -> List[Dict[str, Any]]:
        sql = "SELECT * FROM whatsapp_messages WHERE 1=1"
        params = []
        if query:
            sql += " AND (message_text LIKE ? OR sender LIKE ?)"
            params.extend([f"%{query}%", f"%{query}%"])
        if symbol:
            sql += " AND symbols LIKE ?"
            params.append(f"%{symbol}%")
        sql += " ORDER BY timestamp DESC LIMIT ?"
        params.append(limit)
        
        with get_db() as conn:
            cursor = conn.cursor()
            rows = cursor.execute(sql, params).fetchall()
            return [
                {
                    "id": r["id"],
                    "sender": r["sender"],
                    "message": r["message_text"],
                    "symbols": [s for s in (r["symbols"] or "").split(",") if s],
                    "keywords": [k for k in (r["keywords"] or "").split(",") if k],
                    "timestamp": r["timestamp"],
                    "formatted_time": time.strftime("%Y-%m-%d %H:%M:%S UTC", time.gmtime(r["timestamp"]))
                }
                for r in rows
            ]

    def wipe_data(self):
        with get_db() as conn:
            cursor = conn.cursor()
            cursor.execute("DELETE FROM whatsapp_messages")
            conn.commit()

    def get_status(self) -> Dict[str, Any]:
        with get_db() as conn:
            cursor = conn.cursor()
            count = cursor.execute("SELECT COUNT(*) as cnt FROM whatsapp_messages").fetchone()["cnt"]
        return {
            "bridge_configured": bool(self.bridge_token),
            "stored_messages": count,
            "android_companion_supported": True,
            "android_bridge_endpoint": "/hub-api/whatsapp/companion/webhook",
            "ios_status": "Manual Import / Share-Sheet only (iOS sandbox forbids background notification scraping)",
            "official_shortcut": "https://web.whatsapp.com"
        }

whatsapp_adapter = WhatsAppAdapter()
