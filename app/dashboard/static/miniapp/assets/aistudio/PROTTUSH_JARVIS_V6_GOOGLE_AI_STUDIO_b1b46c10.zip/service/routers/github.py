from fastapi import APIRouter
from service.adapters.github import github_adapter

router = APIRouter(prefix="/hub-api/github", tags=["GitHub Integration"])

@router.get("/overview")
async def get_github_overview():
    return await github_adapter.get_overview()
