import base64
import hashlib
from cryptography.fernet import Fernet
from service.config import settings

def _get_fernet() -> Fernet:
    # Derive a 32-byte key from settings.encryption_key
    key_bytes = hashlib.sha256(settings.encryption_key.encode("utf-8")).digest()
    b64_key = base64.urlsafe_b64encode(key_bytes)
    return Fernet(b64_key)

def encrypt_value(raw: str) -> str:
    if not raw:
        return ""
    f = _get_fernet()
    return f.encrypt(raw.encode("utf-8")).decode("utf-8")

def decrypt_value(enc: str) -> str:
    if not enc:
        return ""
    try:
        f = _get_fernet()
        return f.decrypt(enc.encode("utf-8")).decode("utf-8")
    except Exception:
        return ""
