from fastapi import APIRouter, Header, HTTPException, Query
from pydantic import BaseModel
from typing import Optional, List, Dict, Any
from service.database import query_notifications, record_notification, mark_notification_read, mark_all_notifications_read, clear_old_notifications

router = APIRouter(prefix="/hub-api/notifications", tags=["Notifications"])

class IngestNotificationRequest(BaseModel):
    source: str
    title: str
    message: str
    severity: str = "info"
    symbol: Optional[str] = None
    is_simulated: bool = False
    deep_link: Optional[str] = None
    metadata: Optional[Dict[str, Any]] = None

@router.get("")
async def get_notifications(
    source: Optional[str] = None,
    severity: Optional[str] = None,
    symbol: Optional[str] = None,
    query: Optional[str] = None,
    unread_only: bool = False,
    limit: int = Query(50, le=200),
    offset: int = 0
):
    items = query_notifications(source, severity, symbol, query, unread_only, limit, offset)
    return {
        "count": len(items),
        "notifications": items
    }

@router.post("")
async def create_notification(req: IngestNotificationRequest, authorization: Optional[str] = Header(None)):
    notif_id = record_notification(
        source=req.source,
        title=req.title,
        message=req.message,
        severity=req.severity,
        symbol=req.symbol,
        is_simulated=req.is_simulated,
        deep_link=req.deep_link,
        metadata=req.metadata
    )
    return {"status": "success", "id": notif_id}

@router.post("/{notif_id}/read")
async def mark_read(notif_id: str):
    mark_notification_read(notif_id)
    return {"status": "success"}

@router.post("/mark-all-read")
async def mark_all_read():
    mark_all_notifications_read()
    return {"status": "success"}

@router.delete("/purge")
async def purge_notifications(days: int = 14):
    clear_old_notifications(days)
    return {"status": "purged", "cutoff_days": days}
