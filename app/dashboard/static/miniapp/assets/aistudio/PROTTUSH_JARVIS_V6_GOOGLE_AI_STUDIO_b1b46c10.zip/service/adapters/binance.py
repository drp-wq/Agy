import httpx
import time
from typing import Dict, Any
from service.config import settings

class BinanceAdapter:
    def __init__(self):
        self.base_url = settings.binance_observer_url.rstrip("/")
        self.client = httpx.AsyncClient(timeout=4.0)

    async def get_health(self) -> Dict[str, Any]:
        try:
            r = await self.client.get(f"{self.base_url}/binance/api/health")
            if r.status_code == 200:
                data = r.json()
                data["connected"] = True
                return data
        except Exception as e:
            return {"connected": False, "status": "offline", "error": str(e), "service": "binance-observer"}
        return {"connected": False, "status": "unknown"}

    async def get_overview(self) -> Dict[str, Any]:
        try:
            r = await self.client.get(f"{self.base_url}/binance/api/overview")
            if r.status_code == 200:
                data = r.json()
                data["connected"] = True
                data["stale_warning"] = False
                return data
        except Exception as e:
            return {"connected": False, "error": str(e), "stale_warning": True}
        return {"connected": False, "stale_warning": True}

    async def get_positions(self) -> Dict[str, Any]:
        try:
            r = await self.client.get(f"{self.base_url}/binance/api/positions")
            if r.status_code == 200:
                return r.json()
        except Exception:
            pass
        return {"positions": []}

    async def get_risk(self) -> Dict[str, Any]:
        try:
            r = await self.client.get(f"{self.base_url}/binance/api/risk")
            if r.status_code == 200:
                return r.json()
        except Exception:
            pass
        return {}

binance_adapter = BinanceAdapter()
