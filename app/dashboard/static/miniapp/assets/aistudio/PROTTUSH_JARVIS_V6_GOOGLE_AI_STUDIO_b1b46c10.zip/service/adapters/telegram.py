import httpx
import time
from typing import Dict, Any, List, Optional
from service.config import settings
from service.adapters.whatsapp import extract_symbols, extract_keywords
from service.database import record_notification

class TelegramAdapter:
    def __init__(self):
        self.bot_token = settings.telegram_bot_token
        self.chat_id = settings.telegram_chat_id
        self.client = httpx.AsyncClient(timeout=5.0)

    def is_configured(self) -> bool:
        return bool(self.bot_token)

    async def get_bot_status(self) -> Dict[str, Any]:
        if not self.bot_token:
            return {
                "configured": False,
                "status": "pending_token",
                "message": "Telegram Bot Token not configured in .env",
                "webhook_supported": True,
                "bot_info": None
            }
        try:
            r = await self.client.get(f"https://api.telegram.org/bot{self.bot_token}/getMe")
            if r.status_code == 200 and r.json().get("ok"):
                return {
                    "configured": True,
                    "status": "healthy",
                    "bot_info": r.json().get("result", {}),
                    "target_chat_id": self.chat_id or "Not Set"
                }
            return {
                "configured": True,
                "status": "invalid_token",
                "error": r.json().get("description", "Authentication failed")
            }
        except Exception as e:
            return {"configured": True, "status": "network_error", "error": str(e)}

    async def fetch_recent_updates(self) -> List[Dict[str, Any]]:
        if not self.bot_token:
            return []
        try:
            r = await self.client.get(f"https://api.telegram.org/bot{self.bot_token}/getUpdates?limit=20")
            if r.status_code == 200 and r.json().get("ok"):
                updates = r.json().get("result", [])
                results = []
                for u in updates:
                    msg = u.get("message") or u.get("channel_post")
                    if msg:
                        text = msg.get("text", "")
                        sender = msg.get("from", {}).get("username") or msg.get("chat", {}).get("title") or "Unknown"
                        symbols = extract_symbols(text)
                        keywords = extract_keywords(text)
                        chat_id = msg.get("chat", {}).get("id")
                        msg_id = msg.get("message_id")
                        
                        deep_link = f"https://t.me/c/{str(chat_id).replace('-100', '')}/{msg_id}" if chat_id else "https://web.telegram.org"
                        
                        # Ingest into Universal Notification Center
                        if text:
                            record_notification(
                                source="telegram",
                                title=f"Telegram [{sender}]" + (f" (${symbols[0]})" if symbols else ""),
                                message=text,
                                severity="info" if not any(k in ["dump", "liquidation", "alert"] for k in keywords) else "warning",
                                symbol=symbols[0] if symbols else None,
                                is_simulated=False,
                                deep_link=deep_link
                            )
                        
                        results.append({
                            "update_id": u.get("update_id"),
                            "sender": sender,
                            "text": text,
                            "symbols": symbols,
                            "keywords": keywords,
                            "date": msg.get("date", int(time.time())),
                            "deep_link": deep_link
                        })
                return results
        except Exception:
            pass
        return []

telegram_adapter = TelegramAdapter()
