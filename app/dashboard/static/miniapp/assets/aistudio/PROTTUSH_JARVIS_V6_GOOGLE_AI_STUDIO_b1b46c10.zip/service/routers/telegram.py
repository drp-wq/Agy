from fastapi import APIRouter
from service.adapters.telegram import telegram_adapter

router = APIRouter(prefix="/hub-api/telegram", tags=["Telegram Integration"])

@router.get("/status")
async def get_telegram_status():
    return await telegram_adapter.get_bot_status()

@router.get("/updates")
async def get_telegram_updates():
    updates = await telegram_adapter.fetch_recent_updates()
    return {"count": len(updates), "updates": updates}
