from fastapi import APIRouter
from service.adapters.system import system_adapter

router = APIRouter(prefix="/hub-api/system", tags=["System Diagnostics"])

@router.get("/metrics")
async def get_system_metrics():
    return await system_adapter.get_metrics()
