import os
from pydantic import BaseModel
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent.parent
DATA_DIR = BASE_DIR / "data"
DATA_DIR.mkdir(parents=True, exist_ok=True)

class Settings(BaseModel):
    hub_port: int = int(os.getenv("HUB_ADAPTER_PORT", "7580"))
    hub_host: str = os.getenv("HUB_HOST", "127.0.0.1")
    database_url: str = str(DATA_DIR / "notifications.db")
    encryption_key: str = os.getenv("SECRET_ENCRYPTION_KEY", "default-fallback-key-32-chars-long!")
    
    # Upstream strictly read-only observers
    gate_observer_url: str = os.getenv("GATE_OBSERVER_URL", "http://127.0.0.1:8844")
    binance_observer_url: str = os.getenv("BINANCE_OBSERVER_URL", "http://127.0.0.1:8845")
    
    # Google OAuth
    google_client_id: str = os.getenv("GOOGLE_CLIENT_ID", "")
    google_client_secret: str = os.getenv("GOOGLE_CLIENT_SECRET", "")
    google_redirect_uri: str = os.getenv("GOOGLE_REDIRECT_URI", "https://home.prottushjd.tech/hub-api/oauth/google/callback")
    google_api_key: str = os.getenv("GOOGLE_API_KEY", "")
    
    # Telegram
    telegram_bot_token: str = os.getenv("TELEGRAM_BOT_TOKEN", "")
    telegram_chat_id: str = os.getenv("TELEGRAM_CHAT_ID", "")
    
    # GitHub
    github_token: str = os.getenv("GITHUB_ACCESS_TOKEN", "")
    github_user: str = os.getenv("GITHUB_USERNAME", "")
    
    # WhatsApp Companion Bridge
    whatsapp_token: str = os.getenv("WHATSAPP_BRIDGE_TOKEN", "")

settings = Settings()
