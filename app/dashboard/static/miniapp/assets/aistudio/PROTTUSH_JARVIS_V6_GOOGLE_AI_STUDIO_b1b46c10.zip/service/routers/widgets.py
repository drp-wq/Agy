from fastapi import APIRouter, Request
from fastapi.responses import HTMLResponse
from fastapi.templating import Jinja2Templates
from pathlib import Path

TEMPLATES_DIR = Path(__file__).resolve().parent.parent / "templates"
templates = Jinja2Templates(directory=str(TEMPLATES_DIR))

router = APIRouter(prefix="/hub-widgets", tags=["Hub Widgets"])

@router.get("/overview", response_class=HTMLResponse)
async def widget_overview(request: Request):
    return templates.TemplateResponse(request=request, name="overview.html")

@router.get("/notifications", response_class=HTMLResponse)
async def widget_notifications(request: Request):
    return templates.TemplateResponse(request=request, name="notifications.html")

@router.get("/trading", response_class=HTMLResponse)
async def widget_trading(request: Request):
    return templates.TemplateResponse(request=request, name="trading.html")

@router.get("/messages", response_class=HTMLResponse)
async def widget_messages(request: Request):
    return templates.TemplateResponse(request=request, name="messages.html")

@router.get("/google", response_class=HTMLResponse)
async def widget_google(request: Request):
    return templates.TemplateResponse(request=request, name="google.html")

@router.get("/netflix", response_class=HTMLResponse)
async def widget_netflix(request: Request):
    return templates.TemplateResponse(request=request, name="netflix.html")

@router.get("/development", response_class=HTMLResponse)
async def widget_development(request: Request):
    return templates.TemplateResponse(request=request, name="development.html")

@router.get("/intelligence", response_class=HTMLResponse)
async def widget_intelligence(request: Request):
    return templates.TemplateResponse(request=request, name="intelligence.html")

@router.get("/system", response_class=HTMLResponse)
async def widget_system(request: Request):
    return templates.TemplateResponse(request=request, name="system.html")
