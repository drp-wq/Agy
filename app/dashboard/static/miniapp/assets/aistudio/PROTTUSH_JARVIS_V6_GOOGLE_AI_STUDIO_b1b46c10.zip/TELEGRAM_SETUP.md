# Telegram Bot API Integration Guide

## Overview
The Telegram integration streams trading signals and channel notifications through the official Telegram Bot API without exposing user session keys or interfering with existing VPS trading bots.

## Setup Instructions

1. **Create a Dedicated Telegram Monitor Bot:**
   - Open Telegram and message `@BotFather`.
   - Send `/newbot` and name it `Prottush Command Center Monitor`.
   - Copy the API token provided by BotFather.

2. **Add Bot to Channels or Group:**
   - Add your bot as an Administrator or Member in your desired trading alert channels or private alert group.

3. **Configure Environment:**
   Edit `/root/prottush-homarr-hub/.env`:
   ```env
   TELEGRAM_BOT_TOKEN=1234567890:ABCdefGHIjklMNOpqrsTUVwxyz
   TELEGRAM_CHAT_ID=-1001234567890
   ```
   Restart adapter:
   ```bash
   systemctl restart prottush-hub-adapter.service
   ```

4. **Features Available on Board:**
   - Real-time bot status and connection health.
   - Live stream of recent message updates with deep links (`https://t.me/c/...`).
   - Automatic extraction of ticker mentions ($BTC, $ETH, $SOL, etc.).
   - Event forwarding to the Universal Notification Center.
