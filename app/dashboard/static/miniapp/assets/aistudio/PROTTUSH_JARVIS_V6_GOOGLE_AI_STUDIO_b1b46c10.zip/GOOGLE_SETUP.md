# Google Workspace Integration Guide

This guide describes how to connect your personal Google account (Gmail, Calendar, Drive, and YouTube) with least-privilege official OAuth2 scopes.

## Least-Privilege Scopes Used
- `https://www.googleapis.com/auth/gmail.readonly` — Unread count, sender, and subject headers only (no email body scraping).
- `https://www.googleapis.com/auth/calendar.readonly` — Upcoming agenda and event titles.
- `https://www.googleapis.com/auth/drive.readonly` — Recent files and starred items metadata.
- `https://www.googleapis.com/auth/youtube.readonly` — Crypto/trading channel video feeds.

## Setup Instructions

1. **Google Cloud Console:**
   - Go to [Google Cloud Console](https://console.cloud.google.com/).
   - Create a project (e.g. `Prottush-Command-Center`).
   - Enable: **Gmail API**, **Google Calendar API**, **Google Drive API**, **YouTube Data API v3**.

2. **OAuth Consent Screen:**
   - User Type: External (or Internal if Google Workspace).
   - Add Test User: Your personal Google email address.
   - Authorized Domain: `prottushjd.tech`.

3. **OAuth 2.0 Client Credentials:**
   - Application Type: **Web Application**.
   - Name: `Homarr Hub Gateway`.
   - Authorized Redirect URIs:
     `https://home.prottushjd.tech/hub-api/google/oauth/callback`

4. **Add Credentials to .env:**
   Edit `/root/prottush-homarr-hub/.env`:
   ```env
   GOOGLE_CLIENT_ID=your-client-id.apps.googleusercontent.com
   GOOGLE_CLIENT_SECRET=your-client-secret
   GOOGLE_REDIRECT_URI=https://home.prottushjd.tech/hub-api/google/oauth/callback
   ```
   Restart adapter:
   ```bash
   systemctl restart prottush-hub-adapter.service
   ```

5. **Authorize:**
   - Open board `https://home.prottushjd.tech/boards/google` (or widget at `http://127.0.0.1:7580/hub-widgets/google`).
   - Click **Connect Google** -> Approve permissions on Google.
   - Tokens are received, encrypted with AES-256 in SQLite, and unread summaries immediately activate.
