# Backup & Restore Procedures

## 1. Automated Backup Script

A full backup archive of Homarr database configurations and Hub data can be created at any time:

```bash
#!/usr/bin/env bash
set -e
TIMESTAMP=$(date +"%Y%m%d_%H%M%S")
BACKUP_DIR="/root/prottush-homarr-hub/backups"
mkdir -p "$BACKUP_DIR"

echo "Backing up Homarr database..."
sqlite3 /root/prottush-homarr-hub/appdata/db/db.sqlite ".backup '$BACKUP_DIR/homarr_db_$TIMESTAMP.sqlite'"

echo "Backing up Hub events database..."
sqlite3 /root/prottush-homarr-hub/data/notifications.db ".backup '$BACKUP_DIR/notifications_db_$TIMESTAMP.sqlite'"

echo "Backing up Caddy configuration..."
cp /etc/caddy/Caddyfile "$BACKUP_DIR/Caddyfile_$TIMESTAMP"

echo "Backup complete: $BACKUP_DIR/*_$TIMESTAMP*"
```

## 2. Restore Procedure

1. **Stop Homarr and Companion Service:**
   ```bash
   cd /root/prottush-homarr-hub
   docker compose down
   systemctl stop prottush-hub-adapter.service
   ```

2. **Restore SQLite Databases:**
   ```bash
   cp /root/prottush-homarr-hub/backups/homarr_db_<TIMESTAMP>.sqlite /root/prottush-homarr-hub/appdata/db/db.sqlite
   cp /root/prottush-homarr-hub/backups/notifications_db_<TIMESTAMP>.sqlite /root/prottush-homarr-hub/data/notifications.db
   ```

3. **Restart Services:**
   ```bash
   docker compose up -d
   systemctl start prottush-hub-adapter.service
   ```
