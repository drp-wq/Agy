# Prottush Homarr Universal Command Center

Production-grade, Cyberpunk-themed personal command center built on the official [Homarr v1.x](https://homarr.dev) release with integrated telemetry from Gate.io and Binance trading engines, Google Workspace, personal WhatsApp notification companion, Telegram Bot API, GitHub monitoring, Netflix launcher, and Universal Notification Center.

## Architecture Overview

```mermaid
flowchart TD
    User["Prottush (Browser)"]
    Caddy["Caddy Reverse Proxy (:80/:443)"]
    Homarr["Homarr Core v1.x (Port 7575)"]
    SocketProxy["Docker Socket Proxy (Port 2375, Read-Only)"]
    Companion["Hub Adapter Service (Port 7580)"]
    
    Gate["Gate.io Observer (:8844)"]
    Binance["Binance Observer (:8845)"]
    External["Google, WhatsApp, Telegram, GitHub, RSS"]

    User -->|HTTPS| Caddy
    Caddy -->|home.prottushjd.tech| Homarr
    Caddy -->|/hub-api & /hub-widgets| Companion
    Homarr --> SocketProxy
    Companion --> Gate
    Companion --> Binance
    Companion --> External
```

## Quick Start & Verification

1. **Homarr URL:** `https://home.prottushjd.tech` (Local fallback: `http://127.0.0.1:7575`)
2. **Existing Trading URL:** `https://trading.prottushjd.tech/` (Gate) & `https://trading.prottushjd.tech/binance` (Binance)
3. **Hub Companion Health:** `http://127.0.0.1:7580/hub-api/health`
4. **Admin Credentials:** Stored on VPS at `/root/.homarr_admin_credentials` (permissions 0600).

## 8 Configured Command Boards

1. **HOME** (`/boards/home`) — Universal Overview (Clock, Weather, Realtime System Health, Trading Overview, Notification Center).
2. **TRADING** (`/boards/trading`) — Gate & Binance Read-Only Telemetry (Spot, Range, Sniper, Alpha V3 paper metrics, live positions, freshness status).
3. **MESSAGES** (`/boards/messages`) — WhatsApp Android companion bridge, chat export importer, Telegram bot alert streaming.
4. **GOOGLE** (`/boards/google`) — Gmail unread summary, Google Calendar agenda, Drive recent files, YouTube channels, Google Search launcher.
5. **ENTERTAINMENT** (`/boards/entertainment`) — Netflix launch shortcut, genre browsers, curated watchlist.
6. **DEVELOPMENT** (`/boards/development`) — VPS git workspaces, GitHub cloud repos, commits, PRs, and CI runs.
7. **INTELLIGENCE** (`/boards/intelligence`) — Live crypto feeds (CoinDesk, Decrypt, CoinTelegraph, Bitcoin Magazine) with $TICKER tagging.
8. **SYSTEM** (`/boards/system`) — Real-time CPU, RAM, Disk telemetry, Docker container health, and Caddy status.
