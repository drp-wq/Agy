import asyncio
import os
import time
import json
from pathlib import Path
from playwright.async_api import async_playwright

SCREENSHOT_DIR = Path("/root/.gemini/antigravity-cli/brain/ed82c59d-5774-41ca-b847-fc6229e3205e/screenshots")
SCREENSHOT_DIR.mkdir(parents=True, exist_ok=True)

async def run_jarvis_acceptance():
    print("=" * 70)
    print("PROTTUSH HOME V4 — PROJECT JARVIS: MIDNIGHT AURORA ACCEPTANCE TEST")
    print("=" * 70)

    # Load admin creds for Homarr
    creds = {}
    with open('/root/.homarr_admin_credentials') as f:
        for line in f:
            if 'Username:' in line:
                creds['user'] = line.split('Username:')[1].strip()
            elif 'Password:' in line:
                creds['pass'] = line.split('Password:')[1].strip()

    results = {}

    async with async_playwright() as p:
        browser = await p.chromium.launch(headless=True)

        # -------------------------------------------------------------
        # 1. DESKTOP VIEWPORT (1920x1080)
        # -------------------------------------------------------------
        print("\n[TEST 1] Desktop Viewport (1920x1080)...")
        desk_ctx = await browser.new_context(viewport={'width': 1920, 'height': 1080}, ignore_https_errors=True)
        page = await desk_ctx.new_page()

        # 1.1 Direct JARVIS Portal
        await page.goto("https://home.prottushjd.tech/jarvis", wait_until="networkidle")
        await page.wait_for_timeout(2000)
        title = await page.title()
        print(f"  ✓ JARVIS Portal Title: '{title}'")
        
        # Verify JARVIS Holographic Rings and Nucleus
        has_rings = await page.is_visible(".jarvis-rings-container")
        has_radar = await page.is_visible(".radar-container")
        print(f"  ✓ Holographic Core Present: {has_rings} | Telemetry Radar Present: {has_radar}")
        assert has_rings and has_radar, "JARVIS Core or Radar missing!"

        await page.screenshot(path=str(SCREENSHOT_DIR / "jarvis_desktop_live.png"))
        print("  ✓ Screenshot captured: jarvis_desktop_live.png")

        # 1.2 Interactive Command Palette (Ctrl + K)
        print("  Testing Command Palette Keyboard Trigger (Ctrl+K)...")
        await page.keyboard.press("Control+k")
        await page.wait_for_timeout(600)
        palette_open = await page.eval_on_selector("#paletteOverlay", "el => el.classList.contains('open')")
        print(f"  ✓ Command Palette Open State: {palette_open}")
        assert palette_open, "Command Palette failed to open on Ctrl+K!"
        await page.screenshot(path=str(SCREENSHOT_DIR / "jarvis_palette_open.png"))
        print("  ✓ Screenshot captured: jarvis_palette_open.png")
        await page.keyboard.press("Escape")
        await page.wait_for_timeout(400)

        # 1.3 State Simulations Verification
        print("  Testing State Simulations on Desktop...")
        await page.click("button:has-text('Test Loading')")
        await page.wait_for_timeout(400)
        await page.click("button:has-text('Test Stale')")
        await page.wait_for_timeout(400)
        await page.click("button:has-text('Restore Live')")
        await page.wait_for_timeout(1000)

        # 1.4 Homarr Board Home with Integrated JARVIS Centerpiece
        print("  Testing Homarr Dashboard Login & Boards Home...")
        await page.goto("https://home.prottushjd.tech/auth/login", wait_until="networkidle")
        await page.fill('input[name="username"]', creds['user'])
        await page.fill('input[name="password"]', creds['pass'])
        await page.click('button[type="submit"]')
        await page.wait_for_timeout(2500)

        await page.goto("https://home.prottushjd.tech/boards/home", wait_until="networkidle")
        await page.wait_for_timeout(3000)
        await page.screenshot(path=str(SCREENSHOT_DIR / "homarr_home_jarvis_desktop.png"))
        print("  ✓ Screenshot captured: homarr_home_jarvis_desktop.png")
        results['desktop'] = 'PASS'
        await desk_ctx.close()

        # -------------------------------------------------------------
        # 2. IPAD / TABLET VIEWPORT (820x1180 Touch)
        # -------------------------------------------------------------
        print("\n[TEST 2] iPad / Tablet Viewport (820x1180 Touch)...")
        ipad_ctx = await browser.new_context(
            viewport={'width': 820, 'height': 1180},
            has_touch=True,
            is_mobile=False,
            device_scale_factor=2,
            ignore_https_errors=True
        )
        ipad_page = await ipad_ctx.new_page()

        await ipad_page.goto("https://home.prottushjd.tech/jarvis", wait_until="networkidle")
        await ipad_page.wait_for_timeout(2000)
        
        # Touch tap nucleus to trigger palette (force=True to bypass CSS animation stability check)
        await ipad_page.tap(".jarvis-nucleus", force=True)
        await ipad_page.wait_for_timeout(600)
        await ipad_page.screenshot(path=str(SCREENSHOT_DIR / "jarvis_ipad_palette.png"))
        await ipad_page.keyboard.press("Escape")
        await ipad_page.wait_for_timeout(400)

        await ipad_page.screenshot(path=str(SCREENSHOT_DIR / "jarvis_ipad_view.png"))
        print("  ✓ Screenshot captured: jarvis_ipad_view.png")
        results['ipad'] = 'PASS'
        await ipad_ctx.close()

        # -------------------------------------------------------------
        # 3. ANDROID MOBILE VIEWPORT (390x844 Touch)
        # -------------------------------------------------------------
        print("\n[TEST 3] Android Mobile Viewport (390x844 Touch)...")
        mob_ctx = await browser.new_context(
            viewport={'width': 390, 'height': 844},
            has_touch=True,
            is_mobile=True,
            device_scale_factor=3,
            user_agent="Mozilla/5.0 (Linux; Android 14; Pixel 7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Mobile Safari/537.36",
            ignore_https_errors=True
        )
        mob_page = await mob_ctx.new_page()

        await mob_page.goto("https://home.prottushjd.tech/jarvis", wait_until="networkidle")
        await mob_page.wait_for_timeout(2000)

        # Check mobile responsiveness & no horizontal overflow
        body_scroll_w = await mob_page.evaluate("() => document.body.scrollWidth")
        viewport_w = await mob_page.evaluate("() => window.innerWidth")
        print(f"  ✓ Mobile Width Check: body {body_scroll_w}px vs viewport {viewport_w}px (No overflow: {body_scroll_w <= viewport_w})")
        assert body_scroll_w <= viewport_w + 5, f"Horizontal overflow detected: {body_scroll_w} > {viewport_w}"

        await mob_page.screenshot(path=str(SCREENSHOT_DIR / "jarvis_android_mobile.png"))
        print("  ✓ Screenshot captured: jarvis_android_mobile.png")
        results['mobile'] = 'PASS'
        await mob_ctx.close()

        await browser.close()

    print("\n" + "=" * 70)
    print("ALL JARVIS ACCEPTANCE TESTS COMPLETED SUCCESSFULLY!")
    print("=" * 70)
    print(json.dumps(results, indent=2))
    return results

if __name__ == "__main__":
    asyncio.run(run_jarvis_acceptance())
