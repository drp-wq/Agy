#!/usr/bin/env python3
import sqlite3
import json
import time

DB_PATH = "/root/prottush-homarr-hub/appdata/db/db.sqlite"

CYBERPUNK_CSS = """
:root {
  --primary-color: #00f0ff !important;
  --secondary-color: #a855f7 !important;
}
.mantine-AppShell-main {
  background-color: #07090e !important;
}
.mantine-Card-root {
  background: rgba(13, 17, 23, 0.85) !important;
  backdrop-filter: blur(14px) !important;
  border: 1px solid rgba(0, 240, 255, 0.15) !important;
  box-shadow: 0 8px 32px 0 rgba(0, 0, 0, 0.45) !important;
  border-radius: 12px !important;
}
"""

BOARDS = [
    {
        "id": "b_home_001",
        "name": "home",
        "page_title": "HOME — Universal Command Center",
        "meta_title": "Home - Prottush Hub",
        "widgets": [
            {
                "kind": "clock",
                "options": {},
                "base": {"x": 0, "y": 0, "w": 3, "h": 1},
                "mobile": {"x": 0, "y": 0, "w": 3, "h": 1}
            },
            {
                "kind": "weather",
                "options": {"showHumidity": False, "showCity": True, "hasForecast": False},
                "base": {"x": 3, "y": 0, "w": 3, "h": 1},
                "mobile": {"x": 0, "y": 1, "w": 3, "h": 1}
            },
            {
                "kind": "iframe",
                "options": {"embedUrl": "/hub-widgets/system", "allowScrolling": True},
                "base": {"x": 6, "y": 0, "w": 4, "h": 1},
                "mobile": {"x": 0, "y": 2, "w": 3, "h": 1}
            },
            {
                "kind": "iframe",
                "options": {"embedUrl": "/hub-widgets/trading", "allowScrolling": True},
                "base": {"x": 0, "y": 1, "w": 10, "h": 2},
                "mobile": {"x": 0, "y": 3, "w": 3, "h": 2}
            },
            {
                "kind": "iframe",
                "options": {"embedUrl": "/hub-widgets/notifications", "allowScrolling": True},
                "base": {"x": 0, "y": 3, "w": 10, "h": 3},
                "mobile": {"x": 0, "y": 5, "w": 3, "h": 3}
            }
        ]
    },
    {
        "id": "b_trading_002",
        "name": "trading",
        "page_title": "TRADING — Gate and Binance Command Center",
        "meta_title": "Trading - Prottush Hub",
        "widgets": [
            {
                "kind": "iframe",
                "options": {"embedUrl": "/hub-widgets/trading", "allowScrolling": True},
                "base": {"x": 0, "y": 0, "w": 10, "h": 3},
                "mobile": {"x": 0, "y": 0, "w": 3, "h": 3}
            },
            {
                "kind": "iframe",
                "options": {"embedUrl": "/hub-widgets/notifications", "allowScrolling": True},
                "base": {"x": 0, "y": 3, "w": 10, "h": 3},
                "mobile": {"x": 0, "y": 3, "w": 3, "h": 3}
            }
        ]
    },
    {
        "id": "b_messages_003",
        "name": "messages",
        "page_title": "MESSAGES — Telegram & WhatsApp Command Center",
        "meta_title": "Messages - Prottush Hub",
        "widgets": [
            {
                "kind": "iframe",
                "options": {"embedUrl": "/hub-widgets/messages", "allowScrolling": True},
                "base": {"x": 0, "y": 0, "w": 10, "h": 4},
                "mobile": {"x": 0, "y": 0, "w": 3, "h": 4}
            }
        ]
    },
    {
        "id": "b_google_004",
        "name": "google",
        "page_title": "GOOGLE — Universal Suite",
        "meta_title": "Google - Prottush Hub",
        "widgets": [
            {
                "kind": "iframe",
                "options": {"embedUrl": "/hub-widgets/google", "allowScrolling": True},
                "base": {"x": 0, "y": 0, "w": 10, "h": 4},
                "mobile": {"x": 0, "y": 0, "w": 3, "h": 4}
            }
        ]
    },
    {
        "id": "b_entertainment_005",
        "name": "entertainment",
        "page_title": "ENTERTAINMENT — Netflix & Media",
        "meta_title": "Entertainment - Prottush Hub",
        "widgets": [
            {
                "kind": "iframe",
                "options": {"embedUrl": "/hub-widgets/netflix", "allowScrolling": True},
                "base": {"x": 0, "y": 0, "w": 10, "h": 4},
                "mobile": {"x": 0, "y": 0, "w": 3, "h": 4}
            }
        ]
    },
    {
        "id": "b_development_006",
        "name": "development",
        "page_title": "DEVELOPMENT — GitHub & VPS DevOps",
        "meta_title": "Development - Prottush Hub",
        "widgets": [
            {
                "kind": "iframe",
                "options": {"embedUrl": "/hub-widgets/development", "allowScrolling": True},
                "base": {"x": 0, "y": 0, "w": 10, "h": 4},
                "mobile": {"x": 0, "y": 0, "w": 3, "h": 4}
            }
        ]
    },
    {
        "id": "b_intelligence_007",
        "name": "intelligence",
        "page_title": "INTELLIGENCE — Social Feeds, News & Alerts",
        "meta_title": "Intelligence - Prottush Hub",
        "widgets": [
            {
                "kind": "iframe",
                "options": {"embedUrl": "/hub-widgets/intelligence", "allowScrolling": True},
                "base": {"x": 0, "y": 0, "w": 10, "h": 4},
                "mobile": {"x": 0, "y": 0, "w": 3, "h": 4}
            }
        ]
    },
    {
        "id": "b_system_008",
        "name": "system",
        "page_title": "SYSTEM — Service Health & Diagnostics",
        "meta_title": "System - Prottush Hub",
        "widgets": [
            {
                "kind": "iframe",
                "options": {"embedUrl": "/hub-widgets/system", "allowScrolling": True},
                "base": {"x": 0, "y": 0, "w": 10, "h": 4},
                "mobile": {"x": 0, "y": 0, "w": 3, "h": 4}
            }
        ]
    }
]

def populate():
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()
    
    # Get admin user ID
    user_row = cursor.execute("SELECT id FROM user WHERE name = 'prottush'").fetchone()
    admin_id = user_row[0] if user_row else None
    
    # Update default board if exists
    cursor.execute("DELETE FROM board WHERE name IN ('home','trading','messages','google','entertainment','development','intelligence','system')")
    
    for b in BOARDS:
        board_id = b["id"]
        name = b["name"]
        
        # 1. Insert board
        cursor.execute("""
        INSERT INTO board (
            id, name, is_public, creator_id, page_title, meta_title,
            primary_color, secondary_color, opacity, custom_css, disable_status, item_radius
        ) VALUES (?, ?, 0, ?, ?, ?, '#00f0ff', '#a855f7', 100, ?, 0, 'lg')
        """, (board_id, name, admin_id, b["page_title"], b["meta_title"], CYBERPUNK_CSS))
        
        # 2. Insert layouts
        layout_base_id = f"lay_base_{name}"
        layout_mob_id = f"lay_mob_{name}"
        cursor.execute("""
        INSERT INTO layout (id, name, board_id, column_count, breakpoint, role)
        VALUES (?, 'Base', ?, 10, 768, 'base'),
               (?, 'Mobile', ?, 3, 0, 'mobile')
        """, (layout_base_id, board_id, layout_mob_id, board_id))
        
        # 3. Insert section
        sec_id = f"sec_{name}_main"
        cursor.execute("""
        INSERT INTO section (id, board_id, kind, x_offset, y_offset, options)
        VALUES (?, ?, 'empty', 0, 0, '{"json": {}}')
        """, (sec_id, board_id))
        
        # Section layouts
        cursor.execute("""
        INSERT INTO section_layout (section_id, layout_id, x_offset, y_offset, width, height)
        VALUES (?, ?, 0, 0, 10, 1),
               (?, ?, 0, 0, 3, 1)
        """, (sec_id, layout_base_id, sec_id, layout_mob_id))
        
        # 4. Insert widgets
        for idx, w in enumerate(b["widgets"]):
            item_id = f"item_{name}_{idx}_{w['kind']}"
            opts_str = json.dumps({"json": w["options"]})
            cursor.execute("""
            INSERT INTO item (id, board_id, kind, options, advanced_options)
            VALUES (?, ?, ?, ?, '{"json": {}}')
            """, (item_id, board_id, w["kind"], opts_str))
            
            # Base item layout
            cursor.execute("""
            INSERT INTO item_layout (item_id, section_id, layout_id, x_offset, y_offset, width, height)
            VALUES (?, ?, ?, ?, ?, ?, ?)
            """, (item_id, sec_id, layout_base_id, w["base"]["x"], w["base"]["y"], w["base"]["w"], w["base"]["h"]))
            
            # Mobile item layout
            cursor.execute("""
            INSERT INTO item_layout (item_id, section_id, layout_id, x_offset, y_offset, width, height)
            VALUES (?, ?, ?, ?, ?, ?, ?)
            """, (item_id, sec_id, layout_mob_id, w["mobile"]["x"], w["mobile"]["y"], w["mobile"]["w"], w["mobile"]["h"]))

    # Set user home board to 'b_home_001'
    if admin_id:
        cursor.execute("UPDATE user SET home_board_id = 'b_home_001', mobile_home_board_id = 'b_home_001' WHERE id = ?", (admin_id,))
    
    # Also update 'everyone' group home board to 'b_home_001'
    cursor.execute("UPDATE 'group' SET home_board_id = 'b_home_001' WHERE name = 'everyone'")
    
    conn.commit()
    conn.close()
    print("Successfully populated all 8 boards with Cyberpunk Glassmorphic theme!")

if __name__ == "__main__":
    populate()
