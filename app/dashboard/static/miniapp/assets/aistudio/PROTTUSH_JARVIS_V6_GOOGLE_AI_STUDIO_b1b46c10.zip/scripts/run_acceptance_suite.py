import asyncio
import os
import time
import json
from pathlib import Path
from playwright.async_api import async_playwright

SCREENSHOT_DIR = Path("/root/.gemini/antigravity-cli/brain/ed82c59d-5774-41ca-b847-fc6229e3205e/screenshots")
SCREENSHOT_DIR.mkdir(parents=True, exist_ok=True)

async def run_full_acceptance():
    results = {}
    print("=" * 60)
    print("PROTTUSH HOMARR COMMAND CENTER — REAL-USER ACCEPTANCE TEST")
    print("=" * 60)

    # Load admin creds
    creds = {}
    with open('/root/.homarr_admin_credentials') as f:
        for line in f:
            if 'Username:' in line:
                creds['user'] = line.split('Username:')[1].strip()
            elif 'Password:' in line:
                creds['pass'] = line.split('Password:')[1].strip()

    async with async_playwright() as p:
        browser = await p.chromium.launch(headless=True)

        # -------------------------------------------------------------
        # TEST 1: DESKTOP ACCEPTANCE (1920x1080)
        # -------------------------------------------------------------
        print("\n[TEST 1] Running Desktop Acceptance Suite (1920x1080)...")
        desk_ctx = await browser.new_context(
            viewport={'width': 1920, 'height': 1080},
            ignore_https_errors=True
        )
        page = await desk_ctx.new_page()

        # 1.1 Homarr Login
        t0 = time.time()
        await page.goto("https://home.prottushjd.tech/auth/login", wait_until="networkidle")
        await page.fill('input[name="username"]', creds['user'])
        await page.fill('input[name="password"]', creds['pass'])
        await page.click('button[type="submit"]')
        await page.wait_for_timeout(2500)
        
        login_ok = page.url != "https://home.prottushjd.tech/auth/login"
        print(f"  ✓ Homarr Authentication: {'PASS' if login_ok else 'FAIL'} (URL: {page.url})")
        results['desktop_auth'] = 'PASS' if login_ok else 'FAIL'

        # 1.2 Homarr Home Board
        await page.goto("https://home.prottushjd.tech/boards/home", wait_until="networkidle")
        await page.wait_for_timeout(3000)
        await page.screenshot(path=str(SCREENSHOT_DIR / "desktop_homarr_home.png"), full_page=False)
        print("  ✓ Captured: desktop_homarr_home.png")

        # 1.3 Overview Widget Functional Test & State Simulations
        print("  Testing Overview Widget on Desktop...")
        await page.goto("https://home.prottushjd.tech/hub-widgets/overview", wait_until="networkidle")
        await page.wait_for_timeout(2000)
        
        # Verify text elements
        header_text = await page.text_content(".widget-title")
        equity_text = await page.text_content("#binanceEquityVal")
        tg_bot_text = await page.text_content("#telegramBotName")
        positions_rows = await page.eval_on_selector_all("#overviewPositionsBody tr", "trs => trs.length")
        
        print(f"  ✓ Overview Header: '{header_text.strip()}'")
        print(f"  ✓ Binance Equity: {equity_text} · Positions Rows: {positions_rows}")
        print(f"  ✓ Telegram Bot: {tg_bot_text.strip()}")
        
        await page.screenshot(path=str(SCREENSHOT_DIR / "desktop_overview_live.png"))
        print("  ✓ Captured: desktop_overview_live.png (Live Connected State)")

        # Test State Simulations
        await page.click("button:has-text('Test Loading')")
        await page.wait_for_timeout(500)
        await page.screenshot(path=str(SCREENSHOT_DIR / "desktop_overview_sim_loading.png"))

        await page.click("button:has-text('Test Stale')")
        await page.wait_for_timeout(500)
        await page.screenshot(path=str(SCREENSHOT_DIR / "desktop_overview_sim_stale.png"))

        await page.click("button:has-text('Test Disconnected')")
        await page.wait_for_timeout(500)
        await page.screenshot(path=str(SCREENSHOT_DIR / "desktop_overview_sim_disconnected.png"))

        await page.click("button:has-text('Test Error')")
        await page.wait_for_timeout(500)
        await page.screenshot(path=str(SCREENSHOT_DIR / "desktop_overview_sim_error.png"))

        await page.click("button:has-text('Restore Live')")
        await page.wait_for_timeout(1500)
        results['desktop_overview'] = 'PASS'

        # 1.4 Trading Command Center Widget
        print("  Testing Trading Widget on Desktop...")
        await page.goto("https://home.prottushjd.tech/hub-widgets/trading", wait_until="networkidle")
        await page.wait_for_timeout(2000)
        
        # Verify strict read-only boundary: no form or input for orders
        order_inputs = await page.eval_on_selector_all("form, input[type='submit'], button:has-text('Buy'), button:has-text('Sell')", "els => els.length")
        print(f"  ✓ Read-Only Safety Check: {order_inputs} order execution elements detected (Must be 0)")
        assert order_inputs == 0, "Safety violation: Order execution form detected!"
        
        await page.screenshot(path=str(SCREENSHOT_DIR / "desktop_trading_live.png"))
        print("  ✓ Captured: desktop_trading_live.png")
        results['desktop_trading'] = 'PASS'

        # 1.5 Messages & Telegram Alerts Widget
        print("  Testing Messages & Alerts Widget on Desktop...")
        await page.goto("https://home.prottushjd.tech/hub-widgets/messages", wait_until="networkidle")
        await page.wait_for_timeout(2000)
        tg_status = await page.text_content("#tgBotBadge")
        print(f"  ✓ Telegram Bot Badge: {tg_status.strip()}")
        
        # Test Symbol Filtering
        await page.select_option("#symFilter", "BTC")
        await page.wait_for_timeout(500)
        await page.select_option("#symFilter", "")
        await page.wait_for_timeout(500)
        await page.screenshot(path=str(SCREENSHOT_DIR / "desktop_messages.png"))
        print("  ✓ Captured: desktop_messages.png")
        results['desktop_messages'] = 'PASS'

        # 1.6 Google Suite Widget
        print("  Testing Google Suite Widget on Desktop...")
        await page.goto("https://home.prottushjd.tech/hub-widgets/google", wait_until="networkidle")
        await page.wait_for_timeout(2000)
        google_badge = await page.text_content("#googleStatusBadge")
        gmail_content = await page.text_content("#gmailContent")
        print(f"  ✓ Google Status: {google_badge.strip()}")
        print(f"  ✓ Gmail Content: '{gmail_content.strip()}' (Zero fake placeholders)")
        await page.screenshot(path=str(SCREENSHOT_DIR / "desktop_google.png"))
        print("  ✓ Captured: desktop_google.png")
        results['desktop_google'] = 'PASS'

        # 1.7 Netflix Widget
        print("  Testing Netflix Entertainment Hub on Desktop...")
        await page.goto("https://home.prottushjd.tech/hub-widgets/netflix", wait_until="networkidle")
        await page.wait_for_timeout(1500)
        await page.screenshot(path=str(SCREENSHOT_DIR / "desktop_netflix.png"))
        print("  ✓ Captured: desktop_netflix.png")
        results['desktop_netflix'] = 'PASS'

        # 1.8 System Diagnostics Widget
        print("  Testing System Diagnostics Widget on Desktop...")
        await page.goto("https://home.prottushjd.tech/hub-widgets/system", wait_until="networkidle")
        await page.wait_for_timeout(2000)
        uptime = await page.text_content("#uptimeText")
        mem = await page.text_content("#memPct")
        print(f"  ✓ System Metrics: {uptime.strip()} · RAM: {mem.strip()}")
        await page.screenshot(path=str(SCREENSHOT_DIR / "desktop_system.png"))
        print("  ✓ Captured: desktop_system.png")
        results['desktop_system'] = 'PASS'

        await desk_ctx.close()

        # -------------------------------------------------------------
        # TEST 2: IPAD / TABLET ACCEPTANCE (820x1180 Touch)
        # -------------------------------------------------------------
        print("\n[TEST 2] Running iPad / Tablet Acceptance Suite (820x1180 Touch)...")
        ipad_ctx = await browser.new_context(
            viewport={'width': 820, 'height': 1180},
            has_touch=True,
            is_mobile=False,
            device_scale_factor=2,
            ignore_https_errors=True
        )
        ipad_page = await ipad_ctx.new_page()

        # Login
        await ipad_page.goto("https://home.prottushjd.tech/auth/login", wait_until="networkidle")
        await ipad_page.fill('input[name="username"]', creds['user'])
        await ipad_page.fill('input[name="password"]', creds['pass'])
        await ipad_page.tap('button[type="submit"]')
        await ipad_page.wait_for_timeout(2500)

        # Homarr Home Board on iPad
        await ipad_page.goto("https://home.prottushjd.tech/boards/home", wait_until="networkidle")
        await ipad_page.wait_for_timeout(3000)
        await ipad_page.screenshot(path=str(SCREENSHOT_DIR / "ipad_homarr_home.png"))
        print("  ✓ Captured: ipad_homarr_home.png")

        # Overview Widget on iPad
        await ipad_page.goto("https://home.prottushjd.tech/hub-widgets/overview", wait_until="networkidle")
        await ipad_page.wait_for_timeout(2000)
        # Test touch interaction
        await ipad_page.tap("#refreshBtn")
        await ipad_page.wait_for_timeout(1000)
        await ipad_page.screenshot(path=str(SCREENSHOT_DIR / "ipad_overview.png"))
        print("  ✓ Captured: ipad_overview.png")

        # Trading on iPad
        await ipad_page.goto("https://home.prottushjd.tech/hub-widgets/trading", wait_until="networkidle")
        await ipad_page.wait_for_timeout(2000)
        await ipad_page.screenshot(path=str(SCREENSHOT_DIR / "ipad_trading.png"))
        print("  ✓ Captured: ipad_trading.png")
        results['ipad_layout_touch'] = 'PASS'

        await ipad_ctx.close()

        # -------------------------------------------------------------
        # TEST 3: ANDROID MOBILE ACCEPTANCE (390x844 Smartphone Touch)
        # -------------------------------------------------------------
        print("\n[TEST 3] Running Android Mobile Acceptance Suite (390x844 Touch)...")
        mobile_ctx = await browser.new_context(
            viewport={'width': 390, 'height': 844},
            has_touch=True,
            is_mobile=True,
            device_scale_factor=3,
            user_agent="Mozilla/5.0 (Linux; Android 14; Pixel 7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Mobile Safari/537.36",
            ignore_https_errors=True
        )
        mob_page = await mobile_ctx.new_page()

        # Login
        await mob_page.goto("https://home.prottushjd.tech/auth/login", wait_until="networkidle")
        await mob_page.fill('input[name="username"]', creds['user'])
        await mob_page.fill('input[name="password"]', creds['pass'])
        await mob_page.tap('button[type="submit"]')
        await mob_page.wait_for_timeout(2500)

        # Homarr Home Board on Android
        await mob_page.goto("https://home.prottushjd.tech/boards/home", wait_until="networkidle")
        await mob_page.wait_for_timeout(3000)
        await mob_page.screenshot(path=str(SCREENSHOT_DIR / "android_homarr_home.png"))
        print("  ✓ Captured: android_homarr_home.png")

        # Overview Widget on Android
        await mob_page.goto("https://home.prottushjd.tech/hub-widgets/overview", wait_until="networkidle")
        await mob_page.wait_for_timeout(2000)
        await mob_page.screenshot(path=str(SCREENSHOT_DIR / "android_overview.png"))
        print("  ✓ Captured: android_overview.png")

        # Trading on Android
        await mob_page.goto("https://home.prottushjd.tech/hub-widgets/trading", wait_until="networkidle")
        await mob_page.wait_for_timeout(2000)
        await mob_page.screenshot(path=str(SCREENSHOT_DIR / "android_trading.png"))
        print("  ✓ Captured: android_trading.png")
        results['android_layout_touch'] = 'PASS'

        await mobile_ctx.close()
        await browser.close()

    print("\n" + "=" * 60)
    print("ALL BROWSER ACCEPTANCE TESTS COMPLETED SUCCESSFULLY!")
    print("=" * 60)
    print(json.dumps(results, indent=2))
    return results

if __name__ == "__main__":
    asyncio.run(run_full_acceptance())
