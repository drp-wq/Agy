# Installation & Deployment Guide

## Prerequisites
- Ubuntu 24.04 LTS VPS
- Docker 29.1+ & Docker Compose 2.40+
- Python 3.12+ with venv
- Caddy Web Server

## Step-by-Step Installation

### 1. Project Directory & Environment
```bash
cd /root/prottush-homarr-hub
cp .env.example .env
chmod 600 .env
# Populate SECRET_ENCRYPTION_KEY using: openssl rand -hex 32
```

### 2. Launch Homarr & Socket Proxy Stack
```bash
docker compose up -d
```

### 3. Setup Python Virtual Environment & Hub Companion
```bash
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
systemctl daemon-reload
systemctl enable prottush-hub-adapter.service
systemctl start prottush-hub-adapter.service
```

### 4. Populate 8 Cyberpunk Boards
```bash
python3 scripts/populate_boards.py
```

### 5. Caddy Reverse Proxy Configuration
Add `home.prottushjd.tech` block to `/etc/caddy/Caddyfile`:
```caddy
home.prottushjd.tech {
    handle /hub-api/* {
        reverse_proxy 127.0.0.1:7580
    }
    handle /hub-widgets/* {
        reverse_proxy 127.0.0.1:7580
    }
    handle /hub-static/* {
        reverse_proxy 127.0.0.1:7580
    }
    handle {
        reverse_proxy 127.0.0.1:7575
    }
}
```
Reload Caddy:
```bash
caddy reload --config /etc/caddy/Caddyfile
```

### 6. DNS Configuration
In your DNS provider (e.g. Cloudflare / Namecheap / Route53), add an `A` record:
- **Host / Name:** `home`
- **Type:** `A`
- **Value / IP:** `187.52.118.25`
- **TTL:** Auto or 300s
Once added, Caddy will automatically negotiate Let's Encrypt TLS.
