# Gate.io & Binance Trading Integration Specification

## Upstream Dashboard Endpoints

1. **Gate.io Observer Dashboard:**
   - Host: `127.0.0.1:8844`
   - Public Website: `https://trading.prottushjd.tech/`
   - Operating Mode: `STRICTLY PAPER ONLY`
   - Endpoints Polled: `/api/health`, `/api/overview`, `/api/subsystems`
   - Data Monitored: Spot Momentum Bot, Range Bot, Solana Discovery Stream (Raydium pools), anti-rug filter stats, stale data timestamps.

2. **Binance Agentic Command Center:**
   - Host: `127.0.0.1:8845`
   - Public Website: `https://trading.prottushjd.tech/binance`
   - Operating Mode: `paper_trading`
   - Endpoints Polled: `/binance/api/health`, `/binance/api/overview`, `/binance/api/positions`, `/binance/api/risk`
   - Data Monitored: Alpha V3 Experiment progress, stage execution, active positions, realized/unrealized P&L, ledger audits.

## Strict Isolation Guarantees
- **Zero Order Routing:** The Hub Companion and Homarr containers have NO API keys with trading or withdrawal permissions.
- **Independent Boundaries:** Gate paper equity ($240.00 isolated) and Binance paper equity ($100,000.00 isolated) are kept completely distinct; balances are NEVER merged or presented misleadingly.
- **Staleness Warnings:** When upstream data age exceeds 120 seconds, a prominent amber `STALE` badge is applied to prevent acting on outdated telemetry.
