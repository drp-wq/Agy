# GitHub Integration Guide

## Overview
Monitors local VPS git repositories and cloud GitHub activity (commits, pull requests, open issues, workflow runs, failed CI checks) with minimal read-only permissions.

## Fine-Grained Personal Access Token (PAT)
1. Go to [GitHub Settings -> Developer Settings -> Fine-grained tokens](https://github.com/settings/tokens?type=beta).
2. Click **Generate new token**.
3. Name: `Prottush Command Center ReadOnly`.
4. Expiration: 90 or 365 days.
5. Repository Access: **Only select repositories** (or **All repositories**).
6. Permissions (Read-only):
   - **Repository contents:** Read-only
   - **Issues:** Read-only
   - **Pull requests:** Read-only
   - **Actions / Workflows:** Read-only
7. Copy the generated token.

## Configure Environment
In `/root/prottush-homarr-hub/.env`:
```env
GITHUB_ACCESS_TOKEN=github_pat_...
GITHUB_USERNAME=your_username
```
Restart adapter:
```bash
systemctl restart prottush-hub-adapter.service
```

## Security Guarantees
- Zero push, commit, delete, or merge permissions.
- Repository secrets and private tokens are never retrieved or rendered.
- Separated entirely from production deployment pipelines.
