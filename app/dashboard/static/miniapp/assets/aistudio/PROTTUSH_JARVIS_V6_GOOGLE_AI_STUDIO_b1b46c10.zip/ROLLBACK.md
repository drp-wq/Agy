# Rollback & Decommissioning Procedure

If at any point you wish to revert your VPS to its exact pre-deployment state, execute the following tested steps:

## Step 1: Stop and Remove Homarr Containers
```bash
cd /root/prottush-homarr-hub
docker compose down -v
```

## Step 2: Stop and Disable Hub Adapter Service
```bash
systemctl stop prottush-hub-adapter.service
systemctl disable prottush-hub-adapter.service
rm -f /etc/systemd/system/prottush-hub-adapter.service
systemctl daemon-reload
```

## Step 3: Revert Caddy Reverse Proxy
Restore the pre-homarr Caddyfile backup created during discovery:
```bash
cp /root/prottush-homarr-hub/backups/Caddyfile.pre-homarr.bak /etc/caddy/Caddyfile
caddy reload --config /etc/caddy/Caddyfile
```

## Step 4: Verify Existing Trading Services
Ensure Gate and Binance observer dashboards remain active and unaffected:
```bash
systemctl status trading-observer-dashboard.service
systemctl status binance-observer-dashboard.service
curl -I https://trading.prottushjd.tech/
curl -I https://trading.prottushjd.tech/binance/
```
