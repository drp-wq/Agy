# Architecture Specification

## 1. System Topology

The command center is structured around isolation, least-privilege security, and non-blocking telemetry aggregation:

- **Upstream Trading Services (Unmodified & Preserved):**
  - Gate.io Observer (`127.0.0.1:8844`): Serves `/api/overview`, `/api/health`, `/api/subsystems`. Protected by systemd strict sandboxing.
  - Binance Agentic Observer (`127.0.0.1:8845`): Serves `/binance/api/overview`, `/binance/api/health`, `/binance/api/positions`. Protected by systemd strict sandboxing.
  - Both services run strictly read-only; no live keys or execution rights are granted to Homarr.

- **Homarr Container (`127.0.0.1:7575`):**
  - Pinned Image: `ghcr.io/homarr-labs/homarr@sha256:f7b31d2dee7b14cfaabd78a5e844362ccd736d09c1b5b4d498b0f2d21c0d17d0`
  - Internal DB: SQLite at `/appdata/db/db.sqlite`
  - Resource Limits: 1.5 CPUs, 1024MB Memory
  - Docker Socket: Isolated via `tecnativa/docker-socket-proxy` (read-only GET permissions for container inventory; all POST/DELETE/PUT mutations blocked).

- **Hub Companion Service (`127.0.0.1:7580`):**
  - High-performance FastAPI service running under systemd (`prottush-hub-adapter.service`).
  - Manages event normalization, deduplication, SQLite event database (`data/notifications.db`), Google OAuth tokens (AES-256 encrypted), WhatsApp companion ingestion, Telegram Bot polling, and RSS intelligence feeds.
  - Serves custom responsive Glassmorphic Cyberpunk widgets embedded inside Homarr boards via Homarr's native `iframe` widget.

- **Caddy Reverse Proxy (`:80` / `:443`):**
  - `trading.prottushjd.tech`: Untouched basicauth reverse-proxy routing to `127.0.0.1:8844` and `127.0.0.1:8845`.
  - `home.prottushjd.tech`: Direct reverse proxy to Homarr (`127.0.0.1:7575`), with `/hub-api/*` and `/hub-widgets/*` routed to `127.0.0.1:7580`.

## 2. Security Boundaries

- **Zero Order Execution:** Homarr and the Hub Companion have no trading execution permissions.
- **Credential Storage:** Secrets are stored in `/root/prottush-homarr-hub/.env` (mode 0600) and `/root/.homarr_admin_credentials` (mode 0600).
- **Socket Isolation:** Direct `/var/run/docker.sock` is NEVER mounted to Homarr.
