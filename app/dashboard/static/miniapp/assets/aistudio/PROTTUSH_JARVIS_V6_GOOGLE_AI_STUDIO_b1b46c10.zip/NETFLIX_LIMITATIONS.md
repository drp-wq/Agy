# Netflix Technical Architecture & Limitations

## Official API Scope
Netflix does **not** provide a public, general-purpose OAuth API for personal accounts to retrieve viewing history, active watch states, or real-time playback telemetry.

## Security & Compliance Architecture
In accordance with strict security standards:
- **No Password Prompts:** The Command Center will NEVER request your Netflix email or password.
- **No Cookie Scraping:** No browser cookie harvesting or DRM playback session extraction is attempted.
- **Dedicated Launcher:** Provides direct, deep-linked shortcuts to Netflix Browse, TV Shows, Movies, My List, and Global Search.
- **Curated Watchlist:** Provides a persistent, manually maintained watchlist stored locally in your SQLite database (`entertainment_watchlist`).
- **External Metadata:** Deep links to TMDB (The Movie Database) for official synopsis, release schedules, and public media artwork.
