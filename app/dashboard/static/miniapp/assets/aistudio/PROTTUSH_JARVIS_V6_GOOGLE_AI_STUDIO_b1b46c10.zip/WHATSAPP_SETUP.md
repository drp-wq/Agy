# Personal WhatsApp Integration Guide

## Privacy & Security Architecture
This integration is built around strict data privacy and zero account-hijacking:
- **No Unofficial Web Scraping:** Does NOT use Puppeteer, headless browsers, or reverse-engineered QR sessions that risk WhatsApp account bans.
- **Strictly Local:** WhatsApp messages reside on your local SQLite database; they are never sent to third-party servers.
- **Purgeable:** A single click on **Wipe Stored Data** permanently drops all cached messages.

## Supported Modes

### Mode 1: Android Companion Forwarder (Real-time)
On Android, apps such as *Notification Forwarder*, *Tasker*, or *MacroDroid* can securely post notification text to your Hub API:

1. **Set Bridge Token in `.env`:**
   ```env
   WHATSAPP_BRIDGE_TOKEN=generate_strong_secret_token_here
   ```
   Restart service:
   ```bash
   systemctl restart prottush-hub-adapter.service
   ```

2. **Configure Forwarder Endpoint:**
   - **URL:** `https://home.prottushjd.tech/hub-api/whatsapp/companion/webhook`
   - **Method:** `POST`
   - **Headers:** `Authorization: Bearer <WHATSAPP_BRIDGE_TOKEN>`, `Content-Type: application/json`
   - **Payload JSON:**
     ```json
     {
       "sender": "%sender%",
       "text": "%message%",
       "timestamp": %timestamp%
     }
     ```

3. **Trading Symbol & Keyword Detection:**
   The Hub automatically parses `$BTC`, `$ETH`, `$SOL`, `$XRP`, etc., and alerts on keywords like `breakout`, `target`, `liquidat`.

---

### Mode 2: Chat Export Import (iOS / Manual)
Due to Apple iOS sandbox constraints, background notification interception is restricted by the operating system.
To import trading group messages on iOS:
1. Open the WhatsApp Group -> Tap Group Name -> **Export Chat** -> **Without Media**.
2. Save the `.txt` file.
3. Open the **MESSAGES** board (`/boards/messages`).
4. Click **Import Chat Export (.txt)** and select the exported file.
5. All messages are ingested, categorized by sender and ticker symbols, and displayed immediately in your command center.
